#!/usr/bin/env python3
"""
check_compliance.py: Design Compliance Check for a PBIR report (Step 9).

Reads:   <name>.Report (PBIR) · tokens/tokens.yaml · rule blocks in references/**
         <_brief>/exceptions.yaml · baseline.yaml · house.lock.yaml (optional)
Writes:  <out>.json + <out>.md (compliance-protocol.md format)

Implemented automatic checks (v0.1): see IMPLEMENTED below. Every other active rule is reported as
NOT EVALUATED (never as passed).

Usage:
  python scripts/check_compliance.py --report "<path>/<name>.Report" [--brief "<path>/_brief"]
         [--out "<path>/_brief/compliance-report"] [--write-baseline] [--quiet]
Exit code: 0 = not FAILED, 1 = FAILED.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _tokens as T  # noqa: E402
from _pbir import Report  # noqa: E402

INTRO_MANIFEST = T.SKILL_ROOT / "assets" / "templates" / "intro-page" / "intro.manifest.json"


def is_intro(page) -> bool:
    return page.name.strip() == "Intro"


def intro_checks(c):
    """PAGE-008 (Intro first + landing) and PAGE-009 (structure matches the template)."""
    rep = c.rep
    first = rep.pages[0] if rep.pages else None
    for p in rep.pages:
        if p.name.strip() == "Intro Light":
            c.add("PAGE-008", p, None, "page", "Intro is Dark-only (no Light twin)", p.name)
    if not first or not is_intro(first):
        c.add("PAGE-008", first, None, "pageOrder[0]", "Intro page (template)", first.name if first else "no pages")
        return
    meta = json.loads((rep.defn / "pages" / "pages.json").read_text(encoding="utf-8"))
    if meta.get("landingPageName") not in (None, first.id):
        c.add("PAGE-008", first, None, "landingPageName", first.id, meta.get("landingPageName"))
    if INTRO_MANIFEST.exists():
        man = json.loads(INTRO_MANIFEST.read_text(encoding="utf-8"))
        want = sorted(man["structure_fingerprint"])
        nav = man.get("navigator", {})
        dyn = {nav.get("group")} | set(nav.get("layers", {}))
        def rel(v):
            p = v.raw.get("position", {})
            h = "*" if v.id in dyn else round(p.get("height", 0))
            return f"{v.vtype}@{round(p.get('x', 0))},{round(p.get('y', 0))},{round(p.get('width', 0))}x{h}"
        got = sorted(rel(v) for v in first.visuals)
        if got != want:
            missing = sorted(set(want) - set(got))[:3]
            extra = sorted(set(got) - set(want))[:3]
            c.add("PAGE-009", first, None, "structure", f"template ({len(want)} visuals)", f"missing {missing} extra {extra}")
        for v in first.visuals:
            if v.vtype == "group":
                continue
            if rep.effective(v, "background", "show") is True:
                c.add("PAGE-009", first, v, "visualContainerObjects.background.show", False, True)
        grp = next((v for v in first.visuals if v.id == nav.get("group")), None)
        if grp is not None:
            n = sum(1 for p in rep.pages if p is not first and not p.is_tooltip and not p.hidden and p.name.strip() != "Intro")
            pad, mx = nav["cell_padding"], nav["max_height"]
            hb = max(nav["button_min"], min(nav["button_max"], (mx - (n - 1) * pad) / n)) if n else nav["button_max"]
            H = min(mx, n * hb + (n - 1) * pad) if n else nav["button_max"]
            if abs(grp.h - H) > 2:
                c.add("PAGE-010", first, grp, "navigator height", f"{H:.0f}px for {n} tab(s)", f"{grp.h:.0f}px")

TOL = 0.5
ALLOWED_FONTS = {"Segoe UI", "Segoe UI Semibold", "Segoe UI Bold"}
DATA_OBJECTS = {"values", "labels", "dataPoint", "value", "dataLabels", "categoryLabels", "rowHeaders", "total", "subTotals"}
CHART_TYPES_ALLOWED = {"lineChart", "areaChart", "waterfallChart", "clusteredBarChart", "clusteredColumnChart", "columnChart"}
CHART_LIKE = ("Chart", "chart", "pie", "donut", "gauge", "scatter", "map", "Map", "treemap", "funnel", "ribbon", "kpi")
NON_CHART_OK = {"cardVisual", "tableEx", "pivotTable", "slicer", "advancedSlicerVisual", "listSlicer", "actionButton",
                "pageNavigator", "bookmarkNavigator", "textbox", "shape", "image", "group", "card", "multiRowCard"}


class Ctx:
    def __init__(self, rep: Report, tokens: dict):
        self.rep, self.t = rep, tokens
        g = tokens["layout"]["grid"]
        self.margin, self.gutter, self.col, self.pitch = g["margin"], g["gutter"], g["column"], g["pitch"]
        self.col_x = [self.margin + i * self.pitch for i in range(g["columns"])]
        self.span_w = {s: self.col * s + self.gutter * (s - 1) for s in range(1, g["columns"] + 1)}
        usable = g["usable"]
        self.split_w = {int((usable - self.gutter * (n - 1)) / n) for n in (5, 7, 9, 10, 11)}
        b = tokens["layout"]["bands"]
        self.bands = {k: (v["y"], v["bottom"]) for k, v in b.items()}
        self.colors = {m: T.all_color_values(tokens, m) for m in T.MODES}
        self.tt = tokens["layout"]["tooltip"]
        self.findings = []

    def add(self, rule, page=None, visual=None, prop="", expected="", found=""):
        self.findings.append({
            "rule": rule, "page": page.name if page else "", "page_id": page.id if page else "",
            "visual_id": visual.id if visual else "", "visual_type": visual.vtype if visual else "",
            "property": prop, "expected": str(expected), "found": str(found)})

    # helpers
    def band_of(self, v):
        for name, (y0, y1) in self.bands.items():
            if v.y >= y0 - TOL and v.bottom <= y1 + TOL:
                return name
        return None

    @staticmethod
    def is_bg_shape(v):
        return v.vtype in ("shape", "image") and v.w >= 1200 and v.h >= 600

    def top_level(self, page):
        return [v for v in page.visuals if not v.parent and not self.is_bg_shape(v)]


def rep_title_on(rep, v) -> bool:
    return rep.effective(v, "title", "show") is True


def font_family(value) -> str:
    return str(value).split(",")[0].strip().strip("'").strip('"').strip()


# ----------------------------------------------------------------------------- checks
def layout_checks(c: Ctx):
    for p in c.rep.pages:
        if is_intro(p):
            continue
        if p.is_tooltip:
            ok = (p.width, p.height) in {(c.tt["small"]["width"], c.tt["small"]["height"]),
                                         (c.tt["medium"]["width"], c.tt["medium"]["height"])}
            if not ok:
                c.add("TIP-001", p, expected="176x48 | 320x320", found=f"{p.width}x{p.height}")
            if p.display != "ActualSize":
                c.add("LAYOUT-002", p, prop="displayOption", expected="ActualSize", found=p.display)
            continue
        if (p.width, p.height) != (1280, 720):
            c.add("LAYOUT-001", p, prop="page.size", expected="1280x720", found=f"{p.width}x{p.height}")
        if p.display != "FitToPage":
            c.add("LAYOUT-002", p, prop="displayOption", expected="FitToPage", found=p.display)
        top = c.top_level(p)
        content = [v for v in top if c.band_of(v) == "content"]
        bottom = sorted([v for v in top if c.band_of(v) == "bottom"], key=lambda v: v.x)
        for v in top:
            if c.band_of(v) is None:
                c.add("LAYOUT-005", p, v, "position", "inside one band", f"y {v.y:.0f}–{v.bottom:.0f}")
            for k, val in (("x", v.x), ("y", v.y), ("width", v.w), ("height", v.h)):
                if abs(val - round(val)) > 0.05:
                    c.add("LAYOUT-007", p, v, k, "integer", f"{val:.2f}")
                    break
        for v in content + bottom[:1]:
            if min(abs(v.x - x) for x in c.col_x) > TOL:
                c.add("LAYOUT-003", p, v, "x", "column start", f"{v.x:.1f}")
        for v in content:
            allowed = list(c.span_w.values()) + list(c.split_w)
            if min(abs(v.w - w) for w in allowed) > TOL:
                c.add("LAYOUT-004", p, v, "width", "span width", f"{v.w:.1f}")
        solid = [v for v in content if v.vtype != "shape"]
        for i, a in enumerate(solid):
            for b in solid[i + 1:]:
                ix = min(a.right, b.right) - max(a.x, b.x)
                iy = min(a.bottom, b.bottom) - max(a.y, b.y)
                if ix > 1 and iy > 1:
                    c.add("LAYOUT-008", p, b, "bounds", "no overlap", f"overlaps {a.vtype} {a.id[:8]}")


def header_checks(c: Ctx, p):
    """PAGE-011 · HD1 header: 4 visuals, template geometry, logo and frame colour of the page mode."""
    import install_header as H
    g = c.t["component"]["header"]
    mode = "light" if p.mode == "light" else "dark"
    found = {}
    for v in p.visuals:
        n = H.visual_name(v.raw, c.t)
        if n in H.NAMES:
            found[n] = v
    for n, key in (("Header Frame", "frame"), ("Header Logo", "logo"), ("Header Title", "title"), ("Header Badge", "badge"),
                   ("Header Period", "period")):
        v = found.get(n)
        if v is None:
            if n in H.REQUIRED:
                c.add("PAGE-011", p, None, n, "present (install_header.py)", "missing")
            continue
        geo = g[key]
        if any(abs(a - b) > TOL for a, b in ((v.x, geo["x"]), (v.y, geo["y"]), (v.w, geo["width"]), (v.h, geo["height"]))):
            c.add("PAGE-011", p, v, "position", f"{geo['x']},{geo['y']} {geo['width']}x{geo['height']}",
                  f"{v.x:.0f},{v.y:.0f} {v.w:.0f}x{v.h:.0f}")
    logo = found.get("Header Logo")
    if logo is not None and g["logo"][mode] not in json.dumps(logo.raw):
        c.add("PAGE-011", p, logo, "imageUrl", g["logo"][mode], "other logo")
    frame = found.get("Header Frame")
    if frame is not None:
        want = T.resolve_path(c.t, "semantic.color.surface.header", mode).upper()
        if want not in json.dumps(frame.raw).upper():
            c.add("PAGE-011", p, frame, "background.color", want, "other")


def chrome_checks(c: Ctx, lock: dict):
    exempt = set(lock.get("twin_exempt", []))
    names = {" ".join(p.name.split()) for p in c.rep.pages}
    for p in c.rep.pages:
        if p.is_tooltip or is_intro(p):
            continue
        hdr = [v for v in p.visuals if not v.parent and v.vtype in ("shape", "group", "image")
               and v.w >= 1200 and v.y < c.bands["content"][0] and v.h < 120]
        if not hdr:
            c.add("PAGE-001", p, expected="header frame 1246x66 in band.header", found="missing")
        header_checks(c, p)
        for v in p.visuals:
            if v.vtype == "slicer" and v.y < c.bands["bottom"][0] - TOL:
                c.add("PAGE-004", p, v, "position", "dropdown slicer in band.bottom", f"y {v.y:.0f}")
            for r in c.t["component"].get("visual_level", []):          # SLICER-008/009 · styles themes cannot set
                if v.vtype == r["visual"]:
                    want = T.visual_level_value(c.t, r)
                    got = next((val for g, o, pr, s, val in v.props
                                if o == r["object"] and pr == r["property"] and s == (r.get("selector") or "")), None)
                    same = got is not None and (float(got) == float(want) if isinstance(want, (int, float)) else str(got) == str(want))
                    if not same:
                        c.add(r.get("rule", "SLICER-008"), p, v, f"{r['object']}.{r['property']}", want, got)
        if p.raw_name[:1] in (" ", " "):
            c.add("NAV-006", p, prop="displayName", expected="no leading spaces", found=repr(p.raw_name[:12]))
        if p.mode == "light" and not p.hidden:
            c.add("MODE-004", p, prop="visibility", expected="HiddenInViewMode", found=p.visibility)
        if p.mode == "dark" and not p.hidden and p.name not in exempt and " ".join(f"{p.name} Light".split()) not in names:
            c.add("MODE-002", p, expected=f"twin '{p.name} Light'", found="missing")


def visual_checks(c: Ctx):
    scale = set(c.t["primitive"]["size"])
    orange = T.resolve(c.t, "{primitive.color.orange}").upper()
    red = T.resolve(c.t, "{primitive.color.red}").upper()
    for p in c.rep.pages:
        if is_intro(p):
            for v in p.visuals:
                if v.vtype in ("pageNavigator", "bookmarkNavigator") and rep_title_on(c.rep, v):
                    c.add("NAV-007", p, v, "title.show", False, True)
            continue
        palette = c.colors[p.mode]
        for v in p.visuals:
            if v.vtype in ("card", "multiRowCard"):
                c.add("KPI-001", p, v, "visualType", "cardVisual", v.vtype)
            if v.vtype not in NON_CHART_OK and (v.vtype not in CHART_TYPES_ALLOWED) and any(k in v.vtype for k in CHART_LIKE):
                c.add("CHART-001", p, v, "visualType", "allowed chart type", v.vtype)
            is_header = v.vtype in ("shape", "group") and v.w >= 1200 and v.y < c.bands["content"][0] and v.h < 120
            for g, o, prop, sel, val in v.props:
                if isinstance(val, str) and val.startswith("#") and len(val) >= 7:
                    hx = val[:7].upper()
                    if hx not in palette:
                        c.add("COLOR-001", p, v, f"{o}.{prop}{'['+sel+']' if sel else ''}", f"token colour ({p.mode})", hx)
                    if p.mode == "dark" and hx == orange and o in DATA_OBJECTS and \
                            (v.vtype in ("tableEx", "pivotTable", "cardVisual") or v.vtype in CHART_TYPES_ALLOWED):
                        c.add("COLOR-005", p, v, f"{o}.{prop}", "conditional only", "static orange")
                    if p.mode == "light" and hx == red and o != "sentimentColors":   # waterfall decrease = negative by definition (COLOR-011)
                        c.add("COLOR-006", p, v, f"{o}.{prop}{'['+sel+']' if sel else ''}", "negatives via condition only", "static red")
                if prop in ("fontFamily", "fontFace") and isinstance(val, str):
                    fam = font_family(val)
                    if fam not in ALLOWED_FONTS:
                        c.add("TYPO-001", p, v, f"{o}.{prop}", "Segoe UI family", fam)
                    elif T.is_bare_font(val):
                        c.add("TYPO-006", p, v, f"{o}.{prop}{'['+sel+']' if sel else ''}", T.font_stack(c.t, fam), val)
                if prop in ("fontSize", "textSize") and isinstance(val, (int, float)):
                    if val < 8:
                        c.add("ACCESS-004", p, v, f"{o}.{prop}", ">= 8", val)
                    elif val not in scale:
                        c.add("TYPO-002", p, v, f"{o}.{prop}", "8|9|10|12|15|20|25", val)
                if o in ("dropShadow", "shadowCustom", "glowCustom") and prop == "show" and val is True and not is_header:
                    c.add("KPI-005" if v.vtype == "cardVisual" else "PAGE-002", p, v, f"{o}.show", False, True)
                if prop in ("labelDisplayUnits", "labelPrecision") and v.vtype not in ("slicer", "advancedSlicerVisual", "listSlicer"):   # slicer labels are text
                    c.add("FMT-002", p, v, f"{o}.{prop}", "format from the model", val)
            if v.vtype in ("pageNavigator", "bookmarkNavigator") and rep_title_on(c.rep, v):
                c.add("NAV-007", p, v, "title.show", False, True)
            if v.vtype == "waterfallChart":
                for prop, tok in (("increaseFill", "waterfall.increase"), ("decreaseFill", "waterfall.decrease"),
                                  ("totalFill", "waterfall.total")):
                    exp = T.resolve_path(c.t, f"semantic.color.{tok}", p.mode).upper()
                    got = c.rep.effective(v, "sentimentColors", prop)
                    if isinstance(got, str) and got.startswith("#") and got[:7].upper() != exp:
                        c.add("COLOR-011", p, v, f"sentimentColors.{prop}", exp, got)


def theme_checks(c: Ctx):
    th = c.rep.theme
    sent = c.t["component"]["theme_sentiment"]
    for key in ("good", "bad", "neutral"):
        exp = T.resolve(c.t, sent[key], "dark").upper()
        if str(th.get(key, "")).upper() != exp:
            c.add("COLOR-009", None, None, f"theme.{key}", exp, th.get(key))
    for cls, spec in th.get("textClasses", {}).items():
        if "fontFace" in spec and font_family(spec["fontFace"]) not in ALLOWED_FONTS:
            c.add("TYPO-001", None, None, f"theme.textClasses.{cls}", "Segoe UI family", font_family(spec["fontFace"]))
        elif "fontFace" in spec and T.is_bare_font(spec["fontFace"]):
            c.add("TYPO-006", None, None, f"theme.textClasses.{cls}.fontFace", T.font_stack(c.t, spec["fontFace"]), spec["fontFace"])
    for vtype, wild in th.get("visualStyles", {}).items():
        for obj, entries in wild.get("*", {}).items():
            for e in entries:
                ff = e.get("fontFamily")
                if isinstance(ff, str) and font_family(ff) not in ALLOWED_FONTS:
                    c.add("TYPO-001", None, None, f"theme.visualStyles.{vtype}.{obj}.fontFamily", "Segoe UI family", font_family(ff))
                elif isinstance(ff, str) and T.is_bare_font(ff):
                    c.add("TYPO-006", None, None, f"theme.visualStyles.{vtype}.{obj}.fontFamily", T.font_stack(c.t, ff), ff)


def nav_checks(c: Ctx):
    page_ids = {p.id for p in c.rep.pages}
    bm_names = {b.get("name") for b in c.rep.bookmarks}
    for p in c.rep.pages:
        for v in p.visuals:
            props = {(o, pr): val for g, o, pr, s, val in v.props if o == "visualLink"}
            target = props.get(("visualLink", "navigationSection"))
            if isinstance(target, str) and target and target not in page_ids:
                c.add("NAV-005", p, v, "visualLink.navigationSection", "existing page", target)
            bm = props.get(("visualLink", "bookmark"))
            if isinstance(bm, str) and bm and bm not in bm_names:
                c.add("NAV-005", p, v, "visualLink.bookmark", "existing bookmark", bm)
    all_visuals = {v.id for p in c.rep.pages for v in p.visuals}
    for b in c.rep.bookmarks:
        sec = b.get("explorationState", {}).get("activeSection")
        if sec and sec not in page_ids:
            c.add("NAV-005", None, None, f"bookmark '{b.get('displayName', b.get('name'))}'", "existing page", sec)
        for tv in b.get("options", {}).get("targetVisualNames", []) or []:
            if tv not in all_visuals:
                c.add("NAV-005", None, None, f"bookmark '{b.get('displayName', b.get('name'))}' target", "existing visual", tv)


IMPLEMENTED = {"NAV-007", "PAGE-008", "PAGE-009", "PAGE-010", "LAYOUT-001", "LAYOUT-002", "LAYOUT-003", "LAYOUT-004", "LAYOUT-005", "LAYOUT-007", "LAYOUT-008",
               "TIP-001", "PAGE-001", "PAGE-002", "PAGE-004", "NAV-005", "NAV-006", "MODE-002", "MODE-004",
               "KPI-001", "KPI-005", "CHART-001", "COLOR-001", "COLOR-005", "COLOR-006", "COLOR-009", "COLOR-011",
               "TYPO-001", "TYPO-002", "ACCESS-004", "FMT-002", "SLICER-008", "SLICER-009", "TYPO-006", "PAGE-011"}  # 34 rules


# ----------------------------------------------------------------------------- status
def fingerprint(f):
    return hashlib.sha1(f"{f['rule']}|{f['page_id']}|{f['visual_id']}|{f['property']}".encode()).hexdigest()[:16]


def load_yaml(p: Path):
    if p and p.exists():
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    return {}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--brief")
    ap.add_argument("--out")
    ap.add_argument("--write-baseline", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    tokens = T.load()
    rules = {}
    for _, data in T.load_rule_blocks():
        if isinstance(data, list):
            for r in data:
                if isinstance(r, dict) and "id" in r:
                    rules[r["id"]] = r
    rep = Report(a.report)
    brief = Path(a.brief) if a.brief else rep.dir.parent / "_brief"
    lock = load_yaml(brief / "house.lock.yaml")
    exceptions = (load_yaml(brief / "exceptions.yaml").get("exceptions") or [])
    baseline = {b["fingerprint"] for b in (load_yaml(brief / "baseline.yaml").get("findings") or [])}

    c = Ctx(rep, tokens)
    for fn in (layout_checks, visual_checks, theme_checks, nav_checks, intro_checks):
        fn(c)
    chrome_checks(c, lock)

    today = dt.date.today()
    for f in c.findings:
        r = rules.get(f["rule"], {})
        f["severity"] = r.get("severity", "warning")
        f["fingerprint"] = fingerprint(f)
        f["status"] = "FAILED"
        for e in exceptions:
            if e.get("rule") != f["rule"] or e.get("status", "active") != "active":
                continue
            sc = e.get("scope", {})
            if sc.get("report") or (sc.get("visual_id") and sc["visual_id"] == f["visual_id"]) or \
               (not sc.get("visual_id") and sc.get("page") and sc["page"] in (f["page"], f["page"].removesuffix(" Light"))):
                rb = e.get("review_by")
                expired = rb and dt.date.fromisoformat(str(rb)) < today
                f["status"] = "EXPIRED-WAIVER" if expired else "WAIVED"
                f["exception"] = e.get("id")
                break
        if f["status"] == "FAILED" and f["fingerprint"] in baseline:
            f["status"] = "BASELINE"

    if a.write_baseline:
        brief.mkdir(parents=True, exist_ok=True)
        data = {"design_system_version": tokens["meta"]["version"], "created_on": str(today),
                "findings": [{"rule": f["rule"], "page": f["page_id"], "visual": f["visual_id"], "fingerprint": f["fingerprint"]}
                             for f in c.findings if f["status"] == "FAILED"]}
        (brief / "baseline.yaml").write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")

    failed_rules = {f["rule"] for f in c.findings}
    active = {k: r for k, r in rules.items() if r.get("status") == "active"}
    passed = sorted(k for k in active if k in IMPLEMENTED and k not in failed_rules)
    not_eval = sorted(k for k in active if k not in IMPLEMENTED)
    crit = [f for f in c.findings if f["status"] in ("FAILED", "EXPIRED-WAIVER") and f["severity"] == "critical"]
    warn = [f for f in c.findings if f["status"] == "FAILED" and f["severity"] != "critical"]
    waived = [f for f in c.findings if f["status"] == "WAIVED"]
    base = [f for f in c.findings if f["status"] == "BASELINE"]
    status = ("FAILED" if crit else "PASSED WITH WARNINGS" if warn else "PASSED WITH WAIVERS" if waived else "PASSED")

    twins = sum(1 for p in rep.pages if p.mode == "light")
    result = {"report": rep.dir.name, "ds_version": tokens["meta"]["version"], "date": str(today), "status": status,
              "pages": len(rep.pages) - twins, "twins": twins, "visuals": sum(len(p.visuals) for p in rep.pages),
              "summary": {"critical": len(crit), "warnings": len(warn), "waived": len(waived), "baseline": len(base),
                          "passed_rules": len(passed), "not_evaluated_rules": len(not_eval)},
              "passed_rules": passed, "not_evaluated_rules": not_eval, "findings": c.findings}

    md = render_md(result, crit, warn, waived, base)
    if a.out:
        out = Path(a.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.with_suffix(".json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        out.with_suffix(".md").write_text(md, encoding="utf-8")
    if not a.quiet:
        print(md if not a.out else md.split("## Critical")[0])
    return 1 if status == "FAILED" else 0


def render_md(r, crit, warn, waived, base) -> str:
    def by_rule(items):
        cnt = Counter(f["rule"] for f in items)
        return ", ".join(f"{k} ×{v}" for k, v in cnt.most_common()) or "—"

    def table(items, limit=60):
        rows = ["| Rule | Page | Visual | Property | Expected | Found |", "|---|---|---|---|---|---|"]
        for f in items[:limit]:
            rows.append(f"| {f['rule']} | {f['page'] or 'report'} | {f['visual_type']} {f['visual_id'][:8]} | "
                        f"{f['property']} | {f['expected']} | {f['found']} |")
        if len(items) > limit:
            rows.append(f"| … | {len(items) - limit} more in the JSON report | | | | |")
        return "\n".join(rows)

    s = r["summary"]
    return f"""# Design Compliance Report

**Report:** {r['report']} · **Design System:** v{r['ds_version']} · **Pages:** {r['pages']} (+{r['twins']} twins) · **Visuals:** {r['visuals']} · **Date:** {r['date']}
**Status:** {r['status']}

| Status | Count | By rule |
|---|---|---|
| Critical | {s['critical']} | {by_rule(crit)} |
| Warnings | {s['warnings']} | {by_rule(warn)} |
| Waived | {s['waived']} | {by_rule(waived)} |
| Baseline | {s['baseline']} | {by_rule(base)} |
| Passed rules | {s['passed_rules']} | {', '.join(r['passed_rules']) or '—'} |
| Not evaluated rules | {s['not_evaluated_rules']} | manual / assisted / not yet automated |

## Critical
{table(crit)}

## Warnings
{table(warn)}

## Not evaluated
{', '.join(r['not_evaluated_rules'])}

**Next step:** {'remediation plan (`remediation-plan.yaml`)' if r['status'] == 'FAILED' else 'ready for visual review and publishing'}
"""


if __name__ == "__main__":
    sys.exit(main())
