#!/usr/bin/env python3
"""preview_testbed.py: geometry preview (NOT a Power BI render) of the HouseTest pages → preview.png"""
import json, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
HERE = Path(__file__).resolve().parent
REP = HERE / "HouseTest" / "HouseTest.Report"
sys.path.insert(0, str(HERE.parent.parent / "scripts"))
import _tokens as T  # noqa: E402
TOK = T.load()
def c(path, mode): return T.resolve_path(TOK, T.expand_alias(path), mode)
font = ImageFont.load_default()
meta = json.loads((REP / "definition/pages/pages.json").read_text())
tiles = []
for pid in meta["pageOrder"]:
    pg = json.loads((REP / "definition/pages" / pid / "page.json").read_text(encoding="utf-8"))
    name = pg["displayName"]; mode = "light" if name.endswith("Light") else "dark"
    if name not in ("Intro", "Summary", "Summary Light", "Profit & Loss"):
        continue
    im = Image.new("RGB", (1280, 720), c("color.surface.page", mode)); dr = ImageDraw.Draw(im)
    vis = []
    for vd in (REP / "definition/pages" / pid / "visuals").iterdir():
        d = json.loads((vd / "visual.json").read_text(encoding="utf-8")); vis.append(d)
    pos = {d["name"]: d["position"] for d in vis}
    def absxy(d):
        x, y = d["position"]["x"], d["position"]["y"]; p = d.get("parentGroupName")
        while p in pos: x += pos[p]["x"]; y += pos[p]["y"]; p = next((v.get("parentGroupName") for v in vis if v["name"] == p), None)
        return x, y
    for d in sorted(vis, key=lambda d: d["position"].get("z", 0)):
        vt = d.get("visual", {}).get("visualType", "group"); x, y = absxy(d); w, h = d["position"]["width"], d["position"]["height"]
        if vt == "group": continue
        if vt == "image":
            s = json.dumps(d); name_img = next((n for n in ("Globe_map7381549055369043.png", "RHG_ICON_WHITE6551529436343584.png", "logo-white.png", "logo-blue.png") if n in s), None)
            src = REP / "StaticResources/RegisteredResources" / name_img
            if src.exists():
                img = Image.open(src).convert("RGBA"); img.thumbnail((int(w), int(h))); im.paste(img, (int(x), int(y)), img)
            continue
        if vt == "shape" and w > 1200 and h > 600:
            continue
        fill = c("color.surface.panel", mode) if vt not in ("textbox", "actionButton", "pageNavigator") else None
        dr.rounded_rectangle([x, y, x + w, y + h], radius=8, fill=fill, outline=c("color.border.container", mode))
        if vt in ("lineChart", "waterfallChart", "tableEx", "clusteredBarChart", "listSlicer", "cardVisual") and h > 60:
            dr.rectangle([x + 1, y + 1, x + w - 1, y + 20], fill=c("color.surface.panel_title", mode))
        label = vt if vt != "textbox" else "TITLE"
        dr.text((x + 6, y + 4), label, fill=c("color.text.on_panel_title", mode) if h > 60 else c("color.text.primary", mode), font=font)
    dr.text((8, 702), f"{name} · geometry preview (not a Power BI render)", fill=c("color.text.primary", mode), font=font)
    tiles.append(im)
sheet = Image.new("RGB", (1280 * 2 + 20, 720 * 2 + 20), "#999999")
for i, t in enumerate(tiles[:4]):
    sheet.paste(t, ((i % 2) * 1300, (i // 2) * 740))
sheet.resize((1300, 740)).save(HERE / "preview.png"); print("preview.png")
