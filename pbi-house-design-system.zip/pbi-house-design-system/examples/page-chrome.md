<!-- STATUS: v0.1 (Step 9) · LOADED: on demand -->
# Examples: Page chrome

## Good: header and bottom band (Dark page "Summary")
```yaml
header:
  container: { kind: shape, x: 12, y: 8, w: 1256, h: 64, fill: color.surface.header, shadow: color.shadow.header }  # PAGE-001/002
  logo: { kind: image, x: 20, y: 16, h: 48, variant: dark-background }      # PAGE-003
  title: { kind: textbox, text: "Summary", centre_x: 640, type: type.page_title }   # PAGE-005, TYPO-004
  period: { text: "Jun-2026", type: type.period, color: color.text.period }   # TEXT-005
bottom_band:
  left: [Year, Period, comparison, measure type, unit, currency]   # PAGE-004
  right: [info x 1086, home x 1152, toggle(moon → "Summary Light") x 1218]   # NAV-001, MODE-005
twin: "Summary Light" (HiddenInViewMode, identical except colours)   # MODE-001/004
```

## Bad
- No header container; title textbox floating at y 30 → ✗ PAGE-001
- Shadow on every panel → ✗ PAGE-002 (header only)
- Toggle in the header, 40 × 40 → ✗ MODE-005 / PAGE-007
- Page named "    ▶ 📄 Room Costs" → ✗ NAV-006 (no leading spaces; hierarchy in house.lock.yaml)
