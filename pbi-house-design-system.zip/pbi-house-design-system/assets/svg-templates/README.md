# assets/svg-templates

SVG templates with {token} placeholders for DAX image measures (sparklines, variance arrows).
