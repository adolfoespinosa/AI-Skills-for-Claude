<!--
STATUS: v0.1 (Step 9): scripts implemented; check_compliance automates 27 rules (see IMPLEMENTED in the script).
PURPOSE: How to run, read and act on the Design Compliance Check.
LOADED: reviews, redesigns, and before handoff or publishing.
-->
# Compliance Protocol

## 1. Inputs

| Input | Source |
|---|---|
| Report definition | `<name>.Report/definition/**` (PBIR only; convert PBIR-Legacy first, D11) |
| Theme | `StaticResources/RegisteredResources/<custom theme>.json` + base theme |
| Rules | `yaml` rule blocks in `references/**` (parsed automatically) |
| Tokens | `tokens/tokens.yaml` |
| Report state | `_brief/house.lock.yaml`, `exceptions.yaml`, `baseline.yaml` (optional) |
| Model checks (FMT, DATA) | Read-only queries through the model tools (`integration/tooling.md`) |

## 2. Run

```bash
# 1. Design rules (all auto + assisted checks)
python ${CLAUDE_SKILL_DIR}/scripts/check_compliance.py --report "<path>/<name>.Report" --brief "<path>/_brief" \
       --out "<path>/_brief/compliance-report"            # writes .json + .md
# 2. Twin parity (MODE-001)
python ${CLAUDE_SKILL_DIR}/scripts/check_twins.py --report "<path>/<name>.Report"
# 3. After a change: only formatting/position paths changed
python ${CLAUDE_SKILL_DIR}/scripts/diff_guard.py --before "<copy of the PBIP before>" --after "<PBIP folder>"
# First audit of a legacy report (optional, with user consent)
python ${CLAUDE_SKILL_DIR}/scripts/check_compliance.py ... --write-baseline
```

The checker always works on **effective values**: base theme → custom theme → visual override. Positions are
**absolute**, with visual groups resolved.

## 3. Finding statuses and report status

| Finding status | Meaning |
|---|---|
| `FAILED` | Rule violated, no waiver |
| `WAIVED` | Covered by an active exception (`exceptions.yaml`) |
| `ACCEPTED-DEVIATION` | Covered by the design-system list AD-xxx (`foundations/color.md`) |
| `BASELINE` | Known legacy issue (`baseline.yaml`) |
| `EXPIRED-WAIVER` | Exception past `review_by`, treated as FAILED |
| `NOT EVALUATED` | `check: manual`, or the data needed was not available |
| `PASSED` | — |

| Report status | Condition |
|---|---|
| **FAILED** | ≥ 1 critical `FAILED` / `EXPIRED-WAIVER` |
| **PASSED WITH WARNINGS** | Only warning-level `FAILED` |
| **PASSED WITH WAIVERS** | No failures, ≥ 1 `WAIVED` |
| **PASSED** | Everything else (baseline, accepted deviations and not-evaluated items are listed but do not block) |

## 4. Report format

```text
DESIGN COMPLIANCE REPORT
Report: <name> · Design System v<x.y.z> · Pages: <n> (+<n> twins) · Date: <yyyy-mm-dd>
Status: <status>

Critical (n):   <RULE-ID>  <page> › <visual id/title>  <expected token>  ≠  <found>
Warnings (n):   …
Waived (n):     <RULE-ID> → <EXC-…> (review <date>)
Accepted deviations (n): <AD-…>
Baseline (n)    Passed (n)
Not evaluated (n): <RULE-ID> (reason)
Next step: <remediation plan | ready for publishing>
```

JSON (`compliance-report.json`): `{ report, ds_version, status, findings: [ {rule, severity, status, page_id, visual_id, property, expected, found, exception?} ] }`.

## 5. Acting on findings
1. Group the findings by page, including the twin, into `remediation-plan.yaml` (target values as **tokens**).
2. Ask for approval, then hand over to `powerbi-report-cli` authoring.
3. Re-run 1 + 2 + 3. Report the delta: fixed, remaining, new.
4. Rules not automated (`NOT EVALUATED`): check them manually against the component rules or with
   `qa/visual-review.md`. Never report PASSED without evidence.
5. Twin check: `check_twins.py` matches visuals by type + position. Measures named `<X> Light` may replace
   `<X>` on the Light twin (mode-specific icons).
