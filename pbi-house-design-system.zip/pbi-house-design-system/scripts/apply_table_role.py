#!/usr/bin/env python3
"""
apply_table_role.py: give a tableEx a house table role (TB2), resolved for the page mode (Dark / Light).

Role 'financial-matrix' (assets/templates/table-roles/financial-matrix.json):
  title Segoe UI Semibold 9 left · on_panel_title text on surface.panel_title band
  subtitle Segoe UI Semibold 8 · text.panel_subtitle (blank " " until the real subtitle exists)
  divider solid 5 px · spacing 5 / 5 / 5 (above subtitle, above divider, above plot area)
  column headers right-aligned Segoe UI Semibold 8 · custom (fixed) widths: first column 150, dummy 10, others 55
  dummy column ("." header, measure = "") right after the first column, painted surface.table (header + values)
  grid row padding 2
Everything else on the table is left as it is.

The role is recorded on the visual as annotations (house.role, house.role.args), so make_light_twin.py re-applies it
with Light colours on the twin. Deterministic helper of the authoring step (D1a).

Usage:
  python scripts/apply_table_role.py --report "<.Report>" --page "<Dark page>" --visual <visualId> \
         --first "dim layout.KPI Heading" --dummy "*Measures*.Dummy Column" [--insert-dummy] [--subtitle " "]
--insert-dummy adds the dummy measure projection after the first column (a binding change: only when the user asks).
"""
from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _tokens as T  # noqa: E402
from install_header import resolve  # noqa: E402

SKILL = T.SKILL_ROOT
ROLES = SKILL / "assets" / "templates" / "table-roles"


def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def dump(p, d): Path(p).write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding="utf-8")


def _key(e):
    return json.dumps(e.get("selector"), sort_keys=True)


def _merge(target: dict, fragment: dict):
    for obj, entries in fragment.items():
        cur = target.setdefault(obj, [])
        for e in entries:
            hit = next((x for x in cur if _key(x) == _key(e)), None)
            if hit is None:
                cur.append(copy.deepcopy(e))
            else:
                hit.setdefault("properties", {}).update(copy.deepcopy(e["properties"]))


def apply_role(body: dict, tokens: dict, mode: str, role: str, first: str, dummy: str, subtitle: str = " ",
               insert_dummy: bool = False) -> dict:
    tpl = load(ROLES / f"{role}.json")
    ctx = {"FIRST": first, "DUMMY": dummy, "SUBTITLE": subtitle.replace("'", "''")}
    frag = resolve(copy.deepcopy({k: tpl[k] for k in ("container", "objects")}), tokens, mode, ctx)
    v = body.setdefault("visual", {})
    _merge(v.setdefault("visualContainerObjects", {}), frag["container"])
    _merge(v.setdefault("objects", {}), frag["objects"])
    if insert_dummy:
        projs = v["query"]["queryState"]["Values"]["projections"]
        if not any(p.get("queryRef") == dummy for p in projs):
            ent, meas = dummy.split(".", 1)
            projs.insert(1, {"field": {"Measure": {"Expression": {"SourceRef": {"Entity": ent}}, "Property": meas}},
                             "queryRef": dummy, "nativeQueryRef": ".", "displayName": "."})
    ann = [a for a in body.get("annotations", []) if not a.get("name", "").startswith("house.role")]
    ann += [{"name": "house.role", "value": role},
            {"name": "house.role.args", "value": json.dumps({"first": first, "dummy": dummy, "subtitle": subtitle})}]
    body["annotations"] = ann
    return body


def reapply_from_annotations(body: dict, tokens: dict, mode: str) -> bool:
    """Used by make_light_twin: re-resolve a role for the twin's mode. Returns True if a role was found."""
    ann = {a.get("name"): a.get("value") for a in body.get("annotations", [])}
    if "house.role" not in ann:
        return False
    args = json.loads(ann.get("house.role.args", "{}"))
    apply_role(body, tokens, mode, ann["house.role"], args["first"], args["dummy"], args.get("subtitle", " "))
    return True


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--page", required=True)
    ap.add_argument("--visual", required=True, help="visual id (folder name)")
    ap.add_argument("--role", default="financial-matrix")
    ap.add_argument("--first", required=True, help="first column metadata, e.g. \"dim layout.KPI Heading\"")
    ap.add_argument("--dummy", required=True, help="dummy measure metadata, e.g. \"*Measures*.Dummy Column\"")
    ap.add_argument("--subtitle", default=" ")
    ap.add_argument("--insert-dummy", action="store_true")
    a = ap.parse_args()
    rep = Path(a.report)
    meta = load(rep / "definition" / "pages" / "pages.json")
    pid = next((p for p in meta["pageOrder"]
                if load(rep / "definition" / "pages" / p / "page.json").get("displayName", "").strip() == a.page.strip()), None)
    if not pid:
        print(f"ERROR: page '{a.page}' not found")
        return 2
    vj = rep / "definition" / "pages" / pid / "visuals" / a.visual / "visual.json"
    body = load(vj)
    mode = "light" if a.page.strip().endswith(" Light") else "dark"
    dump(vj, apply_role(body, T.load(), mode, a.role, a.first, a.dummy, a.subtitle, a.insert_dummy))
    print(f"TABLE ROLE '{a.role}' · {a.visual} on '{a.page}' ({mode}) · then rebuild the twin (make_light_twin --replace)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
