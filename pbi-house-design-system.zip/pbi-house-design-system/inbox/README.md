# inbox/ · raw visual JSON drop zone (repo only, never packaged)

Drop one folder per visual:

```text
inbox/visuals/<short-name>/visual.json      ← copied from <Report>/definition/pages/<page>/visuals/<id>/
inbox/visuals/<short-name>/notes.txt        ← what it is · report · page
inbox/visuals/<short-name>/group.visual.json  (only if the visual sits in a group: parentGroupName)
```

Then: `python scripts/normalize_visual.py --in inbox/visuals/<short-name>/visual.json --id <family>/<variant>`
→ draft blueprint + findings in `assets/blueprints/<family>/`. Review, approve, test in Desktop, mark golden.

Raw files may contain report bindings and saved selections. They stay here and are excluded by `.skillignore`.
