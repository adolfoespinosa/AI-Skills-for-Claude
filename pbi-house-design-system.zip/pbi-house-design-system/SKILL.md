---
name: pbi-house-design-system
description: "Corporate Power BI design system (house style): tokens, Light/Dark twin pages, 1280x720 grid, page chrome, panels, KPI cards, charts, matrices, slicers, navigation, tooltips and design compliance checks. Use this skill whenever work changes how a Power BI report looks or behaves for its users, including restyling, tidying layouts or changing colours: creating or modifying dashboards, pages, visuals, layouts, themes or PBIP/PBIR formatting; designing KPI cards, matrices, charts, slicers, tooltips or navigation; building Light/Dark versions; redesigns, design reviews and design QA; and creating measures that will be displayed. Use it even if the user never says 'design'. Works together with powerbi-report-cli (writes PBIR) and semantic-model-authoring (owns DAX): this skill decides and verifies the house design, but never edits PBIR or business logic itself. Do not use for pure DAX, ETL, modelling, refresh, security (RLS) or performance work, or for data questions, when nothing visual changes."
metadata:
  version: "0.10.0"
  design_system_version: "0.9.0"
  compatible_with:
    powerbi-report-cli: "1.0.x (Design Brief contract_version 1)"
---

# Power BI House Design System

This skill is the **house design layer** for Power BI. It turns the company's design system into
decisions and checks. It complements other skills and does not replace them:

- **This skill** decides *what the report must look like* (tokens, layout, components, Light/Dark)
  and *verifies* the result (compliance).
- **`powerbi-report-cli`** writes and validates PBIR, previews and publishes.
- **`semantic-model-authoring`** owns measures, DAX, format strings and model changes.

> **Build status (v0.1.0).** References, tokens, themes and checkers are implemented. `check_compliance.py`
> automates 34 rules; every other rule is reported as NOT EVALUATED and must be checked manually or with
> `qa/visual-review.md`. Never invent values: if a value is not in `tokens/tokens.yaml`, ask.

---

## 1. Scope

**Use for:** new dashboards or pages, changes to visuals or layouts, themes, KPI cards, charts,
matrices, slicers, navigation, tooltips, titles, Light/Dark twins, redesigns, design reviews,
compliance reports, design documentation, and measures that will be displayed (format
standards only).

**Do not use for** (hand over to the owning skill): DAX logic, semantic model structure, Power
Query/M, ETL, Fabric items, refresh, performance, security, deployment, data questions.

---

## 2. Core rules (always apply, no file lookup needed)

| # | Rule | Ref |
|---|---|---|
| C1 | Use **design tokens only** (`tokens/tokens.yaml`). Never write a literal HEX, font size or pixel value that is not a token. If a value is missing, ask; do not invent it. | D2 |
| C2 | Canvas is **1280 × 720**. Tooltip pages use the approved tooltip sizes only. | LAYOUT |
| C3 | Grid C: **margin 12 · gutter 16 · 24 columns of 37 px**. `x = 12 + (n−1)·53` · `width = 37·s + 16·(s−1)`. Vertical bands: **header 8–72 · content 88–656 · bottom band 656–720**. | LAYOUT |
| C4 | **Bottom band** holds the filters (dropdowns and button-slicer groups) and most navigation, including the Light/Dark toggle at bottom right. Do not move filters to the top, even though `powerbi-report-cli` places them there by default. | PAGE |
| C5 | **Default mode is Dark.** Light is a hidden **twin page** `"<page> Light"`, reached through the 🌙/☀ button. Twins MUST stay identical in visuals, positions, fields, filters and bookmarks; only colour properties may differ. Any change to a page also applies to its twin. | MODE |
| C6 | **Orange `#F3B244` (Dark)** on numbers, bars or variance arrows means *negative*. On titles, decorative borders and hover it is an accent. Never colour a non-negative number orange. | COLOR |
| C7 | **Red `#C00D0D` (Light)** is reserved for negatives only: never for selection or accent. Selection in Light uses slate. | COLOR |
| C8 | **Blue `#336293`** only on light surfaces. Status has two states: positive = primary text colour, negative = orange (Dark) or red (Light). There is no green and no amber. | COLOR |
| C9 | KPI cards use the **new card visual (`cardVisual`)**. The legacy `card` is forbidden in new work. | KPI |
| C10 | Typography is **Segoe UI** (Regular / Semibold / Bold) on the 7-step scale **8 · 9 · 10 · 12 · 15 · 20 · 25 pt**, by role. Always write fonts as the **Power BI font stack** (`tokens › primitive.font_stack`, e.g. `'Segoe UI Bold', wf_segoe-ui_bold, helvetica, arial, sans-serif`), never the bare name. | TYPO, TYPO-006 |
| C11 | Drop shadow **only on the page header**. Containers use a 1 px border with radius 10. | PAGE/PANEL |
| C12 | Encode scenarios with **colour + line style**: ACT solid, FCT dashed, REF `#ADC0D4`. | CHART |
| C13 | **Never change business logic** for design reasons: no edits to measures, DAX, M, model, filters, field bindings or bookmarks targets unless the user explicitly asks. | — |
| C14 | **Never edit PBIR directly.** Produce a plan; `powerbi-report-cli` (authoring mode) executes it. The only exceptions are the deterministic scripts (`install_intro.py`, `install_header.py`, `apply_table_role.py`, `make_light_twin.py`, `bind_blueprint.py`), which run as part of the authoring step. | D1, D1a |
| C15 | **Never apply a rule violation silently.** Follow the conflict protocol (§4). | D7 |
| C16 | **Every report starts with the corporate Intro page** (Dark only, no twin): round RHG logo, world map, title "Title", page navigator. Install it with `scripts/install_intro.py`. It is the first and landing page. Only the title text may change. **Run `install_intro.py --refresh-nav` after adding or removing pages**, because the navigator buttons resize to the number of tabs. | PAGE-008/009/010 |
| C17 | **Corporate logos and icons come from `assets/logo` and `assets/icons`**: `logo-white.png` on Dark pages, `logo-blue.png` on Light twins. Never use other copies. | PAGE-003, ASSET-001 |
| C18 | **Reuse blueprints before writing visual JSON.** If `assets/blueprints/INDEX.md` lists the component, bind it with `scripts/bind_blueprint.py` (Dark page, then rebuild the twin). Never copy a raw dashboard visual. Styles listed in `tokens › component.visual_level` are ignored by themes and MUST be written on every visual of that type (SLICER-008/009). | D19 |
| C19 | **Every page except Intro carries the corporate header** (frame, rectangular logo, title "Title", empty badge). Install it with `scripts/install_header.py`; never draw it by hand. `make_light_twin.py` rebuilds it with Light colours. | PAGE-001, PAGE-011 |

Hex values in C6–C12 are listed for recognition only. When implementing, always reference the
semantic token.

---

## 3. Routing: what to read for each task

Read `references/boundaries-and-handoffs.md` once per session before the first create, modify
or review task. Then load **only** the files for the task:

| Task | Read |
|---|---|
| New report (always) / Intro or landing page | `components/intro-page.md` |
| New dashboard or page | `composition/dashboard-catalog.md` → `composition/page-templates.yaml` → `components/page-chrome.md` (header: `install_header.py`) → `components/panel.md` → `foundations/layout-grid.md` → the component files involved |
| Place, resize or align visuals | `foundations/layout-grid.md` |
| Any colour decision | `foundations/color.md` |
| Any text or title | `foundations/typography.md`, `components/text-titles.md` |
| KPI card | `components/kpi-card.md` |
| Chart | `components/charts.md` |
| Table or matrix | `components/table-matrix.md` (financial statements: role `financial-matrix` via `apply_table_role.py`), plus `data-driven-formatting.md` if rows are styled by a layout table |
| Slicer, filter, view selector, text tabs | `components/slicers-filters.md` |
| Any visual that may have a blueprint (all bottom-band slicers have one); adding a new blueprint from a dashboard | `assets/blueprints/INDEX.md` |
| Navigation, buttons, page names | `components/navigation.md` |
| Tooltip | `components/tooltips.md` |
| Light/Dark, twin pages | `foundations/modes.md` |
| Measures that will be displayed, number formats, K/M or currency toggles | `formatting-standards.md` |
| User request conflicts with a rule; exceptions | `priority-and-exceptions.md` |
| Review, redesign, before handoff or publish | `qa/compliance-protocol.md` (+ `qa/visual-review.md` with screenshots) |
| A step needs a concrete tool (MCP, CLI) | `integration/tooling.md` |
| Unsure how a component should look | `examples/<component>.md` (only then) |

Rules live in `yaml` blocks inside these files, with IDs `<DOMAIN>-<NNN>` (see the ID scheme in
the rule blocks). Cite rule IDs in every plan, brief and report. Core rules C1–C15 are summaries: in
plans and `remediation-plan.yaml` always cite the underlying domain rule (e.g. LAYOUT-003, not "C3").

---

## 4. Priority and conflict protocol

Priority ladder (highest first):

```text
P0 Platform limits → P1 Accessibility → P2 Corporate brand → P3 Semantic conventions
→ P4 Component standard → P5 Page template → P6 Generic guidance (incl. powerbi-report-cli design mode)
```

- House rules **always override** generic guidance from `powerbi-report-cli` design mode
  (tone catalogue, default canvas, filter placement, base theme).
- A **user request** is not a priority level. If it does not conflict with a rule, do it. If it
  conflicts:
  1. **Warn** in one sentence and name the rule ID.
  2. **Offer** 1–2 compliant alternatives.
  3. If the user still wants it, apply it **only within the requested scope** and record an
     exception in `_brief/exceptions.yaml` (schema in `priority-and-exceptions.md`).
- **P0** cannot be overridden: explain why. **P1 (ACCESS-\*)** rules cannot take an exception by
  default.
- An exception is never promoted to a global rule automatically.

---

## 5. Workflows

### A. New dashboard or page (greenfield)

1. Let `powerbi-report-cli` **planning** capture the requirements. Respect its approval gate.
2. **House constrain.** Pick the dashboard type and page template from the catalogue, and map
   measures to slots. Write `_brief/house-constraints.yaml` (from
   `assets/brief-templates/`): canvas, grid, bands, locked identity, theme, filters in the bottom
   band, twin-page requirement.
3. `powerbi-report-cli` **design** produces the `Design Brief:` within those constraints. Add the
   extension block:
   ```yaml
   house_system: { name: pbi-house-design-system, version: <x.y.z>, mode: dark,
                   template: <id>, twin: "<page> Light", rules_applied: [...], exceptions: [] }
   ```
4. **Pre-check the brief** against the Core rules and the component rules. Fix it before handoff.
5. **Model requests.** Format strings, K/M or currency toggles and SVG measures go to
   `_brief/model-requests.yaml` → `semantic-model-authoring`.
6. **Intro page first (new reports).** As part of authoring, run `scripts/install_intro.py`
   (`components/intro-page.md`). The title stays "Title" unless the user gives one. After the pages
   are built, run it again with `--refresh-nav` so the navigator fits the number of tabs.
7. `powerbi-report-cli` **authoring** builds each Dark page. Then create its Light twin with
   `scripts/make_light_twin.py --report <.Report> --page "<page>"`, which applies the Light override
   profile, swaps logo and toggle icons, and links both toggles. Logos come from `assets/logo/`.
   The header goes on every Dark page with `scripts/install_header.py` (C19); components with a blueprint (C18)
   are placed with `scripts/bind_blueprint.py` first.
8. **Compliance** (§6), then screenshot review through `powerbi-report-cli`. Publish only when
   the gate passes.

### B. Modify or redesign an existing report (brownfield)

1. Read `_brief/house.lock.yaml` and `_brief/exceptions.yaml` if they exist.
2. **Audit:** run compliance on the current state. On first audit of a legacy report, offer a
   **baseline**.
3. Write `_brief/remediation-plan.yaml`: for each change, the visual id, property path,
   current value → token, and rule ID. **Always include the twin page.** Show the plan to the
   user and get approval.
4. `powerbi-report-cli` **authoring** executes the plan.
5. Run **diff guard** (only formatting and position paths changed) + **twin check** + compliance.
   Return the report.

### C. Review / design QA only

Run compliance. Add a screenshot review if screenshots are available. Return the compliance
report. Do not change files.

### D. Small single-visual change

Use the minimal brief (`mode: brownfield`, `design_identity: unchanged`, one `change`, plus the
rule ID). The change still applies to the twin, and the visual is still re-checked.

---

## 6. Compliance gate

Scripts are run, not read. Only their output enters the context.

```bash
python ${CLAUDE_SKILL_DIR}/scripts/check_compliance.py --report "<path>/<name>.Report" --brief "<path>/_brief"
python ${CLAUDE_SKILL_DIR}/scripts/check_twins.py      --report "<path>/<name>.Report"
python ${CLAUDE_SKILL_DIR}/scripts/diff_guard.py       --before "<copy of the PBIP before>" --after "<PBIP folder>"
```

Report format (always this shape):

```text
DESIGN COMPLIANCE REPORT · Design System vX.Y.Z · Mode: Dark+Light
Status: PASSED | PASSED WITH WARNINGS | PASSED WITH WAIVERS | FAILED
Critical: [IDs + location]   Warnings: [...]   Waived: [ID → EXC-…]
Baseline: [n]   Passed: [n]   Not evaluated (manual): [IDs]
```

- Any **unwaived critical** → `FAILED` → do not hand off to publishing.
- **Not evaluated** items are listed explicitly, never counted as passed.
- Never claim PASSED without evidence. Rules the script does not automate are listed as NOT EVALUATED.
- Themes: register `assets/themes/corporate-dark.<ver>.json`; style Light twins with
  `assets/themes/light-overrides.<ver>.json` (overrides + role profiles). Rebuild with
  `python ${CLAUDE_SKILL_DIR}/scripts/build_themes.py` after any token change.

---

## 7. Outputs by task

| Task | Deliverable |
|---|---|
| Greenfield | `house-constraints.yaml` + Design Brief with the `house_system` block + `model-requests.yaml` (if needed) + compliance report |
| Brownfield | `remediation-plan.yaml` (approved) + compliance report + diff-guard result |
| Review | Compliance report (+ prioritised fix list with rule IDs) |
| Exception | Entry in `exceptions.yaml` (rule, scope, reason, alternatives offered, approver **role**, review date) |
| Design documentation | Generated from tokens and rule blocks; never hand-copied values |

---

## 8. Anti-patterns (do not)

- Duplicate `powerbi-report-cli` mechanics (PBIR schema, CLI commands) or its generic design
  catalogue in this skill.
- Change DAX, measures, model, M or ETL to achieve a visual effect. Request it through
  `model-requests.yaml` instead.
- Edit only one page of a twin pair.
- Hand-edit theme files in `assets/themes/`. They are generated from tokens.
- Use orange (Dark) or red (Light) for anything that is not negative, except orange on
  non-data accents (C6).
- Turn an exception into a new rule, or widen its scope.
- Report a check as passed when it was not run.
- Make unrequested "improvements" during a redesign. Change only what a rule or the user requires.
