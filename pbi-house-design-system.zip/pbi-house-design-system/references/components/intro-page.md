<!--
STATUS: v0.3 (2026-10-05)
PURPOSE: The corporate Intro page: a locked, Dark-only brand template installed in every report (PAGE-008/009/010).
LOADED: creating a new report or dashboard, adding/removing pages, auditing the first page, or any request about the Intro / landing page.
-->
# Intro Page (locked brand template, Dark only)

## 1. What it contains

The template is based on the Intro page of *Operational Report – Fabric*, reduced to what the house standard keeps:

| Element | Visual | Geometry (fixed) |
|---|---|---|
| Background | `shape` (full page, Dark surface) | 0,0 · 1280×720 |
| World map | `image` (Globe map) | 0,333 · 1103×388 |
| Round RHG logo (white, "Radisson Hotel Group") | `image` | 19,11 · 249×266 |
| Title | `textbox`, generic word **"Title"**, Segoe Bold 80 pt, white | 281,60 · 985×190 |
| Page navigator | `group` with 2 stacked `pageNavigator` layers (pill backgrounds + text) | x 980, y 240, w 287 · **height dynamic** |

Not included (removed by decision IN3): video-tutorial buttons, scrolling banner (`DynamicScroll`), version text,
"last update" card. The template therefore needs **no measures** from the semantic model.

| Item | Value |
|---|---|
| Template | `assets/templates/intro-page/` (page.json, 7 visual entries, 2 images, `intro.manifest.json`) |
| Installer | `scripts/install_intro.py` |
| Position | First page and landing page, display name `Intro` |
| Mode | **Dark only.** No Light twin, no mode toggle (exempt from MODE-002/005) |

## 2. Dynamic navigation buttons

The page navigator lists the report's visible pages automatically (hidden pages, tooltips and the Intro itself are
not listed; Light twins are hidden, so they never appear). Its height adapts to the number of tabs so the buttons keep
a good proportion:

```text
n = visible, non-tooltip pages except Intro
h = clamp( (469 − (n−1)·5) / n , 28 , 48 )   px per button (cell padding 5)
H = n·h + (n−1)·5                           navigator height, top fixed at y 240, max 469
```

| Tabs (n) | Button h | Navigator H |
|---|---|---|
| 3 | 48 | 154 |
| 6 | 48 | 313 |
| 10 | 42.4 | 469 |
| 14 | 28.9 | 469 |
| 17+ | 28 | 469 (capped) |

The installer sizes it at install time. **Run `--refresh-nav` after every batch that adds or removes pages.**

## 3. How to install and refresh

```bash
# new report (part of the powerbi-report-cli authoring step, D1a)
python ${CLAUDE_SKILL_DIR}/scripts/install_intro.py --report "<path>/<name>.Report" [--title "Title"]
# after adding/removing pages
python ${CLAUDE_SKILL_DIR}/scripts/install_intro.py --report "<path>/<name>.Report" --refresh-nav
```

Leave the title as **"Title"** unless the user gives the report title. It is meant to be edited later.

## 4. Rules

```yaml
- id: PAGE-008
  title: Every report starts with the Dark-only Intro page
  status: active
  since: 0.2.0
  severity: critical
  priority: P2
  modes: [dark]
  applies_to: [report]
  statement: "The first page of every report MUST be the Intro page installed from assets/templates/intro-page (display name 'Intro'). It MUST be the landing page and MUST NOT have a Light twin."
  check: auto
  exceptions: allowed

- id: PAGE-009
  title: Intro page matches the template
  status: active
  since: 0.2.0
  severity: critical
  priority: P2
  modes: [dark]
  applies_to: [page]
  statement: "The Intro page MUST keep the template structure (same visual types, positions and widths; navigator height is dynamic). Only the title text may differ. Every Intro visual MUST have container title and background switched off, so no visual hides the logo or the title (z-order: background 0 · map 1000 · logo 2000 · title 3000 · navigator 7000)."
  check: auto
  exceptions: allowed

- id: PAGE-010
  title: Navigator height fits the number of tabs
  status: active
  since: 0.3.0
  severity: warning
  priority: P4
  modes: [dark]
  applies_to: [page]
  statement: "The Intro navigator group height MUST equal H(n) from section 2 for the current number of visible pages (tolerance 2 px). Fix with install_intro.py --refresh-nav."
  check: auto
  exceptions: allowed
```

## 5. Exemptions

The Intro keeps its original geometry, fonts and display option. The checker **does not evaluate** grid (LAYOUT-*),
typography (TYPO-*), colour (COLOR-*), KPI, naming (NAV-006) or twin rules (MODE-*) on this page. It evaluates
PAGE-008/009/010 instead. To change the Intro design, update the template in the skill (new skill version).
Never edit it per report.
