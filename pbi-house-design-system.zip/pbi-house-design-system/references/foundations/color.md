<!--
STATUS: v0.1 (Step 6, batch 1). Values live in tokens/tokens.yaml (Step 7). This file holds meaning and rules only.
PURPOSE: Colour semantics, status and scenario encoding, COLOR-* and colour-related ACCESS-* rules.
LOADED: any task that sets, changes or reviews a colour.
-->
# Colour

## 1. Semantic roles

Always implement through these token names. Mode values are resolved from `tokens.yaml`.

| Token | Role | Inverts between modes? |
|---|---|---|
| `color.surface.page` | Page background | Yes |
| `color.surface.outspace` | Area outside the canvas | Yes |
| `color.surface.panel` | Panel and chart background | Yes |
| `color.surface.header` | Page header band (+ `shadow.header`) | Yes |
| `color.surface.panel_title` | Panel title bar | **Yes, contrasts with the panel in both modes** |
| `color.surface.table` | Table body | Yes |
| `color.surface.data_label` | Data label background (waterfall) | Yes |
| `color.tooltip.background` / `color.tooltip.text` | Tooltips: **dark in both modes** (Q-T1) | No |
| `color.surface.total_row` / `color.text.on_total_row` | P&L total band (from `DIM_Layout`) | No |
| `color.surface.highlight_row` / `color.text.on_highlight_row` | P&L highlighted band (from `DIM_Layout`) | No |
| `color.text.primary` | Default text, positive values | Yes |
| `color.text.on_panel_title` | Text on the panel title bar | Yes |
| `color.text.panel_subtitle` | Subtitle row on the title bar | Yes |
| `color.text.period` | Period next to the page title | Yes |
| `color.text.tab_active` / `tab_inactive` | Text tabs | Yes |
| `color.border.container` | Container border | Yes |
| `color.gridline` | Gridlines | No |
| `color.accent.primary` | Non-data accent: titles, decorative outlines, hover | Yes (Dark: orange) |
| `color.info.on_light` | Blue information text, **light surfaces only** | No |
| `color.status.positive` | Positive / neutral value (= `text.primary`) | Yes |
| `color.status.negative` | Negative for the business | Yes (Dark: orange · Light: red) |
| `color.selection.fill` / `selection.text` | Selected state of controls | Yes |
| `color.scenario.actual` | ACT | Yes |
| `color.scenario.forecast` | FCT (same colour as ACT, dashed) | Yes |
| `color.scenario.reference` | REF = BUD / LY / TGT | No |
| `color.waterfall.increase` / `decrease` / `total` | Alias → `status.positive` / `status.negative` / `scenario.reference` | — |

There is no `status.warning` and no green. Do not introduce them without a new design system version.

## 2. Rules

```yaml
- id: COLOR-001
  title: Colours come from tokens only
  status: active
  since: 0.1.0
  severity: critical
  priority: P2
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Every effective colour (theme default or visual override) MUST equal a token value of the active mode. Colours outside the token set are forbidden."
  expect:
    - effective_color_in: "{tokens.all_color_values[mode]}"
  check: auto
  exceptions: allowed
  rationale: "Single source of truth (D2); removes drift colours found in the corpus."

- id: COLOR-002
  title: Prefer theme over per-visual colour overrides
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark]
  applies_to: ["*"]
  statement: "On Dark pages, a visual SHOULD NOT override a colour whose value equals the theme default for that property. Light pages are exempt (their overrides are the Light profile, see MODE-003)."
  expect:
    - redundant_override: false
  check: auto
  exceptions: allowed

- id: COLOR-003
  title: Dark - orange on data means negative
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark]
  applies_to: [tableEx, pivotTable, cardVisual, lineChart, waterfallChart, barChart, clusteredBarChart, columnChart, clusteredColumnChart, areaChart]
  statement: "On data elements (values, labels, bars, markers, variance arrows), color.status.negative MUST only be applied through a condition that evaluates to negative (conditional formatting rule or measure-driven colour)."
  expect:
    - data_object_color_eq: "{color.status.negative}"
      requires: conditional_binding
  check: assisted
  exceptions: allowed
  rationale: "Decision COLOR-R1."

- id: COLOR-004
  title: Dark - orange as accent only on non-data elements
  status: active
  since: 0.1.0
  severity: warning
  priority: P3
  modes: [dark]
  applies_to: ["*"]
  statement: "color.accent.primary MAY be used only on: titles, decorative outlines/borders, icons, hover states. It MUST NOT be used as a static colour on values, labels or data marks."
  expect:
    - accent_allowed_objects: [title, subTitle, outline, border, icon, "fill[hover]", "text[hover]"]
  check: auto
  exceptions: allowed

- id: COLOR-005
  title: Never orange on a non-negative number
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark]
  applies_to: [tableEx, pivotTable, cardVisual, "*Chart"]
  statement: "A static (unconditional) orange MUST NOT be applied to values, data labels or callout values."
  expect:
    - static_color_on_data_objects_not: "{color.status.negative}"
  check: auto
  exceptions: allowed

- id: COLOR-006
  title: Light - red is reserved for negatives
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [light]
  applies_to: ["*"]
  statement: "color.status.negative (Light) MUST only appear through a negative condition on data elements. It MUST NOT be used for selection, hover, accent or decoration."
  expect:
    - status_negative_only_on: conditional_data
  check: auto
  exceptions: allowed
  rationale: "Decision R1 (mirror of COLOR-R1)."

- id: COLOR-007
  title: Selection uses selection tokens
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [listSlicer, slicer, advancedSlicerVisual, actionButton]
  statement: "Selected states MUST use color.selection.fill / color.selection.text (selected = inverse of surface)."
  expect:
    - "selector[selected]": "{color.selection.*}"
  check: auto
  exceptions: allowed

- id: COLOR-008
  title: Blue only on light surfaces
  status: active
  since: 0.1.0
  severity: critical
  priority: P1
  modes: [dark, light]
  applies_to: ["*"]
  statement: "color.info.on_light MUST only be used on text whose resolved background is a light surface (surface.panel_title in Dark; page, panel or table surfaces in Light)."
  expect:
    - background_of(info.on_light) in: [light_surfaces]
  check: auto
  exceptions: forbidden

- id: COLOR-009
  title: Two-state status, theme sentiment keys aligned
  status: active
  since: 0.1.0
  severity: warning
  priority: P3
  modes: [dark, light]
  applies_to: [theme]
  statement: "Theme keys good / bad / neutral MUST map to status.positive / status.negative / text.primary. No green, no amber."
  expect:
    - theme.good: "{color.status.positive}"
    - theme.bad: "{color.status.negative}"
    - theme.neutral: "{color.text.primary}"
  check: auto
  exceptions: forbidden

- id: COLOR-010
  title: Scenario encoding by colour and line style
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [lineChart, areaChart, comboChart]
  statement: "ACT MUST be solid in scenario.actual; FCT MUST be dashed in scenario.forecast; REF (BUD/LY/TGT) MUST use scenario.reference. Scenario is identified by the measure suffix (_ACT, _FCT, _REF/_BUD/_LY/_TGT)."
  expect:
    - series_suffix_map: { ACT: { color: "{color.scenario.actual}", style: solid },
                           FCT: { color: "{color.scenario.forecast}", style: dashed },
                           REF: { color: "{color.scenario.reference}" } }
  check: assisted
  exceptions: allowed

- id: COLOR-011
  title: Waterfall sentiment colours
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [waterfallChart]
  statement: "sentimentColors MUST be increase = waterfall.increase, decrease = waterfall.decrease, total = waterfall.total."
  expect:
    - sentimentColors.increaseFill: "{color.waterfall.increase}"
    - sentimentColors.decreaseFill: "{color.waterfall.decrease}"
    - sentimentColors.totalFill: "{color.waterfall.total}"
  check: auto
  exceptions: allowed

- id: COLOR-012
  title: Conditional formatting uses tokens
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Colours inside conditional formatting rules, gradients and measure-driven colours MUST be token values. Measures returning colours MUST return status/scenario token values."
  expect:
    - cf_colors_in: "{tokens.all_color_values[mode]}"
  check: assisted
  exceptions: allowed
```

## 3. Accessibility (colour)

```yaml
- id: ACCESS-001
  title: Text contrast
  status: active
  since: 0.1.0
  severity: critical
  priority: P1
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Text MUST reach a contrast ratio of 4.5:1 against its resolved background; 3:1 for large text (>= 18 pt regular or >= 14 pt bold)."
  expect:
    - contrast_text_normal: ">= 4.5"
    - contrast_text_large: ">= 3.0"
  check: auto
  exceptions: forbidden

- id: ACCESS-002
  title: Non-text contrast
  status: active
  since: 0.1.0
  severity: critical
  priority: P1
  modes: [dark, light]
  applies_to: ["*Chart", slicer, advancedSlicerVisual, actionButton]
  statement: "Lines, bars, markers and control boundaries needed to understand content MUST reach 3:1 against the adjacent background."
  expect:
    - contrast_graphic: ">= 3.0"
  check: auto
  exceptions: forbidden

- id: ACCESS-003
  title: Colour is never the only signal
  status: active
  since: 0.1.0
  severity: critical
  priority: P1
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Negative values MUST also show a minus sign or a direction icon; scenarios MUST also differ by line style or label."
  check: assisted
  exceptions: forbidden
```

## 4. Accepted corporate deviations (design-system level)

The design system owner decided (2026-10-04) to **keep the corporate colours** for the pairs below, even
though they are below WCAG AA. They form a **closed list**. These exact token pairs, in these roles, are
reported as `ACCEPTED-DEVIATION` instead of critical. Any other pair that fails ACCESS-001/002 is still
**critical, with no exception possible** (D9).

```yaml
accepted_deviations:
  - id: AD-001
    rule: ACCESS-001
    role: "negative values as text (Dark)"
    pairs:
      - { fg: color.status.negative, bg: color.surface.page,  mode: dark }
      - { fg: color.status.negative, bg: color.surface.table, mode: dark }
    ratio: 4.20
    decided: 2026-10-04
    review_by: 2027-04-04
  - id: AD-002
    rule: ACCESS-001
    role: "panel subtitle (Light) and highlight-row text"
    pairs:
      - { fg: color.text.panel_subtitle,   bg: color.surface.panel_title,   mode: light }
      - { fg: color.text.on_highlight_row, bg: color.surface.highlight_row, mode: [dark, light] }
    ratio: 4.20
    decided: 2026-10-04
    review_by: 2027-04-04
  - id: AD-003
    rule: ACCESS-001
    role: "inactive text tabs"
    pairs:
      - { fg: color.text.tab_inactive, bg: color.surface.panel_title, mode: [dark, light] }
    ratio: "2.35 (dark) / 1.68 (light)"
    decided: 2026-10-04
    review_by: 2027-04-04
  - id: AD-004
    rule: ACCESS-001
    role: "P&L total rows (DIM_Layout total band)"
    pairs:
      - { fg: color.text.on_total_row, bg: color.surface.total_row, mode: [dark, light] }
    ratio: 2.93
    decided: 2026-10-04
    review_by: 2027-04-04
  - id: AD-005
    rule: ACCESS-002
    role: "REF line in Light charts"
    pairs:
      - { fg: color.scenario.reference, bg: color.surface.panel, mode: light }
    ratio: 1.49
    decided: 2026-10-04
    review_by: 2027-04-04
```

Rules for this list:
- Only the design system owner can add entries, and only in a new design system version. It is not a
  per-report exception.
- An accepted deviation does **not** permit reusing the same colour in another role. For example, AD-001
  does not allow orange body text.
- At `review_by`, the compliance report reminds the owner. Remediation candidates are recorded in
  `docs/decision-log.md` (A1–A5).
- ACCESS-003 (colour is never the only signal) becomes **more** important for these pairs. Negatives keep
  the minus sign; REF keeps its line style or label.
