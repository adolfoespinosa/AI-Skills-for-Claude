<!--
STATUS: v0.1 (Step 6, batch 1). Sizes and weights resolve from tokens/tokens.yaml › semantic.type (Step 7).
PURPOSE: Font family, type scale, role mapping, TYPO-* rules and ACCESS-004.
LOADED: any task that creates or changes text.
-->
# Typography

## 1. Family

| Token | Value | Notes |
|---|---|---|
| `font.render` | Segoe UI (Regular / Semibold / Bold) | Renders in Desktop and the Service |
| `font.brand` | **Gotham** (official corporate font) | Documentation, PowerPoint and print only. **Not used in Power BI visuals**: Gotham is not a Service-supported font and would fall back unpredictably (P0) |

## 2. Scale (canvas 1280 × 720)

Seven steps only: **8 · 9 · 10 · 12 · 15 · 20 · 25 pt**.

| Role token | Size | Weight | Colour token | Used for |
|---|---|---|---|---|
| `type.page_title` | 25 | Semibold | `text.primary` (Light) / `accent.primary` (Dark) | One title per page, header band |
| `type.kpi_hero` | 25 | Semibold | `text.primary` | Hero KPI value |
| `type.kpi_large` | 20 | Semibold | `text.primary` | Standard KPI value |
| `type.kpi_medium` | 15 | Semibold | `text.primary` | Compact KPI value, KPI card title |
| `type.period` | 15 | Semibold | `text.period` | Period next to the page title |
| `type.kpi_small` | 12 | Semibold | `text.primary` | Context cards in the header |
| `type.panel_title` | 10 | Bold | `text.on_panel_title` | Panel title bar, visual titles |
| `type.control` | 9 | Regular; **Bold when selected** | selection tokens | Button slicers, text tabs, list-slicer headers, buttons |
| `type.slicer_header` | 9 | Semibold | `text.primary` | Dropdown slicer headers ("Period", "Year"), decision SL1 |
| `type.subtitle` | 9 | Regular | `text.panel_subtitle` | Subtitle row ("Mth – Jun 2026", "YTD") |
| `type.table_header` | 8 | Bold | `text.on_panel_title` | Table and matrix column headers |
| `type.table_cell` | 8 | Regular (total rows Bold) | `text.primary` | Financial matrices (P&L, `pivotTable`, dense `tableEx`) |
| `type.table_cell_list` | 10 | Regular | `text.primary` | List tables (`tableEx`) with ≤ 8 columns: hotel lists, rankings |
| `type.label` | 8 | Regular | `text.primary` | Axis labels, data labels, legend, slicer items |
| `type.footnote` | 8 | Regular | `text.tab_inactive` | Notes, source, refresh info |

Weights are derived from the corpus (Bold 357 / Semibold 277 / Regular 158 uses). Rows marked as proposals
can be adjusted in Step 7.

## 3. Rules

```yaml
- id: TYPO-006
  title: Fonts written as Power BI font stacks
  status: active
  since: 0.7.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: ["*", theme]
  statement: "Every fontFamily / fontFace in visuals and themes MUST be the Power BI font stack from tokens › primitive.font_stack (e.g. 'Segoe UI Bold', wf_segoe-ui_bold, helvetica, arial, sans-serif). A bare name ('Segoe UI Bold') renders with a wrong weight/shape in Desktop (FS1, tested 2026-10-07). Text-box text runs keep Desktop's own names."
  check: auto
  exceptions: forbidden

- id: TYPO-001
  title: Segoe UI only
  status: active
  since: 0.1.0
  severity: critical
  priority: P2
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Every effective font family MUST be Segoe UI, Segoe UI Semibold or Segoe UI Bold. Arial, Calibri, Verdana, DIN (wf_standard-font), Courier and Segoe UI Light are forbidden."
  expect:
    - font_family_in: ["{font.render_regular}", "{font.render_semibold}", "{font.render_bold}"]
  check: auto
  exceptions: allowed

- id: TYPO-002
  title: Sizes from the scale only
  status: active
  since: 0.1.0
  severity: critical
  priority: P4
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Every effective font size MUST be one of the 7 scale steps."
  expect:
    - font_size_in: [8, 9, 10, 12, 15, 20, 25]
  check: auto
  exceptions: allowed

- id: TYPO-003
  title: Size and weight follow the role
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Text MUST use the size and weight of its role token (section 2), e.g. panel titles = type.panel_title."
  expect:
    - role_map: "section 2"
  check: assisted
  exceptions: allowed

- id: TYPO-004
  title: One page title per page
  status: active
  since: 0.1.0
  severity: warning
  priority: P5
  modes: [dark, light]
  applies_to: [textbox]
  statement: "Each page MUST have exactly one text element using type.page_title, placed in the header band."
  check: auto
  exceptions: allowed

- id: TYPO-005
  title: Textbox height avoids scrollbars
  status: active
  since: 0.1.0
  severity: warning
  priority: P0
  modes: [dark, light]
  applies_to: [textbox]
  statement: "Textbox height MUST be >= max(18, ceil(fontSize * 25/16)) + padding_top + padding_bottom, otherwise Desktop renders a scrollbar."
  check: auto
  exceptions: forbidden

- id: ACCESS-004
  title: Minimum font size
  status: active
  since: 0.1.0
  severity: critical
  priority: P1
  modes: [dark, light]
  applies_to: ["*"]
  statement: "No text MAY be smaller than 8 pt on a 1280 × 720 canvas."
  expect:
    - font_size_min: 8
  check: auto
  exceptions: forbidden
```

## 4. Decisions
- T1 (2026-10-04): two table cell roles, 8 pt (financial matrices) and 10 pt (lists).
- T2: corporate font Gotham (`font.brand`); Segoe UI renders in Power BI (`font.render`).
- T3: page title Semibold.
