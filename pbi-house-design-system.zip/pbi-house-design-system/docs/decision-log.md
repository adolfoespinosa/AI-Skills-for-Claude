# Decision Log — Power BI House Design System Skill

Estado: **Step 1 cerrado** · Fecha: 2026-10-04 · Design System: v0.0 (pre-captura)

> Este fichero vivirá en la raíz del repo de la skill (`/docs/decision-log.md`).
> No forma parte del paquete `.skill`: Claude no lo necesita para trabajar, es memoria del proyecto.

---

## Decisiones cerradas

| ID | Decisión | Elección | Consecuencia principal |
|---|---|---|---|
| D1 | ¿La House skill edita PBIR? | **No.** Genera `remediation-plan.yaml`; `powerbi-report-cli` (authoring) lo ejecuta | La skill no contiene conocimiento de esquema PBIR. Revisable a "híbrida" (lista cerrada de propiedades) más adelante |
| D2 | Formato de tokens | **YAML en 3 niveles** (primitive → semantic con light/dark → component) → JSON generado | `tokens/tokens.yaml` es la única fuente de verdad. Prohibido usar literales en reglas |
| D3 | Dónde viven las reglas | **Bloques YAML dentro de cada `.md` de componente** | `check_compliance.py` parsea los bloques ```yaml de `references/**`. No hay registro de reglas aparte |
| D4 | Tema JSON | **Generado** desde tokens con `build_themes.py`, conservando las protecciones de `base.json` de report-cli | Los temas en `assets/themes/` no se editan a mano. Nombre versionado: `corporate-<mode>.<ver>.json` |
| D5 | Canvas | **1280 × 720** (estándar inicial) | **Sustituye** el valor por defecto de report-cli (1920 × 1080): debe ir en `house-constraints.yaml`. Escala tipográfica pensada para 1280 |
| D6 | Grid | **Base de 8 px y 24 columnas** + bandas verticales de altura fija | Ver parámetros candidatos abajo |
| D7 | Excepciones | **En el PBIP** (`_brief/exceptions.yaml`), nunca en la skill | El checker las muestra como WAIVED, nunca como PASSED |
| D8 | Prioridades | P0 Plataforma > P1 Accesibilidad > P2 Marca > P3 Semántica > P4 Componente > P5 Plantilla > P6 Guía genérica / Claude | La petición del usuario no es un nivel: entra por la vía de excepción |
| D9 | ¿Excepción sobre accesibilidad? | **No por defecto** (configurable) | Reglas ACCESS-* con `exceptions: forbidden` |
| D10 | Ingeniería inversa | **Automática** con `extract_pbir.py` + sesión de decisiones | Umbrales iniciales: ≥80% regla candidata · 40–80% preguntar · <40% excepción o deriva |
| D11 | PBIR-Legacy | **Convertir a PBIR** antes de auditar | El checker solo soporta PBIR (`definition/`) |
| D12 | Distribución | **Repo git** como fuente → paquete `.skill` | Tests y CHANGELOG en el repo; excluidos del paquete |

### Decisiones del Step 3, ronda 1 (2026-10-04)

| ID | Decisión |
|---|---|
| D6b | Grid **opción C**: margen 12 · gutter 16 · 24 columnas de 37 px · ancho útil 1256. Bandas verticales: 8–72 · 88–656 · 656–720 |
| Q2 | `#ADC0D4` **oficial** → `scenario.reference` (REF/BUD) y total del waterfall |
| Q3 | Dark: `status.positive` = blanco · `status.negative` = naranja `#F3B244` · sin verde · `status.warning` no definido (no se usa) |
| Q4 | KPI cards unificadas en `cardVisual` (card nueva); las legacy pasan al baseline |
| Q5 | Banda inferior = filtros + la mayor parte de la navegación (obligatorio, sustituye el valor por defecto de report-cli) |

### Decisiones del Step 3, ronda 2 (2026-10-04)

| ID | Decisión |
|---|---|
| COLOR-R1 | Naranja (Dark): números, barras y flechas de variación = negativo; títulos, bordes decorativos y hover = acento; nunca en un número no negativo |
| D16 | Light/Dark = **páginas gemelas** (`<página>` + `<página> Light` oculta); el botón 🌙/☀ navega entre ellas. Tema = Dark; Light = perfil de overrides generado desde tokens. Regla MODE-001 de paridad entre gemelas |
| P5 | Negativo Light = `#C00D0D` |
| P6 | Sombra solo en la cabecera de página |
| P4 | Azul `#336293`: solo sobre superficies claras |

### Decisiones del Step 3, ronda 3 (cierre) (2026-10-04)

| ID | Decisión |
|---|---|
| R1 | Selección en Light = `#425463`; el rojo `#C00D0D` queda reservado a negativos (espejo de COLOR-R1) |
| R2 / D15 | Modo por defecto = **Dark** |
| R3 | Pestañas inactivas: Dark `#8E98A1` · Light `#687682`; se elimina `#B2B2B2` en ese rol |
| R4 | Gris unificado `#B1B3B3` (sustituye a `#B2B2B2` en todos los usos) |
| R5 | `scenario.reference` = `#ADC0D4` en ambos modos |

**Step 3 cerrado.** Especificación de referencia: `docs/discovery/design-system-draft-v0.3.md` + este registro.

### Decisiones del Step 4 (asumidas por defecto, revisables)

| ID | Decisión |
|---|---|
| D13 | Ficheros de la skill en **inglés**; conversación en español |
| D14 | Nombre provisional: `pbi-house-design-system` (renombrable antes de empaquetar) |
| RID | Sistema de IDs de reglas v1.0 → `docs/rule-id-system.md` (17 dominios; el modo es un atributo) |

### Decisiones del Step 6, tanda 1 (2026-10-04)

| ID | Decisión |
|---|---|
| A1–A5 | Se **mantienen los colores corporativos** en los 5 pares por debajo de WCAG AA → lista cerrada de *accepted deviations* AD-001…AD-005 (nivel Design System, revisión 2027-04-04). Cualquier otro fallo de contraste sigue siendo critical sin excepción (D9). Candidatos de remediación guardados: A1 `#F5BE60` · A2 `#B9C9DA` · A3 `#53565A`/`#CDD1D4` · A4 `#687682` · A5 línea `#687682` |
| T1 | Dos tamaños de celda: 8 pt (matrices financieras) y 10 pt (listas) |
| T2 | Fuente corporativa **Gotham** (`font.brand`, solo documentación); Power BI usa Segoe UI (`font.render`) |
| T3 | Título de página Semibold |

### Decisiones del Step 6, tanda 2 (2026-10-04)

| ID | Decisión |
|---|---|
| PC1 | Todos los botones de la banda inferior **50 × 50** (button slicers, iconos, toggle) a y 663; desplegables h 56 a y 660; separación 16 (gutter); cluster derecho alineado a x 1268 (toggle en x 1218). Exención LAYOUT-003/004 en la banda inferior salvo el primer elemento |
| PN1 | Título de panel: izquierda en tablas, centrado en gráficos y rejillas KPI (PANEL-007) |
| N1 | Prefijo emoji sí, espacios iniciales no; jerarquía en `house.lock.yaml › page_hierarchy` (NAV-006) |
| TP1 | Tooltips: small 176 × 48 · medium 320 × 320 |
| TX1 | Sentence case en títulos de panel, Title Case en nombres de página (TEXT-006) |

### Decisiones del Step 6, tanda 3 (2026-10-05)

| ID | Decisión |
|---|---|
| F1 | Importes con `#,##` (el cero se muestra vacío, intencionado) |
| T-STATEMENT | Plantilla P&L aprobada: matriz span 12 (620) + gráficos span 12 (620) |

**Step 6 cerrado** (21 referencias, 106 reglas).

### Step 7 (2026-10-05)

| ID | Decisión |
|---|---|
| TK1 | `tokens.yaml` v0.1.0: 14 primitivos de color, 39 tokens semánticos de color (paridad dark/light), 14 roles tipográficos, layout, componentes y 18 pares de contraste |
| TK2 | Paleta categórica de datos **provisional** (CH1), sin colores de estado |
| TK3 | `check_tokens.py` PASSED · `check_contrast.py` PASSED (36 combinaciones: 26 PASSED + 10 ACCEPTED-DEVIATION, 0 FAILED) |

### Step 8 (2026-10-05)

| ID | Decisión |
|---|---|
| TH1 | `dataColors[0..7]`, foreground y background **bloqueados** (`component.theme_compat`): los visuales existentes los referencian por ColorId. Reordenarlos = cambio MAJOR. Nuevo primitivo `grey_mid #97999B` solo por compatibilidad |
| TH2 | Light override profile = diferencias de propiedades + **perfiles por rol** (pestañas de texto, contorno de KPI tile), porque un tema no distingue roles del mismo visualType |
| TH3 | Desplegables rellenos en ambos modos (`control.dropdown_*`), observado en las gemelas |
| TH4 | Iconos de botón en Dark = `accent.primary` (naranja, decorativo, COLOR-004), como en el tema actual |
| Q-T1 | Tooltips **oscuros en ambos modos** (`color.tooltip.background/text`) |
| TH5 | Etiquetas del eje de valores = `text.primary` (el gris del corpus no cumple contraste y no está en la lista AD) |

### Step 9 (2026-10-05)

| ID | Decisión |
|---|---|
| CK1 | `check_compliance.py` automatiza 27 reglas; el resto se reporta NOT EVALUATED |
| CK2 | Hover de botones de filtro = `hover.control` (gris `#B1B3B3`, ambos modos) y press = `press.control`, como en el corpus |
| CK3 | Corrección: `slate_ink_40` = `#989A9C` (valor real del corpus) |
| CK4 | Las gemelas pueden sustituir medidas `<X>` por `<X> Light` (iconos por modo); los nombres de gemelas se comparan normalizando espacios dobles |
| CK5 | Tests: 24/24 (estáticos, 16 fixtures sintéticos, gemelas, diff guard); 10 evals de comportamiento + 16 de activación |

### Step 10 (2026-10-05)

| ID | Decisión |
|---|---|
| V1 | Evals con/sin skill: 18/18 frente a 4/18 expectativas (#2, #3, #5, #7) |
| V2 | Descripción ajustada (restyling/colores incluidos; RLS y preguntas de datos excluidas), 1006 caracteres, `quick_validate` válido |
| V3 | En los planes se citan reglas de dominio, no los números de regla básica (C1–C15) |
| V4 | Paquete `.skill` v0.1.0 sin `docs/`, `tests/` ni CHANGELOG. Brechas G1–G7 y roadmap en `docs/validation-report.md` |

### v0.2.0 · tras la primera prueba real (2026-10-05)

| ID | Decisión |
|---|---|
| LG1 | Logos corporativos incluidos en `assets/logo/` (PNG/JPG de los informes de referencia): `logo-white.png` (Dark), `logo-blue.png` (Light), `logo-black.jpg` (impresión), `icon-white.png`, `icon-ww.png`. Iconos en `assets/icons/` (luna, sol, filtros, play, home). Los SVG oficiales siguen pendientes (G1) |
| IN1 | **Página Intro obligatoria** en todo informe: copia exacta de la Intro de *Operational Report – Fabric* (`assets/templates/intro-page`). Es la primera página y la de aterrizaje. Solo cambian título (2 partes), versión y enlace al tutorial. Reglas PAGE-008/009. Exenta de las reglas de grid, tipografía, color, nombres y gemelas |
| D1a | Matiz a D1: la Intro la instala un script determinista (`install_intro.py`) dentro del paso de authoring. Es una copia de plantilla, no una decisión de diseño. El resto de cambios PBIR siguen en `powerbi-report-cli` |
| IN2 | Las medidas `Last_update` (requiere `AUX_LastUpdate`) y `DynamicScroll` se piden al modelo mediante `model-requests.yaml`. El script nunca toca el modelo |

### v0.3.0 · Intro simplificada (2026-10-05)

| ID | Decisión |
|---|---|
| IN3 | Intro v2: **solo** fondo, mapa del mundo, logo redondo RHG (blanco), título genérico "Title" y navegador de páginas. Se eliminan de la skill el botón de tutorial, `DynamicScroll`, el texto de versión y la tarjeta "Last update". Ya no necesita ninguna medida del modelo (IN2 queda obsoleta) |
| IN4 | Navegador con **altura dinámica**: h = clamp((469−(n−1)·5)/n, 28, 48) por botón, H = n·h + (n−1)·5, arriba en y 240. Se recalcula con `install_intro.py --refresh-nav` (regla PAGE-010) |
| IN5 | La Intro es **solo Dark**: sin gemela Light ni botón de modo. Una página "Intro Light" es un fallo de PAGE-008 |

### v0.4.0 · Testbed (2026-10-06)

| ID | Decisión |
|---|---|
| TB1 | PBIP de prueba **HouseTest** con datos 100 % ficticios (12 hoteles inventados), generado por `tests/testbed/build_testbed.py` solo con la skill. Forma parte de `run_tests.py` (compliance y gemelas PASSED) |
| TB2 | Nuevo `scripts/make_light_twin.py` (determinista, D1a): duplica la página Dark como gemela Light, aplica el perfil Light y los roles, cambia logo e icono y enlaza los toggles en ambas direcciones |
| TB3 | Ajustes del checker detectados por el testbed: `sentimentColors.decreaseFill` en Light no infringe COLOR-006 (negativo por definición); `check_twins` ignora los colores dentro de los textos |

### v0.4.1 · Corrección tras la prueba en Desktop (2026-10-06)

| ID | Decisión |
|---|---|
| FX1 | Causa raíz: el tema activa `background.show` y `title.show` en `"*"`. En la Intro, el fondo del shape a pantalla completa (z 5000) tapaba el logo (z 3000) y el título (z 4000), y el navegador heredaba una barra de título |
| FX2 | Plantilla Intro: título, fondo y cabecera de visual desactivados explícitamente en cada visual; z-order normalizado (fondo 0 · mapa 1000 · logo 2000 · título 3000 · navegador 7000). PAGE-009 lo verifica |
| FX3 | Tema: `pageNavigator` / `bookmarkNavigator` sin título, fondo ni borde; `shape` sin fondo de contenedor; `image` sin cabecera. Nueva regla **NAV-007** (crítica, sin excepciones): los navegadores nunca muestran título |

### PENDIENTE (no aplicado) · Orden de capas de la Intro (2026-10-06)

| ID | Pendiente | Estado |
|---|---|---|
| BL1 | Orden del panel de selección (de delante a atrás): **Page Navigator** (grupo: *Page navigator Buttons* delante de *Page Navigator custom*) → **Shape** → **Title** ("Operational Report title") → **Radisson Logo** → **World map** (al fondo). Afecta a la plantilla `intro-page` (z-order), a PAGE-009 y a `intro-page.md` | ⏸ Esperando la orden del usuario para aplicarlo |

### D19 · Biblioteca de blueprints de visuales (2026-10-06)

| ID | Decisión |
|---|---|
| D19 | Los visual.json de dashboards reales se dejan en `inbox/visuals/` (solo repo, excluido del paquete) y se normalizan con `scripts/normalize_visual.py` a **blueprints** en `assets/blueprints/<familia>/<variante>` (visual.json + manifest.yaml + findings.json). Normalizar = IDs/posición → placeholders, campos → `{{FIELD_n}}`, selección guardada y filterConfig eliminados, propiedades iguales al tema eliminadas, fuentes fuera de la casa eliminadas, colores → `{{token:…}}`. Se instancian con `scripts/bind_blueprint.py` (excepción D1a). Estados: draft → approved-draft → golden (confirmado en Desktop) |
| BP1 | Primer blueprint: `slicer/period-dropdown` (Slicer Period). Slot: banda inferior, y 660, h 56, span 3, col 3 |

### Blueprint slicer/period-dropdown · decisiones

| ID | Pendiente | Estado |
|---|---|---|
| SL1 | Cabecera del slicer dropdown en **Segoe UI Semibold** 9 pt. Nuevo rol `type.slicer_header` (tokens 0.2.0, MINOR); el tema lo aplica a `slicer.header`; SLICER-006 actualizada | ✅ Usuario 2026-10-06 |
| RD1 | Esquinas redondeadas del desplegable del slicer: **3 px**. Token nuevo `radius.dropdown` (tokens 0.3.0, opción A: no afecta a `radius.control` = 5 de los button slicers). El tema lo aplica en `slicer.dropdown.borderRadius` | ✅ Usuario 2026-10-06 |
| RD1b | Prueba en Desktop: `slicer.dropdown.borderRadius` **no se aplica desde el tema**. Se escribe en cada visual: registro `component.visual_level` en tokens, blueprint `{{num:radius.dropdown}}`, testbed (Year) y regla nueva **SLICER-008** (auto) | ✅ 2026-10-06 |
| SL2 | Periodo por defecto **"Last Month"**: la selección guardada es la etiqueta `Last Month` (no un mes), en una columna de etiqueta de periodo del modelo. Requisito de modelo (model-requests, upstream). Blueprint 1.1.0 parámetro `DEFAULT_VALUE` | ✅ Usuario 2026-10-06 |

### Slicers del corpus P&L RHG (2026-10-07)

| ID | Decisión | Estado |
|---|---|---|
| BP2 | Year, Period, LY/TGT, Deltaview, Figures, Currency y Dataview extraídos de *RHG Consolidated Results › ▶ P&L RHG* (Dark + Light). Los cinco button slicers comparten estilo → un blueprint `slicer/button-group` con presets; Year → `slicer/year-dropdown` | ✅ |
| BS1 | Texto de los button slicers 8 pt (`type.label`), como el corpus; el tema decía 9. Hover/press en Bold, press 9 pt + padding 6 (efecto pulsado), texto hover blanco en ambos modos (token nuevo `hover.control_text`). Tokens 0.4.0 | ✅ (fidelidad) |
| BS3 | `keepLayerOrder: true` en los slicers dropdown (tema del corpus): el visual no salta al frente al hacer clic | ✅ (fidelidad) |
| FD1 | Nuevo `check_fidelity.py`: compara valores efectivos (tema + visual) del origen y del blueprint, por estado y modo. Las diferencias se corrigen, se aceptan con motivo o quedan pendientes | ✅ |
| BS2 | Color de *press* en Light: **gris** `grey_400` (en lugar del naranja del origen). `press.control` Light = grey_400. Nota: el hover Light usa el mismo gris; el press se distingue por Bold 9 pt y el desplazamiento | ✅ Usuario 2026-10-07 |
| BS4 | Esquinas de los button slicers **obligatorias, 4 px** (`radius.control` = 4). Se escriben en cada visual con la estructura de Desktop (`shapeCustomRectangle[default]`: `tileShape 'rectangleRoundedByPixel'` + `rectangleRoundedCurve 4L`, tomada del corpus Operational Report); regla nueva **SLICER-009** (auto, sin excepciones) | ✅ Usuario 2026-10-07 |

| FS1 | Prueba en Desktop: las fuentes escritas con el nombre suelto (`'Segoe UI Bold'`) se ven con un formato extraño (botones seleccionados, títulos de matrices). Desktop escribe la **pila de fuentes** (`'Segoe UI Bold', wf_segoe-ui_bold, helvetica, arial, sans-serif`). Tokens 0.5.0 `primitive.font_stack`; tema, blueprints, binder, normalizador y gemelas usan la pila; regla nueva **TYPO-006** (auto, crítica) | ✅ Usuario 2026-10-07 |

| HD1 | **Cabecera de página** (todas salvo Intro), especificada por el usuario a partir de *P&L RHG*: frame 11·10·1246×66 (fondo #425463 Dark / #E6E6E6 Light, borde 1 px blanco/#425463, radio 10, sombra #425463 abajo-derecha exterior); logo rectangular 15·20·245×50 (blanco/azul); título "Title" Segoe (Bold) 400·10·244×66 (#F3B244 / #425463); badge imagen vacía 1184·12·58×54 (padding 0, borde 1 px, 4 esquinas 10 px, fondo #425463/#E6E6E6, caption Segoe UI Semibold 8 blanco/#425463). Plantilla `assets/templates/page-header`, `install_header.py`, regla **PAGE-011**. Tokens 0.7.0 (shadow.header → #425463, band.header 10–76) | ✅ Usuario 2026-10-07 |
| HD3 | Ajustes tras la prueba: logo con **Image fit = Fit** (estructura `image.sourceFile` + `fit`, como el logo Light del origen); tarjeta **Selected Period** dentro de la cabecera (`Header Period`, opcional, `--period`): sin borde, sin fondo, sin divisor, sin etiqueta, valor Segoe UI Semibold 15 centrado; título **centrado en el frame y más bajo** (512·16·244×60). Corregido: `make_light_twin` aplicaba el contorno de KPI a la tarjeta del periodo | ✅ Usuario 2026-10-07 |
| HD4 | Tarjeta del periodo: *Multi-card layout* sin color de fondo y *uniform padding* 0 en Dark y Light (`layout[default]`: `backgroundShow false`, `paddingUniform 0L`, estructura escrita por Desktop en HouseTest) | ✅ Usuario 2026-10-07 |
| TB2 | Tabla financiera (rol `financial-matrix`, ejemplo *P&L RHG*): título Semibold 9 #425463 sobre #E6E6E6; subtítulo Semibold 8 #336293 (en blanco provisionalmente); divider sólido 5 px #425463; spacing 5/5/5; columna dummy "." (medida `""`) tras la primera, fondo y cabecera #425463; cabeceras a la derecha Semibold 8; anchos custom 150 / 10 / 55; row padding 2. Light según la gemela del origen (#FFFFFF sobre #425463, subtítulo #ADC0D4, dummy blanca). `apply_table_role.py` + anotaciones `house.role` | ✅ Usuario 2026-10-08 |
| HD2 | Interpretaciones a confirmar: (resuelto por HD3: título centrado 512·16·244×60); tamaño de letra 25 pt (escala; el origen usa 28 pt); "fit Center" escrito como `Normal` (valor PBIR del origen); borde del badge en Light #425463 (origen) | ⏸ Confirmación del usuario |

Hallazgos del origen (no se copian): la página Light no tiene Slicer Dataview; los títulos de los slicers Light están mal
nombrados ("Slicer Currency" ×3); Light usa 4 columnas; Year no tiene el redondeo de 3 px (Period sí); LY/TGT press 8 pt;
4 slicers llevan un tooltip de página del informe.

### Subdecisiones asumidas en D7 (propuestas aceptadas por defecto, revisables)

- Aprobación: el responsable del informe, registrado por **rol**, no por nombre.
- Caducidad por defecto: **3 meses** (`review_by`), renovable.
- Revisión de regla propuesta cuando acumula excepciones en **≥3 informes distintos**.
- **Baseline** para informes heredados: solo fallan los incumplimientos nuevos.

---

## Parámetros derivados (CANDIDATOS: se validan con el corpus en el Step 3)

Canvas 1280 × 720 · base 8 px · 24 columnas

| Parámetro | Candidato | Comprobación |
|---|---|---|
| Margen lateral | 24 px | — |
| Gutter | 16 px | — |
| Ancho de columna (24 col) | 36 px | (1280 − 2·24 − 23·16) / 24 = 864 / 24 = 36 ✔ |
| Equivalente en 12 col | 88 px | 36 + 16 + 36 = 88 ✔ |
| Span 6 (1 de 4 cards) | 296 px | 6·36 + 5·16 = 296 · 4·296 + 3·16 = 1232 ✔ |
| Span 8 (1 de 3 visuales) | 400 px | 8·36 + 7·16 = 400 · 3·400 + 2·16 = 1232 ✔ |
| Span 12 (media página) | 608 px | 12·36 + 11·16 = 608 ✔ |
| Ancho útil | 1232 px | 1280 − 48 ✔ |

Fórmulas del checker:
```text
x(col n)     = margin + (n − 1) × (col + gutter)
width(span)  = span × col + (span − 1) × gutter
tolerancia   = 0.5 px
```

Alturas de bandas (cabecera, KPIs, contenido, footer): **pendientes del corpus**.

---

## Decisiones abiertas

| ID | Decisión | Propuesta | Bloquea |
|---|---|---|---|
| D13 | Idioma de los ficheros de la skill | **Inglés** para SKILL.md, reglas y tokens (coherente con report-cli y con la activación); conversación en español | Step 4 |
| D14 | Nombre de la skill | `pbi-house-design-system`, o el nombre de tu sistema | Step 4 |
| D15 | Modo por defecto | ✅ Dark (R2) | — |
| D16 | Mecanismo Light/Dark | ✅ Páginas gemelas | — |
| D17 | Imágenes de fondo con contenedores dibujados | Pendiente: si se usan, el layout lo fija la imagen | Step 3 |
| D18 | Alcance: móvil, paginated, visuales custom | Pendiente | Step 4 |

---

## Riesgos registrados

1. Duplicar el modo `design` de report-cli → la skill solo aporta diferencias y restricciones.
2. Cambios en el contrato `Design Brief` (hoy `contract_version: 1`, report-cli v1.0.4) → matriz de compatibilidad + test.
3. Canvas 1280 frente al valor por defecto 1920 de report-cli → override explícito y test que lo verifique.
4. Fuentes corporativas no disponibles en el Service → tokens `font.brand` y `font.render`.
