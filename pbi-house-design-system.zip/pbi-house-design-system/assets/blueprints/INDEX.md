<!--
STATUS: v0.1 (2026-10-06, D19)
PURPOSE: Catalogue of approved visual blueprints and how to bind or add them.
LOADED: building a component that may have a blueprint, or turning a dashboard visual into a new blueprint.
-->
# Visual blueprints

A blueprint is a **normalized visual.json taken from a real dashboard**: no IDs, no position, no report fields,
no saved selections, nothing the theme already sets, and colours as tokens. Bind it; do not read it into context.

## Catalogue

| Blueprint | Visual | Role | Slot (default) | Status | Pending |
|---|---|---|---|---|---|
| `slicer/year-dropdown` | `slicer` (Dropdown) | Global year filter, synced ("Year") | bottom band · col 1 · span 2 · y 660 · h 56 | approved-draft | `DEFAULT_VALUE` required (e.g. `2026L`) |
| `slicer/period-dropdown` | `slicer` (Dropdown) | Global period filter, single select, latest first, synced (`SYNC_GROUP` "Period") | bottom band · col 3 · span 3 · y 660 · h 56 | approved-draft | — (opens on "Last Month": needs the model label, see manifest) |
| `slicer/button-group` | `advancedSlicerVisual` | View selector, one 50 px button per option. **Presets**: `ly-tgt` · `deltaview` · `figures` · `currency` · `dataview` | bottom band · y 670 · h 50 · W = 50 × options · 16 px after the previous group (`--x`) | approved-draft | — (press Light grey BS2 · corners 4 px BS4) |

Source of the slicer blueprints: *RHG Consolidated Results › ▶ P&L RHG* (Dark + Light twin). Fidelity is checked with
`scripts/check_fidelity.py` (effective values, every state, both modes); accepted differences are listed with their
reason in each manifest (`fidelity.accepted`), open ones in `fidelity.pending`.

## Bind (authoring step, D1a)

```bash
python ${CLAUDE_SKILL_DIR}/scripts/bind_blueprint.py --report "<path>/<name>.Report" --page "<Dark page>" \
       --blueprint slicer/period-dropdown --bind FIELD_1="Date[Period Label]" [--param HEADER="Month"] [--col 1]
python ${CLAUDE_SKILL_DIR}/scripts/bind_blueprint.py --report "<path>/<name>.Report" --page "<Dark page>" \
       --blueprint slicer/button-group --preset currency --bind FIELD_1="aux_fx[Currency]" --x 581
python ${CLAUDE_SKILL_DIR}/scripts/make_light_twin.py --report "<path>/<name>.Report" --page "<Dark page>" --replace
```

- Required fields and parameter defaults are in `<variant>.manifest.yaml`.
- Colour tokens that are equal in both modes become theme colours (`ThemeDataColor`). Others become the Dark
  value, which the twin builder re-colours.
- After binding, run the compliance gate as usual.

## Add a blueprint (repo only)

1. The user drops `visual.json` + `notes.txt` in `inbox/visuals/<name>/`.
2. `python scripts/normalize_visual.py --in inbox/visuals/<name>/visual.json --id <family>/<variant>`
3. Review `<variant>.findings.json`: rule violations dropped, decisions to ask, colours tokenised.
4. Write the final `<variant>.visual.json` and `<variant>.manifest.yaml`. Add a row to the catalogue.
5. Fidelity: `python scripts/check_fidelity.py --source-theme <source theme> --raw <raw> [--raw-light <raw light>] --bound <bound> [--bound-light <bound light>] --manifest <manifest>`
   → every difference is fixed, accepted (with reason) or pending (decision for the user).
6. Test: bind into the testbed (`tests/run_tests.py`, blueprint layer) → compliance and twins PASSED.
7. The user confirms in Desktop → status `golden`.
