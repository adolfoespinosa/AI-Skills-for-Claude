<!--
STATUS: v0.1 (Step 6, batch 2)
PURPOSE: Slicer types, roles, placement and states (SLICER-*).
LOADED: slicers, filters, view selectors, text tabs.
-->
# Slicers and Filters

## 1. Four slicer roles

| Role | Visual | Where | Selection | Example |
|---|---|---|---|---|
| **Global filter** | `slicer` (Dropdown) | band.bottom, left | Single | Year, Period |
| **View selector** | `advancedSlicerVisual` (button slicer), one per dimension | band.bottom, after dropdowns | Single, no "select all" | vs LY / vs TGT · ABS / DEV / DEV% · K / M · EUR / FXN / LC |
| **Text tabs** | `advancedSlicerVisual` styled as text | Panel subtitle row | Single | Calendar year / Rolling LTM · BUD / LY / TGT |
| **Detail filter rail** | `listSlicer` | band.content, a full-height column (span 4) at the left or right edge | Multi with search | Hotel / area lists |

## 2. States

| State | Button slicer | Text tab |
|---|---|---|
| Selected | `selection.fill` + `selection.text`, **Bold** (outline `selection.fill`) | `text.tab_active`, Bold, no box |
| Unselected | `surface.page` fill, `border.container` outline, `text.primary` | `text.tab_inactive`, no box |
| Hover | `hover.control` (grey, both modes), text `hover.control_text` (white, both modes), **Bold** | — |
| Press | `press.control` (Dark orange / **Light grey** `grey_400`, BS2), **Bold 9 pt**, text moves up 6 px (press padding) | — |
| Shape | Rounded rectangle **4 px** (`radius.control`), mandatory, on each visual (SLICER-009) | — |
| Value text | 8 pt (`type.label`, BS1), centred, one row, cell padding 2 | — |
| Dropdown (global filter) | Filled in **both** modes: `control.dropdown_fill` + `control.dropdown_text`; header label `text.primary`, `type.slicer_header`; rounded corners `radius.dropdown` (3 px, RD1) **set on each visual** (themes ignore it, SLICER-008) | — |

## 3. Rules

```yaml
- id: SLICER-001
  title: Global filters are dropdowns in the bottom band
  status: active
  since: 0.1.0
  severity: critical
  priority: P2
  modes: [dark, light]
  applies_to: [slicer]
  statement: "Page-level filters MUST be Dropdown slicers in band.bottom (see PAGE-004)."
  check: auto
  exceptions: allowed

- id: SLICER-002
  title: One button slicer per view dimension
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [advancedSlicerVisual]
  statement: "Each view dimension MUST be one button-slicer group with single select and no 'select all'. Each button is 50 × 50 (group width = 50 × buttons); groups are separated by the gutter (16)."
  check: auto
  exceptions: allowed

- id: SLICER-003
  title: Selection states
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [advancedSlicerVisual, slicer, listSlicer]
  statement: "Selected and unselected states MUST use the tokens in section 2 (selected = inverse of surface). Status colours MUST NOT be used for selection (COLOR-006)."
  check: auto
  exceptions: allowed

- id: SLICER-004
  title: Text tabs in the title bar
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [advancedSlicerVisual]
  statement: "Text tabs MUST sit in the panel subtitle row, height 24, transparent background, type.control, tab_active / tab_inactive colours."
  check: auto
  exceptions: allowed

- id: SLICER-005
  title: List rail geometry
  status: active
  since: 0.1.0
  severity: info
  priority: P5
  modes: [dark, light]
  applies_to: [listSlicer]
  statement: "List slicers used as filter rails SHOULD span 4 columns and the full height of band.content (88 to 656)."
  check: auto
  exceptions: allowed

- id: SLICER-006
  title: Slicer typography
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [slicer, advancedSlicerVisual, listSlicer]
  statement: "Dropdown slicer headers MUST use type.slicer_header (Semibold 9, SL1); button-slicer values and list-slicer headers MUST use type.control; items MUST use type.label."
  check: auto
  exceptions: allowed

- id: SLICER-008
  title: Dropdown rounded corners on the visual
  status: active
  since: 0.5.3
  severity: warning
  priority: P5
  modes: [dark, light]
  applies_to: [slicer]
  statement: "Every dropdown slicer MUST set objects.dropdown.borderRadius = radius.dropdown (3) on the visual itself. Power BI ignores this property in themes (tested 2026-10-06), so it is listed in component.visual_level and written by the blueprint / authoring step."
  check: auto
  exceptions: allowed

- id: SLICER-009
  title: Button corners rounded 4 px on the visual
  status: active
  since: 0.8.0
  severity: warning
  priority: P5
  modes: [dark, light]
  applies_to: [advancedSlicerVisual]
  statement: "Every button slicer MUST set objects.shapeCustomRectangle[default] = tileShape 'rectangleRoundedByPixel' + rectangleRoundedCurve = radius.control (4) on the visual itself (BS4, mandatory). Listed in component.visual_level; written by bind_blueprint."
  check: auto
  exceptions: forbidden

- id: SLICER-007
  title: Reset available
  status: active
  since: 0.1.0
  severity: info
  priority: P5
  modes: [dark, light]
  applies_to: [page]
  statement: "Pages with more than one filter SHOULD offer a reset or clear button in the bottom-band icon cluster."
  check: auto
  exceptions: allowed
```

## 4. Button slicers from the corpus (P&L RHG, 2026-10-07)

All view selectors share one style: blueprint `slicer/button-group` with presets.

| Preset | Options (default **bold**) | Sync group | Width |
|---|---|---|---|
| `ly-tgt` | vs LY · **vs TGT** | Deviation | 100 |
| `deltaview` | **ABS** · DEV · DEV% | Deltaview | 150 |
| `figures` | K · **M** | Figures | 100 |
| `currency` | **EUR** · FXN · LC | Currency | 150 |
| `dataview` | **Mth** · YTD · ROY · FY | (none) | 200 |

Order in the bottom band (left → right): Year · Period · LY/TGT · Deltaview · Figures · Currency · Dataview,
16 px between groups.

## 5. Default period (decision SL2, 2026-10-06)

The period dropdown opens on **"Last Month"**: the saved selection is the label `Last Month`, not a month value,
so it never goes stale. This needs a period label column in the date dimension where the last closed month is
labelled `Last Month` and every other month keeps its normal label (sorted by the period key). Request it through
`model-requests.yaml` → `semantic-model-authoring`; build it upstream (gold layer or Power Query), not as a DAX
calculated column. Blueprint: `slicer/period-dropdown` (`DEFAULT_VALUE` = "Last Month").

Watch the Year slicer: in January, "Last Month" is December of the previous year. Do not hard-code the Year
default; derive it from the same label column, or drop the Year slicer when the period label carries the year.
