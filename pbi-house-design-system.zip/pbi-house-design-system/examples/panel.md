<!-- STATUS: v0.1 (Step 9) · LOADED: on demand -->
# Examples: Panel

## Good: single-visual panel (chart)
```yaml
- id: tracking
  kind: lineChart
  geometry: { col: 13, span: 12, y: 88, h: 276 }        # T-STATEMENT › tracking
  title: { text: "Monthly tracking · 2026 - Actual vs Budget (Ref)", align: center,     # PANEL-007, TEXT-003, TEXT-006
           background: color.surface.panel_title, color: color.text.on_panel_title, type: type.panel_title }  # PANEL-002
  subtitle_row: text_tabs [Calendar year | Rolling LTM] · [BUD | LY | TGT]              # SLICER-004
  border: { color: color.border.container, width: 1, radius: 10 }                       # PANEL-004
  extra_shapes: none                    # single visual → use its own title, no container shape
```

## Bad
```yaml
- kind: lineChart
  title: { show: false }               # ✗ PANEL-001/002 no title bar
  plus: textbox "MONTHLY TRACKING" + shape behind     # ✗ extra shapes for a single visual; ✗ TEXT-006 capitalisation
  border: { show: false }              # ✗ PANEL-004
  title_align: left                    # ✗ PANEL-007 (charts are centred)
```
