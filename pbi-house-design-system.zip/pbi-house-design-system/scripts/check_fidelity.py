#!/usr/bin/env python3
"""
check_fidelity.py: does a blueprint-bound visual LOOK like its source? (D19, fidelity gate)

Compares EFFECTIVE values, property by property and state by state:
  source  = source report theme + raw visual.json (Dark, and its Light twin if given)
  house   = house theme        + bound visual.json (Dark, and the Light twin built by make_light_twin)

Cascade used for a property (object, state, property):
  visual[state] → theme[$id=state] → visual[default] → theme[default] → visual[no selector] → theme[no selector]
Colours compare as HEX (ThemeDataColor resolved with each side's own theme), fonts by first family, numbers as floats.

Keys compared: every property set in the source visual, the bound visual, or either theme for that visual type,
except identity / data / report-specific keys (IGNORE). Accepted differences come from the blueprint manifest
(fidelity.accepted: ["object[state].property", ...]) and are reported but do not fail.

Usage:
  python scripts/check_fidelity.py --source-theme <theme.json> --raw <dark.json> [--raw-light <light.json>]
         --bound <bound dark visual.json> [--bound-light <bound light visual.json>] [--manifest <manifest.yaml>]
Exit 0 = no unaccepted differences.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _tokens as T  # noqa: E402
from _pbir import shade  # noqa: E402

SKILL = T.SKILL_ROOT
IGNORE_OBJECTS = {"visualTooltip", "visualHeaderTooltip", "visualLink"}
IGNORE_PROPS = {"filter", "text", "section", "type"}
PBI_DEFAULTS = {                                                  # Power BI defaults when nothing sets the property
    ("*", "title", "show"): False, ("*", "subTitle", "show"): False, ("*", "dropShadow", "show"): False,
    ("advancedSlicerVisual", "fillCustom", "show"): True, ("advancedSlicerVisual", "outline", "show"): True,
}
STATES = ("", "default", "interaction:rest", "selection:selected", "interaction:hover", "interaction:press", "selection:disabled")


def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))


def norm(v, theme):
    if isinstance(v, dict) and "solid" in v:
        v = v["solid"]["color"]
    if isinstance(v, dict) and "expr" in v:
        e = v["expr"]
        if "ThemeDataColor" in e:
            cid, pct = e["ThemeDataColor"]["ColorId"], e["ThemeDataColor"].get("Percent", 0)
            base = ({0: theme.get("foreground"), 1: theme.get("background")}.get(cid) or theme["dataColors"][cid - 2]).upper()
            return shade(base, pct) if pct else base
        if "Literal" in e:
            v = e["Literal"]["Value"]
            if v in ("true", "false"):
                return v == "true"
            if v[-1:] in ("D", "L") and v[:-1].replace(".", "", 1).lstrip("-").isdigit():
                return float(v[:-1])
            if v.startswith("'") and v.endswith("'"):
                v = v[1:-1].replace("''", "'")
        else:
            return json.dumps(e, sort_keys=True)[:80]
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        if v.startswith("#"):
            return v.upper()
        if "," in v or v.startswith("'"):
            v = v.split(",")[0].strip("' ")
        return v
    return json.dumps(v, sort_keys=True)[:80] if v is not None else None


def visual_props(d):
    out = {}
    v = d.get("visual", {})
    for sec in ("objects", "visualContainerObjects"):
        for obj, ents in v.get(sec, {}).items():
            for e in ents:
                sel = (e.get("selector") or {}).get("id", "")
                for p, val in e.get("properties", {}).items():
                    out[(obj, sel, p)] = val
    return out


def theme_props(theme, vtype, only_specific=False):
    out = {}
    for vt in ((vtype,) if only_specific else ("*", vtype)):                                       # specific visual type wins over "*"
        for obj, ents in theme.get("visualStyles", {}).get(vt, {}).get("*", {}).items():
            for e in ents:
                sel = e.get("$id", "")
                for p, val in e.items():
                    if p != "$id":
                        out[(obj, sel, p)] = val
    return out


def effective(key, vp, tp, vtype=""):
    obj, sel, prop = key
    chain = [(obj, sel, prop)]
    if sel not in ("", "default"):
        chain += [(obj, "default", prop)]
    chain += [(obj, "", prop)]
    for k in chain:
        if k in vp:
            return vp[k], "visual"
        if k in tp:
            return tp[k], "theme"
    d = PBI_DEFAULTS.get((vtype, obj, prop), PBI_DEFAULTS.get(("*", obj, prop)))
    return (d, "pbi") if d is not None else (None, "default")


def compare(src_theme, raw, house_theme, bound):
    vtype = raw["visual"]["visualType"]
    rv, bv = visual_props(raw), visual_props(bound)
    st, ht = theme_props(src_theme, vtype), theme_props(house_theme, vtype)
    objs = {k[0] for k in rv} | {k[0] for k in bv} | {k[0] for k in theme_props(src_theme, vtype, True)} \
        | {k[0] for k in theme_props(house_theme, vtype, True)}
    keys = {k for k in set(rv) | set(bv) | set(st) | set(ht)
            if k[0] in objs and k[0] not in IGNORE_OBJECTS and k[2] not in IGNORE_PROPS}
    hidden = {o for o in objs if norm(effective((o, "", "show"), rv, st, vtype)[0], src_theme) is False
              and norm(effective((o, "", "show"), bv, ht, vtype)[0], house_theme) is False}
    rows = []
    for k in sorted(keys):
        if k[0] in hidden and k[2] != "show":
            continue                                              # object switched off on both sides
        a, sa = effective(k, rv, st, vtype)
        b, sb = effective(k, bv, ht, vtype)
        na, nb = norm(a, src_theme), norm(b, house_theme)
        if na is None and nb is None:
            continue
        rows.append({"key": f"{k[0]}[{k[1]}].{k[2]}", "source": na, "from_s": sa, "house": nb, "from_h": sb,
                     "match": na == nb or ((na is None or nb is None)
                                           and str(na if na is not None else nb) in ("False", "0.0"))})
    return rows


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-theme", required=True)
    ap.add_argument("--house-theme")
    ap.add_argument("--raw", required=True)
    ap.add_argument("--raw-light")
    ap.add_argument("--bound", required=True)
    ap.add_argument("--bound-light")
    ap.add_argument("--manifest")
    ap.add_argument("--json")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()
    src_theme = load(a.source_theme)
    house_theme = load(a.house_theme or sorted((SKILL / "assets" / "themes").glob("corporate-dark.*.json"))[-1])
    accepted, pending = {}, {}
    if a.manifest:
        man = yaml.safe_load(Path(a.manifest).read_text(encoding="utf-8"))
        for item in (man.get("fidelity") or {}).get("accepted", []):
            accepted[(item.get("mode", "*"), item["key"])] = item.get("reason", "")
        for item in (man.get("fidelity") or {}).get("pending", []):
            pending[(item.get("mode", "*"), item["key"])] = item.get("reason", "")
    report, fails, open_ = {}, 0, 0
    pairs = [("dark", a.raw, a.bound)] + ([("light", a.raw_light, a.bound_light)] if a.raw_light and a.bound_light else [])
    for mode, raw, bound in pairs:
        rows = compare(src_theme, load(raw), house_theme, load(bound))
        for r in rows:
            r["accepted"] = accepted.get((mode, r["key"])) or accepted.get(("*", r["key"]))
            r["pending"] = pending.get((mode, r["key"])) or pending.get(("*", r["key"]))
            if not r["match"] and r["accepted"] is None:
                if r["pending"] is not None:
                    open_ += 1
                else:
                    fails += 1
        report[mode] = rows
        if not a.quiet:
            diffs = [r for r in rows if not r["match"]]
            print(f"FIDELITY {mode.upper():<5} · {len(rows)} properties · {len(rows) - len(diffs)} match · {len(diffs)} differ")
            for r in diffs:
                tag = "ACCEPTED" if r["accepted"] is not None else "PENDING " if r["pending"] is not None else "DIFF    "
                print(f"  {tag} {r['key']:<46} source {str(r['source']):<22} ({r['from_s']:<7}) house {str(r['house']):<22} ({r['from_h']})"
                      + (f"  · {r['accepted'] or r['pending']}" if (r["accepted"] or r["pending"]) else ""))
    if a.json:
        Path(a.json).write_text(json.dumps(report, indent=1, default=str), encoding="utf-8")
    status = "FAILED" if fails else "PASSED WITH PENDING DECISIONS" if open_ else "PASSED"
    print(f"FIDELITY {status} · unaccepted differences: {fails} · pending decisions: {open_}")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
