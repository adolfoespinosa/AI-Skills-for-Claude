# Design Profile v0.1: Operational Report (Fabric)

**Step 3: ingeniería inversa** · Corpus: 1 informe (etiquetado `reference`) · Fecha: 2026-10-04
Fuente: solo la carpeta `.Report` (PBIR v2, report schema 3.3.0). No se ha leído el modelo ni ningún dato.

> Todos los valores de este documento son **OBSERVADOS**, no decididos.
> Con un solo informe no se puede distinguir entre "regla" y "costumbre de este informe".
> Cada punto se clasifica como: **Candidata** (patrón fuerte) · **Preguntar** · **Deriva** (probable error).

Ficheros generados: `data/*.csv` (salida de `extract_pbir.py`) · `wireframes.png` (4 páginas principales)

---

## 1. Inventario

| Elemento | Valor |
|---|---|
| Páginas | 30 (27 de 1280×720 · 3 tooltips · 1 de 1280×740) |
| Páginas visibles / ocultas | 17 / 13 (drillthrough simulados, tooltips, utilidades) |
| Visuales | 832 (79 grupos) |
| Tema | Base `CY24SU10` + custom `RHG_finance_template` (152 KB) |
| Modo | **Solo Dark.** Este informe no tiene versión Light |
| Bookmarks | 27 (casi todos "Erase X", resetean filtros) |

**Mezcla de visuales: es un informe operacional centrado en tablas, no en gráficos**

| Familia | Nº | Comentario |
|---|---|---|
| Botones (`actionButton`) | 133 | Navegación e iconos de acción |
| Slicers | 235 | 123 button slicers + 96 dropdown + 16 list |
| Formas y contenedores (`shape`) | 85 | Se usan como **contenedores** detrás de los visuales |
| Imágenes | 73 | Logos e iconos PNG |
| Textbox | 62 | Títulos |
| Tablas | 65 | 52 `tableEx` + 13 `pivotTable` |
| KPI cards | 72 | 43 card nueva + 29 card legacy |
| Gráficos | 19 | Línea 5, waterfall 5, barras 4, área 3, columnas 2 |
| Navegadores | 9 | 7 page navigators + 2 bookmark navigators |

---

## 2. Color

### 2.1 Disciplina: alta
- Solo **11 HEX distintos** escritos directamente en visuales, frente a **~3.000 referencias al tema** (`ThemeDataColor`).
- Es una base excelente: casi todo pasa ya por el tema, que es justo lo que pide D2/D4.

### 2.2 Colores del tema (`dataColors` y roles)

| HEX | Rol observado | Uso | Clasificación |
|---|---|---|---|
| `#425463` | Fondo de página, superficie de visuales, fondo de tooltip | theme:0 (1.216 refs) + 237 literales | **Candidata** → `surface.page` / `surface.card` (Dark) |
| `#687682` | Superficie elevada: cabeceras de tabla, visual header | theme:3, `backgroundNeutral` | **Candidata** → `surface.raised` |
| `#F3B244` | **Acento**: títulos, contorno de KPI, iconos, hover de botón, relleno de button slicer seleccionado | theme:2 (860) + 282 literales | **Candidata** → `accent.primary` |
| `#FFFFFF` | Texto principal, bordes, estado "selected" | theme:1 + 388 literales | **Candidata** → `text.primary` (Dark) |
| `#B1B3B3` | Texto secundario, relleno de button slicer no seleccionado | `foregroundNeutralSecondary` | **Candidata** → `text.secondary` |
| `#B3BBC1` | Neutro claro | theme:4 (318) | **Preguntar** |
| `#53565A`, `#97999B` | Neutros oscuros y medios | theme:5, theme:6 | **Preguntar** |
| `#425463` con −10% | Cabecera de tabla | theme:0 −0.1 (243) | **Candidata** → `surface.header` |

### 2.3 Fuera del tema

| HEX | Uso | Clasificación |
|---|---|---|
| `#ADC0D4` | 55 usos en 16 páginas: relleno de barras, fuente de subtotales, títulos, total de waterfall | **Preguntar**: ¿color oficial (p. ej. `data.secondary`) o deriva? |
| `#0E2841`, `#E6E6E6`, `#86919B`, `#C00D0D` | 1–4 usos cada uno | **Deriva** |

### 2.4 Semánticos: probablemente no corporativos
- `good: #32CD32` y `bad: #FF6347` son los colores estándar *LimeGreen* y *Tomato*.
- Iconos del tema: `RHG_green`, `RHG_red`, `RHG_orange`, `RHG_white` y flechas rojas/verdes.
- **Preguntar:** ¿cuáles son los verdes, rojos y ámbares oficiales?

### 2.5 Paleta de datos
- El 2.º color de `dataColors` es `#FFFFFF`: tiene sentido en Dark, pero rompe en Light.
- Los colores 9–50 son la paleta por defecto de Power BI (no curada).
- **Candidata:** paleta categórica corta y curada por modo.

### 2.6 ¡Formato condicional que vive en los DATOS!
- Las filas del P&L toman fondo, fuente, color, sangría y signo de la tabla **`DIM_Layouts`** (`Background Color`, `Font Color`, `Highlight Code`), con una escala de sangría 0 / 3 / 4 / 6 / 10 / 12.
- **Implicación de arquitectura:** hay HEX de diseño guardados como **datos** en el Lakehouse/modelo. Ni el tema ni el checker de PBIR los ven.
- Hace falta:
  - (a) que esos HEX estén en `tokens.yaml`;
  - (b) una regla `DATA-xxx` que valide `DIM_Layouts` contra los tokens (vía consulta DAX/MCP);
  - (c) un handoff al dueño de datos o modelo para cambiarlos.
- Es una frontera nueva que no estaba en la arquitectura.

---

## 3. Tipografía

### 3.1 Familias

| Familia | Usos | Clasificación |
|---|---|---|
| Segoe UI Bold | 357 | **Candidata** |
| Segoe UI Semibold | 277 | **Candidata** |
| Segoe UI (Regular) | 158 | **Candidata** |
| Arial | 71 | **Deriva** |
| `wf_standard-font` (DIN) / light | 63 | **Preguntar** (¿uso intencionado?) |
| Calibri | 19 | **Deriva** |
| Verdana | En el tema (multiRowCard) | **Deriva** (en el propio tema) |
| Courier New, Segoe UI Light | 1–2 | **Deriva** |

→ **Candidata:** `font.render = Segoe UI`, con pesos Regular / Semibold / Bold.
Falta saber la fuente corporativa oficial (`font.brand`).

### 3.2 Escala de tamaños (pt)

| Tamaño | Usos | Rol observado |
|---|---|---|
| **8** | 475 | Etiquetas, ejes, celdas de tabla, items de slicer, valores de button slicer |
| **9** | 211 | Cabecera de slicer, subtítulos |
| **10** | 152 | Títulos de visual, texto de navegación, valores de `tableEx` |
| **12** | 45 | Títulos de pivot, valores de KPI pequeños, botones |
| **15** | 38 | Título de KPI card, valor de card legacy |
| **20** | 29 | Valor de KPI (card mediana) |
| **25** | 21 | Valor de KPI (card grande), título de página (textbox por defecto) |
| 11 / 13 / 28 / 30 | 1–3 | **Deriva** |

→ **Candidata:** escala de 7 pasos `8 · 9 · 10 · 12 · 15 · 20 · 25`.
Nota: 8 pt en 1280×720 es pequeño. Hay que validarlo contra el tamaño mínimo accesible (ACCESS).

---

## 4. Canvas y layout

### 4.1 Canvas
- **1280×720 en 27 de 27 páginas estándar** → confirma D5.
- `1280×740` en *Profit & Loss (YoY)* → **Deriva** (está oculta).
- Tooltips: 320×320, 175×40, 210×80 → **Preguntar** (¿2 tamaños estándar?).
- Vista: `FitToPage` en 24 páginas; `ActualSize` en Intro, Monthly Tracking y YoY → **Preguntar**.

### 4.2 Estructura de página: patrón muy fuerte (ver `wireframes.png`)

```text
y=0   ┌──────────────────────────────────────────────────────────────┐
y=10  │ CABECERA (shape 11,10 · 1247×66)                              │
      │  [Logo 259×61] [Título textbox] [cards de contexto] … [img]  │
y=76  ├──────────────────────────────────────────────────────────────┤
y=88  │ CONTENIDO  (x 11 → 1257)                                     │
      │  rejilla de KPIs · tablas · gráficos · rail de list slicer   │
y=657 ├──────────────────────────────────────────────────────────────┤
      │ BANDA INFERIOR: slicers dropdown │ button slicers │ [nav] [i] [⟲] [⌂] │
y=720 └──────────────────────────────────────────────────────────────┘
```

| Elemento | Observado | Repeticiones |
|---|---|---|
| Panel de fondo | shape 0,0 · 1279×656 | 16 páginas |
| Cabecera | y 10→76 (alto 66), x 11→1258 | 15 páginas |
| Logo | 0,10 · 259×61 (izquierda) | 15 páginas |
| Inicio del contenido | y = 88–91 (88 el más frecuente) | 36 visuales |
| Fin del contenido | y = 656–658 | 34 visuales |
| **Filtros** | **Banda inferior**, y 657→720: dropdowns a la izquierda, button slicers 150×50 en el centro | Casi todas |
| Botones de acción | Abajo a la derecha: home 50×50 en (1194,662), info, reset, back | 14 páginas |

**Firma visual del sistema:** filtros y navegación en una **banda inferior**, no arriba. Es poco habitual y choca con el valor por defecto de `powerbi-report-cli` (franja de filtros arriba a la derecha) → hay que imponerlo explícitamente en `house-constraints`.

### 4.3 Márgenes, separación y grid

| Métrica | Observado | Clasificación |
|---|---|---|
| Margen izquierdo | 11–12 px | **Candidata** |
| Borde derecho del contenido | 1257–1260 (≈ 22 px de margen) | **Preguntar**: asimétrico (izq. 11 / dcha. 22) |
| Separación horizontal más frecuente | 17, 11, 16 px | Sin un valor único → **Deriva** |
| Separación vertical | 0 (apilado dentro de grupos), 9, 12, 15 | Sin un valor único |
| x múltiplo de 8 | 9% (el azar daría ~12%) | **Hoy no hay grid** |
| Posiciones con decimales | 57% | Colocación manual arrastrando |

→ Hay estructura **implícita** (bandas, margen izquierdo), pero no grid. Aplicar D6 implica **migrar** las posiciones (ver opciones en la sección 8).

---

## 5. Contenedores

| Propiedad | Observado | Clasificación |
|---|---|---|
| Patrón de contenedor | **Shapes como contenedores** detrás de los visuales; los visuales con fondo apagado (`background.show = false` en 495) | **Candidata**: regla de patrón |
| Borde | Tema: blanco, radio 10, `show:true`; **pero 555 overrides `show:false`** frente a 76 `true` | **Preguntar**: el tema y la práctica se contradicen |
| Radio | 10 px (127) · 3 px (20) · 5 px en button slicers (92) | **Candidata**: 10 para contenedores, 5 para controles |
| Sombra | `dropShadow` en 32 visuales (KPI cards), preset Center | **Preguntar**: ¿sombras en Dark? |
| Glow | 6 KPI cards | **Deriva** |
| Padding | 0 en la mayoría; 5/15 en algunas cards | **Preguntar** |

---

## 6. Componentes

### KPI cards
- Conviven **card nueva (43) y card legacy (29)** → **Preguntar**: ¿estandarizar en `cardVisual`?
- Tamaños observados:
  - **174×173** (rejilla de 6 en Summary, con contorno acento y sombra);
  - 160×56 (contexto en cabecera);
  - 112×35;
  - 173×149 / 173×102 (con reference labels).
- La card nueva usa título 15 pt, valor 20 o 25 pt, reference labels (comparativas) y contorno `#F3B244`.

### Slicers
- **Dropdown** (94 de 96) en la banda inferior, alto ~57–63.
- **Button slicer** (`advancedSlicerVisual`) 150×50 o 100×50, radio 5, relleno `#B1B3B3` / acento al seleccionar; también usado como **pestañas**.
- **List slicer** como rail vertical (183×570) en las páginas Hotel List.
- **Preguntar:** ¿son tres tipos con roles distintos (filtro global, selector de vista, filtro de detalle)?

### Tablas
- `tableEx` domina (52). `pivotTable` para P&L de ancho completo (1248×517).
- Grid 8 pt, valores 10 pt.
- `rowPadding` con **dos convenciones**: 1 y 6 → **Preguntar**.
- Cabecera en `#425463` −10%, preset "Condensed", sin gridlines.

### Navegación
- Botones: 108 PageNavigation · 43 WebUrl · 18 Bookmark · 2 Back.
- Iconos: information, reset, back, clearAllSlicers, custom.
- Estados del botón (en el tema):

| Estado | Relleno | Icono |
|---|---|---|
| default | `#425463` | acento |
| hover | **acento** | `#687682` |
| selected | blanco | blanco, texto `#425463` |

  → **Candidata**
- Jerarquía de páginas codificada con espacios iniciales y emojis en el nombre → **Deriva/frágil** (ya señalado en el handover).

### Gráficos
- Pocos (19); título 10 pt, ejes y etiquetas 8 pt; leyenda y eje de valores a menudo ocultos.
- Hay muy poca muestra para fijar reglas → **necesito otro informe con más gráficos**.

---

## 7. Assets

| Asset | Estado | Recomendación |
|---|---|---|
| Logos | `RHG_LOGO_WHITE.png`, `RHG_LOGO_BLACK.jpg`, `RHG_ICON_WHITE.png`, `RHG_ICON_WW.png` | Pedir el SVG oficial (light/dark) |
| Iconos | PNG (hotels ×4 duplicados, furniture ×3, user ×3, play ×2, globe, home) | Normalizar a un set SVG en `assets/icons/` |
| Iconos de tema | SVG embebidos (flechas, puntos RHG) | Generarlos desde tokens |

---

## 8. Impacto en las decisiones

### D5: confirmada
1280×720 es el estándar real.

### D6: hay que elegir parámetros de grid (D6b)
Combinaciones con columnas de ancho entero en 1280:

| Opción | Margen | Gutter | Columna (24) | Útil | Frente a lo actual |
|---|---|---|---|---|---|
| **A** | 8 | 8 | 45 | 1264 | Más denso; gutter más estrecho que hoy (11–17) |
| **B** | 24 | 16 | 36 | 1232 | Más aire; se pierden ~25 px de ancho útil |
| **C** | 12 | 16 | 37 | 1256 | **El más parecido a lo actual** (margen 11–12, gutter 16–17). El margen es múltiplo de 4, no de 8 |

**Bandas verticales candidatas** (muy cerca de lo actual, todo múltiplo de 8):

| Banda | Candidata | Actual |
|---|---|---|
| Margen superior | 0 → 8 | 0 → 10 |
| Cabecera | 8 → 72 (64) | 10 → 76 (66) |
| Separación | 72 → 88 (16) | 76 → 88 (12) |
| Contenido | 88 → 656 (568) | 88 → 657 (569) |
| Banda inferior | 656 → 720 (64) | 657 → 720 (63) |

Comprobación: 8 + 64 + 16 + 568 + 64 = 720 ✔

### D16 (mecanismo Light/Dark)
Este informe es solo Dark. Necesito un informe Light de referencia, o confirmar que Light aún no existe y hay que diseñarlo.

### Arquitectura: añadir una frontera nueva
**Data-driven formatting** (`DIM_Layouts`): familia de reglas `DATA-xxx` + handoff al dueño del modelo o de los datos.

---

## 9. Preguntas para la sesión de decisiones

| # | Pregunta | Mi recomendación |
|---|---|---|
| Q1 | D6b: ¿grid A, B o C? | **C** (mínima migración); si quieres pureza de 8 px, **A** |
| Q2 | ¿`#ADC0D4` es oficial o deriva? | — |
| Q3 | Verde, rojo y ámbar oficiales (sustituir LimeGreen/Tomato) | — |
| Q4 | ¿Estandarizar KPI cards en `cardVisual` (eliminar legacy)? | Sí |
| Q5 | ¿La banda inferior de filtros y navegación es tu estándar para todos los informes? | — |
| Q6 | ¿Bordes: on u off por defecto? (tema y práctica se contradicen) | Off + contenedor shape, alineando el tema |
| Q7 | ¿Sombras en Dark? | No (elevación con `surface.raised`) |
| Q8 | `rowPadding` de tablas: ¿1 o 6? | — |
| Q9 | Tooltips: ¿qué tamaños estándar? | 2 tamaños |
| Q10 | ¿`wf_standard-font` (DIN) es intencionado? | — |
| Q11 | ¿Margen derecho de 22 px intencionado o deriva? | Simétrico |
| Q12 | Los HEX de `DIM_Layouts`: ¿quién los mantiene y cuáles son? | — |

---

## 10. Para completar el corpus
1. **1–2 informes más** de referencia, idealmente uno **Light** y uno con **más gráficos**.
2. Screenshots Light/Dark (punto A3) para validar lo que no se ve en JSON (densidad, jerarquía).
3. Logo en SVG.
