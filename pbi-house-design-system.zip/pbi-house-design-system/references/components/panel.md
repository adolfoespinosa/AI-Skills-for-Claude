<!--
STATUS: v0.1 (Step 6, batch 2)
PURPOSE: The basic content block: panel with title bar and optional subtitle / text-tabs row (PANEL-*).
LOADED: creating or modifying any content block in band.content.
-->
# Panel

## 1. Anatomy

```text
┌───────────────────────────────────────────────────────────┐  border.container · radius 10
│▓ Title (type.panel_title, text.on_panel_title)          ▓│  title bar  = surface.panel_title
│▓ subtitle / [tab] [tab] · metric · [tab] [tab]          ▓│  subtitle row (optional)
│                                                           │
│   content (chart / table / KPI grid)  on surface.panel    │
└───────────────────────────────────────────────────────────┘
```

The title bar **inverts between modes** so that it always contrasts with the panel:
Dark = light bar with slate text · Light = slate bar with white text.

## 2. Implementation patterns

| Case | Pattern |
|---|---|
| Single visual panel (most common) | Use the visual's own `title` (background = `surface.panel_title`) and `subTitle`, plus the visual border. **No extra shapes** |
| Multi-visual panel (e.g. KPI grid, visual + text tabs) | A container `shape` behind (same geometry, lower z) + a title textbox or the first visual's title; children grouped |
| Text tabs in the subtitle row | `advancedSlicerVisual` overlaid on the subtitle row (see `slicers-filters.md`, SLICER-004) |

Geometry: panel x and width follow grid spans (LAYOUT-003/004). Panels stack with 16 px gaps and the last
panel ends at y 656.

## 3. Rules

```yaml
- id: PANEL-001
  title: Every content block is a panel
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: ["content visuals in band.content"]
  statement: "Every chart, table or KPI grid in band.content MUST sit inside a panel: a title bar plus container border."
  check: assisted
  exceptions: allowed

- id: PANEL-002
  title: Title bar tokens
  status: active
  since: 0.1.0
  severity: critical
  priority: P2
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Panel title bars MUST use background surface.panel_title, font colour text.on_panel_title and type.panel_title."
  expect:
    - title.background: "{color.surface.panel_title}"
    - title.fontColor: "{color.text.on_panel_title}"
    - title.fontSize: "{type.panel_title.size}"
  check: auto
  exceptions: allowed

- id: PANEL-003
  title: Subtitle row tokens
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Subtitle rows MUST use text.panel_subtitle and type.subtitle on surface.panel_title."
  check: auto
  exceptions: allowed

- id: PANEL-004
  title: Container border
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Panels MUST have border.container (1 px) with radius.container (10). Visuals inside a multi-visual panel MUST have no border of their own."
  check: auto
  exceptions: allowed

- id: PANEL-005
  title: Panel surface
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Panel background MUST be surface.panel. Table bodies use surface.table."
  check: auto
  exceptions: allowed

- id: PANEL-006
  title: Hidden visual header
  status: active
  since: 0.1.0
  severity: info
  priority: P4
  modes: [dark, light]
  applies_to: ["*"]
  statement: "The visual header (hover icons) SHOULD be hidden on panels, except where users need focus mode or export."
  check: auto
  exceptions: allowed
```

## 4. Decision PN1 (2026-10-04)

```yaml
- id: PANEL-007
  title: Title alignment by content
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Panel titles MUST be left-aligned on tables and matrices, and centred on charts and KPI grids."
  check: auto
  exceptions: allowed
```
