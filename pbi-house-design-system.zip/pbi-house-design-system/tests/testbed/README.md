# Testbed: HouseTest PBIP (fictitious data)

A complete PBIP generated **only with the skill** (tokens, themes, Intro installer, Light-twin builder), used
to test every new version of the design system in Power BI Desktop.

> 100 % fictitious data: 12 invented hotels in 6 areas, 2025–2026, seed 42. No real business or personal data,
> and no external data source (the model refreshes offline).

## Contents

| Page | Template | What it exercises |
|---|---|---|
| Intro | T-INTRO (locked) | Round logo, world map, "Title", dynamic navigator (3 tabs → 154 px) |
| Summary (+ Light) | T-SUMMARY | KPI row (6 tiles), EBITDA tracking (ACT solid · FCT dashed · REF light blue), revenue by area, EBITDA bridge, hotels table |
| Profit & Loss (+ Light) | T-STATEMENT | Layout-driven P&L (`PnL Layout`: indents, ↪ ratio rows, total/highlight bands from data colours, dynamic formats `#,##` / `#,#0.0%` / `pp`), tracking line, bridge |
| Hotel List (+ Light) | T-LIST | List table (10 pt, padding 6) + Area list rail |

Every page has the header (logo, title, period) and the bottom band (Year, Period, vs BUD / vs LY, K / M,
mode toggle 🌙/☀).

Model: `Date`, `Hotel`, `Facts` (ACT 2025 → Sep-2026, FCT Oct–Dec 2026, BUD 2026), `PnL Layout`, `Comparison`,
`Unit`, `Bridge`, `_Measures`.

## How to use

```bash
python tests/testbed/build_testbed.py      # regenerate HouseTest/ from scratch (after any skill change)
python tests/run_tests.py                  # includes: testbed builds, compliance PASSED, twins PASSED
python tests/testbed/preview_testbed.py    # geometry preview → preview.png (not a Power BI render)
```

Open `HouseTest/HouseTest.pbip` in Power BI Desktop, then **Refresh**. The first open has no data cache.

## What to check in Desktop (please report back)

1. The file opens without errors (model and report).
2. Refresh loads data. KPIs and the P&L show figures (Year 2026, Period Sep-26, vs BUD, K).
3. Theme: Dark pages slate, panel title bars light grey with slate text; no shadows except the header.
4. P&L: total rows (Revenue, EBITDAR, Net Income) in the grey band, EBITDA in the slate band with light-blue text,
   ratio rows in %, zero shown blank.
5. Mode toggle: 🌙 goes to "<page> Light" and ☀ comes back. The Light page has a blue logo and the same layout.
6. Intro: the navigator shows 3 buttons (Summary, Profit & Loss, Hotel List) with a good proportion.
7. K / M and vs BUD / vs LY change figures and titles.

Anything that looks wrong → describe it (or screenshot it). It becomes a fix in the skill, then
`build_testbed.py` is re-run.
