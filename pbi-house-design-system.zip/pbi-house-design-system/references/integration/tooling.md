<!--
STATUS: v0.1 (Step 6, batch 3)
PURPOSE: The ONLY file that names concrete tools (MCP servers, CLIs, scripts). Rules elsewhere describe capabilities.
LOADED: when a workflow step needs a concrete tool.
-->
# Tooling Map

Knowledge (this skill) and actions (tools) are separate. If a tool changes, update **this file only**.

| Capability | Tool (current environment) | Used by | Notes |
|---|---|---|---|
| Read and write PBIR files | Local file system (PBIP folder) | report-cli authoring (writes); HOUSE scripts (read) | HOUSE never writes PBIR (D1) |
| Validate PBIR schema, preview, screenshots | `powerbi-report-author` CLI, via `powerbi-report-cli` | report-cli | — |
| Read measures and format strings | `powerbi-modeling-mcp` (`measure_operations`), or `fabric` MCP `get_semantic_model_definition` | HOUSE (FMT-001) | Read-only |
| Run read-only DAX (layout table validation) | `powerbi-modeling-mcp` (`dax_query_operations`) or `fabric` MCP `execute_dax_query` | HOUSE (DATA-*) | Query design metadata only, never business figures |
| Change measures, format strings, layout table | `semantic-model-authoring` with its tools | Model owner | Requested via `model-requests.yaml` |
| Publish, download, rebind | `powerbi-report-cli` (management) | report-cli | Gate: compliance not FAILED |
| Extract the design profile from a report | `scripts/extract_pbir.py` | HOUSE (reverse engineering) | Reads `.Report` only |
| Compliance, twins, diff guard, tokens, contrast | `scripts/check_*.py`, `scripts/diff_guard.py` | HOUSE | Python 3.10+, `pyyaml` |
| Generate themes | `scripts/build_themes.py` | HOUSE | Output in `assets/themes/` |

## Data protection
- Design checks need report definitions and **design metadata** only. Do not query or copy business data
  or personal data into briefs, reports or examples.
- Screenshots used for visual review must come from development data, or have any personal data removed.
