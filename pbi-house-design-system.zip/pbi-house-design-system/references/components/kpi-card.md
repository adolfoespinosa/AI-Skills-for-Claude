<!--
STATUS: v0.1 (Step 6, batch 2)
PURPOSE: KPI card standard (KPI-*).
LOADED: designing or modifying KPI cards.
-->
# KPI Card

## 1. Visual and variants

Visual: **`cardVisual`** (new card) only (Q4). The legacy `card` is forbidden in new work; existing ones go to the baseline.

| Variant | Size (grid C) | Content | Where |
|---|---|---|---|
| `tile` | span 4 (196) × 176 | label · value (`type.kpi_large` / `kpi_hero`) · reference labels (comparisons) · optional icon | KPI grid in band.content (6 per row) |
| `compact` | span 4 (196) × 104 | label · value (`type.kpi_medium`) · 1 comparison | Secondary KPI rows |
| `context` | span 3 (143) × 48 | value (`type.kpi_small`) · optional label | Header right slot |

Heights are corpus values (173 / 102 / 56) normalised to the 8 px rhythm.

## 2. Anatomy (tile)

```text
┌──────────────────────┐
│        LABEL         │  type.label · text.primary · centred · above value
│       142,677        │  value · type.kpi_large · text.primary
│  vs BUD   +2.4%  ▲   │  reference labels: type.label · variance coloured by status (conditional)
└──────────────────────┘
```

## 3. Rules

```yaml
- id: KPI-001
  title: New card visual only
  status: active
  since: 0.1.0
  severity: critical
  priority: P4
  modes: [dark, light]
  applies_to: [card, cardVisual]
  statement: "KPI cards MUST use visualType cardVisual. Legacy card is forbidden in new work."
  expect:
    - visualType: cardVisual
  check: auto
  exceptions: allowed

- id: KPI-002
  title: Approved variants and sizes
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [cardVisual]
  statement: "A KPI card MUST match one variant (tile, compact, context) in width and height."
  check: auto
  exceptions: allowed

- id: KPI-003
  title: Value typography by variant
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [cardVisual]
  statement: "Value font MUST be type.kpi_large or type.kpi_hero (tile), type.kpi_medium (compact), type.kpi_small (context)."
  check: auto
  exceptions: allowed

- id: KPI-004
  title: Variance coloured only by condition
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [cardVisual]
  statement: "Comparison and variance values MUST be coloured by a condition (status.positive / status.negative) and MUST also show a sign or arrow (ACCESS-003). The main value uses text.primary."
  check: assisted
  exceptions: allowed

- id: KPI-005
  title: No shadow or glow on cards
  status: active
  since: 0.1.0
  severity: warning
  priority: P2
  modes: [dark, light]
  applies_to: [cardVisual]
  statement: "dropShadow, shadowCustom and glowCustom MUST be off (see PAGE-002)."
  check: auto
  exceptions: allowed

- id: KPI-006
  title: Card outline
  status: active
  since: 0.1.0
  severity: info
  priority: P4
  modes: [dark, light]
  applies_to: [cardVisual]
  statement: "Tile cards MAY use a decorative outline: accent.primary in Dark (allowed by COLOR-004), border.container in Light."
  check: auto
  exceptions: allowed

- id: KPI-007
  title: Consistent row
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [cardVisual]
  statement: "Cards in the same row MUST share variant, height, label position and number of comparisons."
  check: auto
  exceptions: allowed
```

## 4. Notes
- The Summary page in the Dark corpus uses inner shadow and glow on KPI tiles. These are now findings
  (KPI-005) and go to the baseline.
- Value format strings (K / M, decimals) are set in the model, not in the card (FMT-*).
