<!-- STATUS: v0.1 (Step 9) · LOADED: on demand (first KPI card in a session, or ambiguous QA) -->
# Examples: KPI card

## Good: tile in a 6-card row (Dark)
**Request:** "Add Revenue, GOP and EBITDA KPIs to the summary page."
**Decision:** template T-SUMMARY › `kpi_row` · variant `tile` (span 4 × 176) · cards 1–3 at x 12 / 224 / 436, y 88.
```yaml
- id: kpi_revenue
  kind: cardVisual                     # KPI-001
  geometry: { col: 1, span: 4, y: 88, h: 176 }
  value: { type: type.kpi_large, color: color.text.primary }          # KPI-003
  label: { text: "Revenue", type: type.label, position: aboveValue }
  reference_labels:
    - { label: "vs BUD", value: "[Revenue vs BUD %]", color: conditional(status.positive|status.negative), sign: true }  # KPI-004, ACCESS-003
  outline: { show: true, color: color.accent.primary }                # KPI-006 (Dark: decorative orange allowed)
  shadow: false                                                       # KPI-005
```
Rules satisfied: KPI-001 · KPI-002 · KPI-003 · KPI-004 · KPI-005 · COLOR-004 · LAYOUT-003/004.

## Bad
```yaml
- kind: card                           # ✗ KPI-001 legacy card
  geometry: { x: 15, width: 174 }      # ✗ LAYOUT-003 off-column · ✗ LAYOUT-004 not a span width
  value: { fontColor: "#F3B244" }      # ✗ COLOR-005 static orange on a number · ✗ COLOR-001 literal instead of token
  dropShadow: true                     # ✗ KPI-005
  variance: { color: red, sign: false } # ✗ ACCESS-003 colour is the only signal
```
**Fix:** `cardVisual`, column 1, span 4; value `text.primary`; variance coloured by a condition with a sign; no shadow.
