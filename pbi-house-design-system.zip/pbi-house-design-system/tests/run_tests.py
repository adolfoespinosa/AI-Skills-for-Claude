#!/usr/bin/env python3
"""
run_tests.py: unit / regression tests for the house checkers (Step 9).

Layer 1 · static     check_tokens.py and check_contrast.py must pass; build_themes.py must build
Layer 2 · fixtures   each tests/fixtures/{good,bad}/*.json spec is rendered into a synthetic PBIR report
                     (no business data) and run through check_compliance.py:
                       good/  → no findings at all
                       bad/   → every rule in expect_present must be reported
Layer 3 · twins      the good fixture must pass check_twins.py; a mutated copy must fail
Layer 4 · diff guard formatting change → PASS, query change → FAIL
Layer 5 · intro      install_intro.py on a synthetic report: Intro first + landing, PAGE-008/009 pass,
                     placeholders filled, images registered, model requests written, re-install refused

Layer 6 · testbed    HouseTest PBIP builds; compliance and twins PASSED
Layer 7 · blueprints normalize_visual on inbox files; bind_blueprint into a testbed copy → compliance + twins PASSED
Layer 8 · fidelity   check_fidelity: bound slicers vs their source visuals (Dark + Light), no unaccepted difference

Usage: python tests/run_tests.py            (exit 0 = all green)
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
PY = sys.executable
RESULTS = []


def run(args):
    return subprocess.run([PY, *map(str, args)], capture_output=True, text=True)


def ok(name, cond, detail=""):
    RESULTS.append((name, bool(cond), detail))


def lit(v):
    if isinstance(v, bool):
        return {"expr": {"Literal": {"Value": "true" if v else "false"}}}
    if isinstance(v, (int, float)):
        return {"expr": {"Literal": {"Value": f"{v}D"}}}
    if isinstance(v, str) and v.startswith("#"):
        return {"solid": {"color": {"expr": {"Literal": {"Value": f"'{v}'"}}}}}
    return {"expr": {"Literal": {"Value": "'" + str(v).replace("'", "''") + "'"}}}


def build_report(spec: dict, root: Path) -> Path:
    rep = root / "Fixture.Report"
    d = rep / "definition"
    (d / "pages").mkdir(parents=True)
    theme = sorted((ROOT / "assets" / "themes").glob("corporate-dark.*.json"))[-1]
    rr = rep / "StaticResources" / "RegisteredResources"
    rr.mkdir(parents=True)
    shutil.copy(theme, rr / theme.name)
    (d / "report.json").write_text(json.dumps({"themeCollection": {"customTheme": {"name": theme.name, "type": "RegisteredResources"}}}))
    (d / "pages" / "pages.json").write_text(json.dumps({"pageOrder": [p["id"] for p in spec["pages"]]}))
    for p in spec["pages"]:
        pd = d / "pages" / p["id"]
        (pd / "visuals").mkdir(parents=True)
        (pd / "page.json").write_text(json.dumps({"name": p["id"], "displayName": p["name"], "width": p["width"],
                                                  "height": p["height"], "displayOption": p["display"],
                                                  "type": p["type"], "visibility": p["visibility"]}, ensure_ascii=False))
        for v in p["visuals"]:
            objects, container = {}, {}
            for k, val in v["props"].items():
                objprop, _, sel = k.partition("[")
                obj, prop = objprop.split(".")
                target = container if obj in ("dropShadow", "title", "border", "background") else objects
                entry = {"properties": {prop: lit(val)}}
                if sel:
                    entry["selector"] = {"id": sel.rstrip("]")}
                target.setdefault(obj, []).append(entry)
            if "link" in v:
                container["visualLink"] = [{"properties": {kk: lit(vv) for kk, vv in v["link"].items()}}]
            body = {"name": v["id"], "position": {"x": v["x"], "y": v["y"], "width": v["w"], "height": v["h"], "z": 0},
                    "visual": {"visualType": v["type"], "objects": objects, "visualContainerObjects": container}}
            (pd / "visuals" / v["id"]).mkdir()
            (pd / "visuals" / v["id"] / "visual.json").write_text(json.dumps(body))
    return rep


def install_intro(rep: Path, *extra):
    return run([SCRIPTS / "install_intro.py", "--report", rep, *extra])


def compliance(rep: Path, tmp: Path) -> dict:
    out = tmp / "cr"
    run([SCRIPTS / "check_compliance.py", "--report", rep, "--brief", tmp / "nobrief", "--out", out, "--quiet"])
    return json.loads(out.with_suffix(".json").read_text())


def main() -> int:
    # Layer 1
    r = run([SCRIPTS / "check_tokens.py"]); ok("static: check_tokens", r.returncode == 0, r.stdout.splitlines()[0] if r.stdout else r.stderr[-200:])
    r = run([SCRIPTS / "check_contrast.py"]); ok("static: check_contrast", r.returncode == 0, r.stdout.splitlines()[0] if r.stdout else "")
    r = run([SCRIPTS / "build_themes.py"]); ok("static: build_themes", r.returncode == 0, r.stdout.splitlines()[0] if r.stdout else r.stderr[-200:])

    # Layer 2
    for spec_path in sorted((ROOT / "tests" / "fixtures").glob("*/*.json")):
        spec = json.loads(spec_path.read_text(encoding="utf-8"))
        with tempfile.TemporaryDirectory() as t:
            tmp = Path(t)
            rep = build_report(spec, tmp)
            if spec.get("expect_absent") == "ALL":
                install_intro(rep)
                run([SCRIPTS / "install_header.py", "--report", rep, "--all"])
            res = compliance(rep, tmp)
            rules = {f["rule"] for f in res["findings"]}
            name = f"fixture: {spec_path.parent.name}/{spec_path.stem}"
            if spec.get("expect_absent") == "ALL":
                ok(name, not rules, f"unexpected: {sorted(rules)}" if rules else "no findings")
            for rule in spec.get("expect_present", []):
                ok(f"{name} → {rule}", rule in rules, f"found {sorted(rules)}")
            # Layer 3 on the good fixture
            if spec.get("expect_absent") == "ALL":
                r = run([SCRIPTS / "check_twins.py", "--report", rep])
                ok("twins: compliant pair passes", r.returncode == 0, r.stdout.splitlines()[0])
                vj = next(rep.glob("definition/pages/p_light/visuals/kpi2/visual.json"))
                body = json.loads(vj.read_text()); body["position"]["x"] = 436; vj.write_text(json.dumps(body))
                r = run([SCRIPTS / "check_twins.py", "--report", rep])
                ok("twins: moved visual on Light fails", r.returncode == 1, r.stdout.splitlines()[0])

    # Layer 4
    good = json.loads((ROOT / "tests" / "fixtures" / "good" / "compliant-twins.json").read_text(encoding="utf-8"))
    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        before = tmp / "before"; after = tmp / "after"
        build_report(good, before); build_report(good, after)
        vj = after / "Fixture.Report/definition/pages/p_dark/visuals/kpi1/visual.json"
        body = json.loads(vj.read_text()); body["visual"]["objects"]["value"][0]["properties"]["fontColor"] = lit("#E6E6E6")
        vj.write_text(json.dumps(body))
        r = run([SCRIPTS / "diff_guard.py", "--before", before, "--after", after])
        ok("diff_guard: formatting change passes", r.returncode == 0, r.stdout.splitlines()[0])
        body["visual"]["query"] = {"queryState": {"Values": {"projections": [{"field": "x"}]}}}
        vj.write_text(json.dumps(body))
        r = run([SCRIPTS / "diff_guard.py", "--before", before, "--after", after])
        ok("diff_guard: query change fails", r.returncode == 1, r.stdout.splitlines()[0])

    # Layer 5
    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        rep = build_report(good, tmp)
        res = compliance(rep, tmp)
        ok("intro: missing Intro fails PAGE-008", "PAGE-008" in {f["rule"] for f in res["findings"]})
        r = install_intro(rep)
        ok("intro: installer succeeds", r.returncode == 0, r.stdout.splitlines()[0] if r.stdout else r.stderr[-200:])
        meta = json.loads((rep / "definition/pages/pages.json").read_text())
        first = meta["pageOrder"][0]
        pj = json.loads((rep / "definition/pages" / first / "page.json").read_text(encoding="utf-8"))
        ok("intro: first page and landing page", pj["displayName"] == "Intro" and meta["landingPageName"] == first)
        txt = "".join(p.read_text(encoding="utf-8") for p in (rep / "definition/pages" / first).rglob("*.json"))
        ok("intro: placeholders filled, generic title", "{{" not in txt and '"Title"' in txt)
        ok("intro: no tutorial / DynamicScroll / version / last update", all(s not in txt for s in ("DynamicScroll", "Last_update", "WebUrl", "Version")))
        rj = json.loads((rep / "definition/report.json").read_text())
        items = {i["name"] for p in rj.get("resourcePackages", []) for i in p.get("items", [])}
        ok("intro: 2 images registered (map + round logo)", items == {"Globe_map7381549055369043.png", "RHG_ICON_WHITE6551529436343584.png"})
        ok("intro: no model requests needed", not (tmp / "_brief" / "model-requests.yaml").exists())
        grp = json.loads((rep / "definition/pages" / first / "visuals/108a61bf481b47834271/visual.json").read_text())
        ok("intro: navigator sized for 1 tab (48px)", abs(grp["position"]["height"] - 48) < 1, f"{grp['position']['height']}")
        run([SCRIPTS / "install_header.py", "--report", rep, "--all"])
        res = compliance(rep, tmp)
        rules = {f["rule"] for f in res["findings"]}
        ok("intro: compliance PAGE-008/009 pass, Intro exempt from grid rules", not rules, f"found {sorted(rules)}")
        r = install_intro(rep)
        ok("intro: second install refused without --replace", r.returncode == 1)
        # add 9 more visible pages → navigator must grow; compliance flags stale height until refresh
        meta = json.loads((rep / "definition/pages/pages.json").read_text())
        for i in range(9):
            pid = f"extra{i:02d}"
            (rep / "definition/pages" / pid / "visuals").mkdir(parents=True)
            (rep / "definition/pages" / pid / "page.json").write_text(json.dumps({"name": pid, "displayName": f"Extra {i}", "width": 1280, "height": 720, "displayOption": "FitToPage"}))
            meta["pageOrder"].append(pid)
        (rep / "definition/pages/pages.json").write_text(json.dumps(meta))
        res = compliance(rep, tmp)
        ok("intro: stale navigator height flagged (PAGE-010)", "PAGE-010" in {f["rule"] for f in res["findings"]})
        r = install_intro(rep, "--refresh-nav")
        grp = json.loads((rep / "definition/pages" / first / "visuals/108a61bf481b47834271/visual.json").read_text())
        ok("intro: refresh-nav resizes for 10 tabs (469px)", r.returncode == 0 and abs(grp["position"]["height"] - 469) < 1, f"{grp['position']['height']}")
        res = compliance(rep, tmp)
        ok("intro: PAGE-010 passes after refresh", "PAGE-010" not in {f["rule"] for f in res["findings"]})

    # Layer 6 · testbed PBIP (fictitious data) built end-to-end with the skill scripts
    r = run([ROOT / "tests" / "testbed" / "build_testbed.py"])
    ok("testbed: HouseTest builds", r.returncode == 0, (r.stdout.strip().splitlines() or [r.stderr[-200:]])[-1])
    tb = ROOT / "tests" / "testbed" / "HouseTest" / "HouseTest.Report"
    with tempfile.TemporaryDirectory() as t:
        res = compliance(tb, Path(t))
        ok("testbed: compliance PASSED", res["status"] == "PASSED", f"{res['status']} {sorted({f['rule'] for f in res['findings']})}")
    r = run([SCRIPTS / "check_twins.py", "--report", tb])
    ok("testbed: twins PASSED", r.returncode == 0, r.stdout.splitlines()[0])

    # Layer 7 · blueprints: normalizer on the raw inbox file, then every blueprint bound into a testbed copy
    raw = ROOT / "inbox" / "visuals" / "slicer-period" / "visual.json"
    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        if raw.exists():
            r = run([SCRIPTS / "normalize_visual.py", "--in", raw, "--id", "slicer/period-dropdown", "--out", tmp])
            draft = (tmp / "slicer" / "period-dropdown.draft.visual.json").read_text(encoding="utf-8") if r.returncode == 0 else ""
            ok("blueprint: normalizer removes literals, IDs and fonts",
               draft and not any(s in draft for s in ("2026-Jun", "Arial", "dim time", "e106de892bc46deb502e", "filterConfig")),
               "clean" if draft else r.stderr[-200:])
            ok("blueprint: normalizer tokenises slicer colours as control.*", "{{token:control.dropdown_text}}" in draft)
        rep = tmp / "tb" / "HouseTest.Report"
        shutil.copytree(tb, rep)
        defn = rep / "definition"
        summary = next(p for p in json.loads((defn / "pages/pages.json").read_text())["pageOrder"]
                       if json.loads((defn / "pages" / p / "page.json").read_text(encoding="utf-8"))["displayName"] == "Summary")
        for vj in (defn / "pages" / summary / "visuals").glob("*/visual.json"):
            d = json.loads(vj.read_text(encoding="utf-8"))
            if d["visual"]["visualType"] == "slicer" and abs(d["position"]["x"] - 118) < 1:
                shutil.rmtree(vj.parent)
        r = run([SCRIPTS / "bind_blueprint.py", "--report", rep, "--page", "Summary", "--blueprint", "slicer/period-dropdown",
                 "--bind", "FIELD_1=Date[Period Label]"])
        ok("blueprint: period-dropdown binds", r.returncode == 0, (r.stdout.splitlines() or [r.stderr[-200:]])[0])
        bound = next((vj.read_text(encoding="utf-8") for vj in (defn / "pages" / summary / "visuals").glob("*/visual.json")
                      if "Slicer Period" in vj.read_text(encoding="utf-8")), "")
        ok("blueprint: default selection is 'Last Month' (SL2)", "'Last Month'" in bound and "Period Label" in bound)
        theme = json.loads(sorted((ROOT / "assets/themes").glob("corporate-dark.*.json"))[-1].read_text(encoding="utf-8"))
        ok("blueprint: theme slicer header is Segoe UI Semibold (SL1)",
           theme["visualStyles"]["slicer"]["*"]["header"][0]["fontFamily"].startswith("'Segoe UI Semibold', wf_"))
        ok("blueprint: theme fonts are Power BI stacks (FS1, TYPO-006)",
           all("wf_" in e["fontFamily"] for vt in theme["visualStyles"].values() for es in vt.get("*", {}).values()
               for e in es if isinstance(e.get("fontFamily"), str)))
        ok("blueprint: dropdown radius written on the visual (SLICER-008)", '"borderRadius"' in bound and '"3L"' in bound)
        btn = next((vj.read_text(encoding="utf-8") for vj in (defn / "pages" / summary / "visuals").glob("*/visual.json")
                    if "Slicer Currency" in vj.read_text(encoding="utf-8")), "")
        ok("blueprint: button corners 4 px on the visual (SLICER-009, BS4)", "rectangleRoundedByPixel" in btn and '"4L"' in btn)
        r = run([SCRIPTS / "make_light_twin.py", "--report", rep, "--page", "Summary", "--replace"])
        res = compliance(rep, tmp)
        ok("blueprint: bound page compliance PASSED", res["status"] == "PASSED", f"{res['status']} {sorted({f['rule'] for f in res['findings']})}")
        r = run([SCRIPTS / "check_twins.py", "--report", rep])
        ok("blueprint: bound page twins PASSED", r.returncode == 0, r.stdout.splitlines()[0])
        r = run([SCRIPTS / "bind_blueprint.py", "--report", rep, "--page", "Summary", "--blueprint", "slicer/period-dropdown"])
        ok("blueprint: missing required field refused", r.returncode == 2)

    # Layer 7b · page header (HD1, PAGE-011)
    with tempfile.TemporaryDirectory() as t:
        rep = Path(t) / "tb" / "HouseTest.Report"
        shutil.copytree(tb, rep)
        sys.path.insert(0, str(SCRIPTS))
        import install_header as H, _tokens as TK
        tk = TK.load()
        def headers(page):
            for pj in (rep / "definition/pages").glob("*/page.json"):
                if json.loads(pj.read_text(encoding="utf-8"))["displayName"] == page:
                    return {H.visual_name(json.loads(v.read_text(encoding="utf-8")), tk): json.loads(v.read_text(encoding="utf-8"))
                            for v in pj.parent.glob("visuals/*/visual.json")
                            if H.visual_name(json.loads(v.read_text(encoding="utf-8")), tk) in H.NAMES}
        d, l = headers("Summary"), headers("Summary Light")
        ok("header: 4 required visuals + period card on Dark and Light", set(H.REQUIRED) <= set(d) and set(H.REQUIRED) <= set(l)
           and "Header Period" in d and "Header Period" in l, f"{sorted(d)} / {sorted(l)}")
        ok("header: period card without border, background or divider (HD3)",
           all('"show": {"expr": {"Literal": {"Value": "false"}}}' in json.dumps(d["Header Period"]["visual"]["objects"][o]) for o in ("outline", "divider", "fillCustom")))
        lay = json.dumps(d["Header Period"]["visual"]["objects"]["layout"]) + json.dumps(l["Header Period"]["visual"]["objects"]["layout"])
        ok("header: period card layout without background, padding 0 (HD4)", lay.count('"backgroundShow"') == 2 and lay.count('"0L"') == 2)
        ok("header: logo image fit = Fit (HD3)", "'Fit'" in json.dumps(d["Header Logo"]["visual"]["objects"]["image"]))
        ok("header: Light frame #E6E6E6 · logo-blue · title slate",
           "#E6E6E6" in json.dumps(l["Header Frame"]) and "logo-blue.png" in json.dumps(l["Header Logo"])
           and "#425463" in json.dumps(l["Header Title"]["visual"]["objects"]))
        ok("header: Dark title orange Segoe (Bold)", "#F3B244" in json.dumps(d["Header Title"]) and "Segoe (Bold)" in json.dumps(d["Header Title"]))
        r = run([SCRIPTS / "install_header.py", "--report", rep, "--page", "Summary", "--title", "P&L RHG"])
        d2 = headers("Summary")
        ok("header: re-install replaces (no duplicates) and sets the title",
           r.returncode == 0 and len(d2) == 5 and "P&L RHG" in json.dumps(d2["Header Title"]) and "Header Period" in d2)
        for v in (rep / "definition/pages").glob("*/visuals/*/visual.json"):
            if H.visual_name(json.loads(v.read_text(encoding="utf-8")), tk) == "Header Badge":
                shutil.rmtree(v.parent)
                break
        res = compliance(rep, Path(t))
        ok("header: missing badge flagged (PAGE-011)", "PAGE-011" in {f["rule"] for f in res["findings"]})

    # Layer 7c · table role financial-matrix (TB2) on the testbed P&L, Dark and Light
    sys.path.insert(0, str(SCRIPTS))
    roles = {}
    for pj in (tb / "definition/pages").glob("*/page.json"):
        name = json.loads(pj.read_text(encoding="utf-8"))["displayName"]
        for vj in pj.parent.glob("visuals/*/visual.json"):
            d = json.loads(vj.read_text(encoding="utf-8"))
            if any(a.get("value") == "financial-matrix" for a in d.get("annotations", [])):
                roles[name] = d
    dk, lt = roles.get("Profit & Loss"), roles.get("Profit & Loss Light")
    ok("table role: on P&L Dark and Light", dk is not None and lt is not None)
    if dk and lt:
        c_d, c_l = json.dumps(dk["visual"]["visualContainerObjects"]), json.dumps(lt["visual"]["visualContainerObjects"])
        ok("table role: title/subtitle/divider colours per mode",
           "'#E6E6E6'" in c_d and "'#336293'" in c_d and "'#ADC0D4'" in c_l and "'#FFFFFF'" in c_l)
        projs = dk["visual"]["query"]["queryState"]["Values"]["projections"]
        ok("table role: dummy '.' column after the first", projs[1].get("displayName") == ".")
        o = json.dumps(dk["visual"]["objects"])
        ok("table role: widths 150/10/55, headers right, row padding 2",
           all(s in o for s in ('"150D"', '"10D"', '"55D"', "'Right'", "'fixedWidth'")) and '"rowPadding": {"expr": {"Literal": {"Value": "2D"}}}' in o)

    # Layer 8 · fidelity: every slicer blueprint bound in the testbed vs its source visual (Dark + Light)
    src_theme = ROOT / "tests" / "fidelity" / "source-theme-rhg.json"
    inbox = ROOT / "inbox" / "visuals"
    if src_theme.exists() and inbox.exists():
        pages = tb / "definition" / "pages"
        def find(page, name):
            for pj in pages.glob("*/page.json"):
                if json.loads(pj.read_text(encoding="utf-8"))["displayName"] == page:
                    for vj in pj.parent.glob("visuals/*/visual.json"):
                        if f"'{name}'" in vj.read_text(encoding="utf-8"):
                            return vj
        for slug, name, man in [("year", "Slicer Year", "year-dropdown"), ("period", "Slicer Period", "period-dropdown"),
                                ("ly-tgt", "Slicer LY/TGT", "button-group"), ("deltaview", "Slicer Deltaview", "button-group"),
                                ("figures", "Slicer Figures", "button-group"), ("currency", "Slicer Currency", "button-group"),
                                ("dataview", "Slicer Dataview", "button-group")]:
            raw = inbox / f"slicer-{slug}"
            if not (raw / "visual.json").exists():
                continue
            args = [SCRIPTS / "check_fidelity.py", "--source-theme", src_theme, "--raw", raw / "visual.json",
                    "--bound", find("Summary", name), "--manifest", ROOT / "assets/blueprints/slicer" / f"{man}.manifest.yaml", "--quiet"]
            if (raw / "visual.light.json").exists():
                args += ["--raw-light", raw / "visual.light.json", "--bound-light", find("Summary Light", name)]
            r = run(args)
            ok(f"fidelity: {name}", r.returncode == 0, r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])

    width = max(len(n) for n, _, _ in RESULTS)
    for n, passed, detail in RESULTS:
        print(f"{'PASS' if passed else 'FAIL'}  {n:<{width}}  {detail}")
    fails = sum(1 for _, p, _ in RESULTS if not p)
    print(f"\n{len(RESULTS) - fails}/{len(RESULTS)} passed")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
