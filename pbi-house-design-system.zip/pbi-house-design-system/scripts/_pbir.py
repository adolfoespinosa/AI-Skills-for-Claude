"""
_pbir.py: read-only model of a PBIR report (definition/ folder) for the house checkers.

Reads only <name>.Report (pages, visuals, bookmarks, themes). Never reads the semantic model or data.
Positions of grouped visuals are resolved to ABSOLUTE canvas coordinates.
Effective values follow the cascade: visual override -> custom theme [visualType] -> custom theme ['*'].
(The Microsoft base theme is not modelled; properties set nowhere are reported as unset.)
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path


def _load(p: Path):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def shade(hex_color: str, pct: float) -> str:
    r, g, b = (int(hex_color[i:i + 2], 16) for i in (1, 3, 5))
    if pct < 0:
        r, g, b = (round(c * (1 + pct)) for c in (r, g, b))
    else:
        r, g, b = (round(c + (255 - c) * pct) for c in (r, g, b))
    return "#%02X%02X%02X" % (r, g, b)


@dataclass
class Visual:
    id: str
    page_id: str
    vtype: str
    parent: str | None
    x: float
    y: float
    w: float
    h: float
    z: float
    raw: dict
    props: list = field(default_factory=list)   # (group, object, property, selector, value)

    @property
    def right(self):
        return self.x + self.w

    @property
    def bottom(self):
        return self.y + self.h

    @property
    def is_group(self):
        return self.vtype == "group"


@dataclass
class Page:
    id: str
    name: str
    raw_name: str
    width: int
    height: int
    display: str
    ptype: str
    visibility: str
    visuals: list
    props: list

    @property
    def is_tooltip(self):
        return self.ptype == "Tooltip"

    @property
    def mode(self):
        return "light" if self.name.endswith(" Light") else "dark"

    @property
    def hidden(self):
        return self.visibility == "HiddenInViewMode"


class Report:
    def __init__(self, report_dir: str | Path):
        self.dir = Path(report_dir)
        self.defn = self.dir / "definition"
        if not self.defn.exists():
            raise SystemExit(f"Not a PBIR report folder (missing definition/): {self.dir}. Convert PBIR-Legacy first (D11).")
        self.report = _load(self.defn / "report.json")
        self.theme = self._theme()
        self.theme_colors = ([self.theme.get("foreground", "#FFFFFF"), self.theme.get("background", "#FFFFFF")]
                             + list(self.theme.get("dataColors", [])))
        self.pages = self._pages()
        self.bookmarks = self._bookmarks()

    # ---------------------------------------------------------------- loading
    def _theme(self) -> dict:
        ct = self.report.get("themeCollection", {}).get("customTheme")
        if ct:
            p = self.dir / "StaticResources" / "RegisteredResources" / ct["name"]
            if p.exists():
                return _load(p)
        return {}

    def _bookmarks(self) -> list[dict]:
        out = []
        bdir = self.defn / "bookmarks"
        if bdir.exists():
            for f in sorted(bdir.glob("*.bookmark.json")):
                out.append(_load(f))
        return out

    def _pages(self) -> list[Page]:
        meta = _load(self.defn / "pages" / "pages.json")
        pages = []
        for pid in meta.get("pageOrder", []):
            pdir = self.defn / "pages" / pid
            pg = _load(pdir / "page.json")
            raw = {}
            vdir = pdir / "visuals"
            if vdir.exists():
                for vd in vdir.iterdir():
                    f = vd / "visual.json"
                    if f.exists():
                        raw[vd.name] = _load(f)
            visuals = [self._visual(vid, d, raw, pid) for vid, d in raw.items()]
            pprops = []
            self._walk(pg.get("objects"), "page", pprops)
            pages.append(Page(pid, (pg.get("displayName") or pid).strip(), pg.get("displayName") or pid,
                              pg.get("width", 0), pg.get("height", 0), pg.get("displayOption", ""),
                              pg.get("type", "Standard"), pg.get("visibility", "AlwaysVisible"), visuals, pprops))
        return pages

    def _visual(self, vid, d, raw, pid) -> Visual:
        def absolute(v, seen=()):
            dd = raw[v]
            p = dd.get("position", {})
            x, y = p.get("x", 0), p.get("y", 0)
            par = dd.get("parentGroupName")
            if par and par in raw and par not in seen:
                px, py = absolute(par, seen + (v,))
                return x + px, y + py
            return x, y
        p = d.get("position", {})
        ax, ay = absolute(vid)
        v = d.get("visual", {})
        vtype = v.get("visualType") or ("group" if "visualGroup" in d else "unknown")
        vis = Visual(vid, pid, vtype, d.get("parentGroupName"), ax, ay, p.get("width", 0), p.get("height", 0),
                     p.get("z", 0), d)
        self._walk(v.get("objects"), "objects", vis.props)
        self._walk(v.get("visualContainerObjects"), "container", vis.props)
        return vis

    def _walk(self, objs, group, sink):
        for oname, entries in (objs or {}).items():
            for e in entries or []:
                sel = e.get("selector", {}) or {}
                sel_s = sel.get("id") or sel.get("metadata") or ("data" if "data" in sel else "")
                for pname, pval in (e.get("properties") or {}).items():
                    sink.append((group, oname, pname, sel_s, self.literal(pval)))

    # ---------------------------------------------------------------- values
    def literal(self, v):
        if isinstance(v, dict):
            if "expr" in v:
                return self.literal(v["expr"])
            if "Literal" in v:
                raw = v["Literal"].get("Value")
                if isinstance(raw, str):
                    if raw.startswith("'") and raw.endswith("'"):
                        return raw[1:-1]
                    if raw[-1:] in ("D", "L") and raw[:-1].replace(".", "", 1).lstrip("-").isdigit():
                        return float(raw[:-1])
                    if raw in ("true", "false"):
                        return raw == "true"
                return raw
            if "solid" in v and "color" in v["solid"]:
                return self.literal(v["solid"]["color"])
            if "ThemeDataColor" in v:
                t = v["ThemeDataColor"]
                i = t.get("ColorId", 0)
                base = self.theme_colors[i] if i < len(self.theme_colors) else "#000000"
                return shade(base, float(t.get("Percent", 0)))
            s = json.dumps(v)
            return "<measure>" if "Measure" in s else ("<rule>" if ("Conditional" in s or "FillRule" in s) else "<expr>")
        return v

    def theme_style(self, vtype: str, obj: str, prop: str, selector: str = ""):
        vs = self.theme.get("visualStyles", {})
        for key in (vtype, "*"):
            for e in vs.get(key, {}).get("*", {}).get(obj, []):
                if e.get("$id", "") in ("", selector) and prop in e:
                    val = e[prop]
                    if isinstance(val, dict) and "solid" in val:
                        val = val["solid"]["color"]
                    return val
        return None

    def effective(self, v: Visual, obj: str, prop: str, selector: str = ""):
        for g, o, p, s, val in v.props:
            if o == obj and p == prop and s in ("", selector):
                return val
        return self.theme_style(v.vtype, obj, prop, selector)

    def page_by_id(self, pid):
        return next((p for p in self.pages if p.id == pid), None)
