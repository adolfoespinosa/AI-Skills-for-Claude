<!--
STATUS: v0.1 (Step 6, batch 3)
PURPOSE: The checks that scripts cannot do; performed on screenshots from powerbi-report-cli.
LOADED: reviews with screenshots (after the automated compliance check).
-->
# Visual Review (manual checks)

Run this **after** the automated compliance check, on screenshots taken by `powerbi-report-cli` (authoring:
screenshot review) of the **Dark page and its Light twin**. Only judge what is listed here. Everything else is
covered by rules.

| ID | Check | Fail when… |
|---|---|---|
| VR-01 | Truncation | Titles, headers, labels or slicer values are cut off or show "…" |
| VR-02 | Label collisions | Data labels overlap each other or the line, or labels sit outside the plot |
| VR-03 | Density | A panel shows more than one analytical question, or a matrix needs horizontal scrolling at 1280 × 720 |
| VR-04 | Hierarchy | The eye does not land first on the page title and then the KPI row or main panel |
| VR-05 | Empty and blank states | Visuals show "(Blank)", empty frames, or error icons with the default filter selection |
| VR-06 | Twin visual parity | The Light twin looks structurally different from Dark (beyond colour) |
| VR-07 | Readability of accepted deviations | AD-001…005 pairs are still legible at 100% zoom; negatives keep their minus sign |
| VR-08 | Scenario legibility | ACT, FCT and REF can be told apart without the legend (line style, labels) |
| VR-09 | Scrollbars | A textbox or table shows an unintended scrollbar |

Output: add the results to the compliance report under **Visual review** (`PASSED` / `FAILED` + screenshot
reference). VR items are warnings unless they hide information (VR-01, VR-05), in which case they are
critical.
