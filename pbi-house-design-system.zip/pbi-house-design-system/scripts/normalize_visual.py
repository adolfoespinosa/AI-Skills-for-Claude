#!/usr/bin/env python3
"""
normalize_visual.py: turn a raw PBIR visual.json (from any dashboard) into a DRAFT blueprint (D19).

Steps
  1. IDs and position      name → {{VISUAL_ID}} · position → {{X}} {{Y}} {{Z}} {{W}} {{H}} {{TAB}} (slot comes from the manifest)
  2. Bindings              every (table, column/measure) → {{FIELD_n.table}} / {{FIELD_n.column}} (+ queryRef, nativeQueryRef)
                           syncGroup.groupName → {{SYNC_GROUP}}
  3. Literal data removed  saved slicer selection (objects.general.filter) and filterConfig → dropped (GDPR / stale values)
  4. Text parameters       container title text → {{NAME}} (Selection-pane name) · other literal texts → {{TEXT_n}}
  5. Minimal diff          a property equal to the effective house theme value (Dark) is dropped
  6. Rule screening        font families outside the house fonts → dropped (TYPO) · sizes off the type scale → flagged
  7. Colours → tokens      remaining colours become "{{token:<semantic path>}}" (binder resolves per mode)

Output: <out>/<variant>.draft.visual.json + <variant>.findings.json. Nothing is approved automatically:
a human reviews the findings, then writes the final <variant>.visual.json + <variant>.manifest.yaml.

Usage: python scripts/normalize_visual.py --in inbox/visuals/<name>/visual.json --id <family>/<variant>
"""
from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _tokens as T  # noqa: E402
from _pbir import shade  # noqa: E402

SKILL = T.SKILL_ROOT
PREFER = {"slicer": ("control.",), "advancedSlicerVisual": ("selection.", "hover.", "press."), "listSlicer": ("control.", "selection.")}
STATE_PREFER = {"default": ("selection.unselected",), "interaction:rest": ("selection.unselected",),
                "selection:selected": ("selection.fill", "selection.text"), "interaction:hover": ("hover.",),
                "interaction:press": ("press.",)}
POS = {"x": "{{X}}", "y": "{{Y}}", "z": "{{Z}}", "width": "{{W}}", "height": "{{H}}", "tabOrder": "{{TAB}}"}


def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))


class Normalizer:
    def __init__(self, raw: dict):
        self.raw = raw
        self.d = copy.deepcopy(raw)
        self.tokens = T.load()
        theme_p = sorted((SKILL / "assets" / "themes").glob("corporate-dark.*.json"))[-1]
        self.theme = load(theme_p)
        self.fields: dict[tuple, str] = {}
        self.texts: dict[str, str] = {}
        self.findings: list[dict] = []
        self.fonts = {v for k, v in self.tokens["primitive"]["font"].items() if k.startswith("render_")}
        self.scale = set(self.tokens["primitive"]["size"])

    # ---------- helpers
    def note(self, kind, path, action, detail="", rule=None):
        self.findings.append({"kind": kind, "path": path, "action": action, "detail": detail, **({"rule": rule} if rule else {})})

    def literal(self, v):
        """PBIR property value → python value (hex for colours)."""
        if isinstance(v, dict) and "solid" in v:
            v = v["solid"]["color"]
        if isinstance(v, dict) and "expr" in v:
            e = v["expr"]
            if "ThemeDataColor" in e:
                cid, pct = e["ThemeDataColor"]["ColorId"], e["ThemeDataColor"].get("Percent", 0)
                base = {0: self.theme["foreground"], 1: self.theme["background"]}.get(cid) or self.theme["dataColors"][cid - 2]
                return shade(base.upper(), pct) if pct else base.upper()
            if "Literal" in e:
                s = e["Literal"]["Value"]
                if s in ("true", "false"):
                    return s == "true"
                if s.endswith(("D", "L")) and s[:-1].replace(".", "", 1).lstrip("-").isdigit():
                    return float(s[:-1])
                if s.startswith("'") and s.endswith("'"):
                    s = s[1:-1].replace("''", "'")
                    return s.upper() if s.startswith("#") else s
        if isinstance(v, str) and v.startswith("#"):
            return v.upper()
        return v

    def theme_value(self, vtype, obj, prop, sel=""):
        vs = self.theme.get("visualStyles", {})
        for vt in (vtype, "*"):
            for entry in vs.get(vt, {}).get("*", {}).get(obj, []):
                if entry.get("$id", "") == sel and prop in entry:
                    return self.literal(entry[prop])
        return None

    def color_tokens(self, hexv, vtype="", sel=""):
        out = []
        for path, _ in T.mode_maps(self.tokens["semantic"]["color"], "semantic.color"):
            if T.resolve_path(self.tokens, path, "dark").upper() == hexv:
                out.append(path.replace("semantic.color.", ""))
        pref = STATE_PREFER.get(sel) if vtype == "advancedSlicerVisual" and sel in STATE_PREFER else PREFER.get(vtype, ())
        return sorted(out, key=lambda c: not c.startswith(pref)) if pref else out

    # ---------- steps
    def ids_and_position(self):
        self.d["name"] = "{{VISUAL_ID}}"
        self.d["position"] = dict(POS)
        self.d.pop("parentGroupName", None)
        self.note("structure", "name/position", "parameterised", "slot from manifest; IDs generated at bind time")

    def bindings(self, node):
        if isinstance(node, dict):
            for key in ("Column", "Measure", "Aggregation", "HierarchyLevel"):
                f = node.get(key)
                if isinstance(f, dict) and "Property" in f and "Entity" in f.get("Expression", {}).get("SourceRef", {}):
                    k = (f["Expression"]["SourceRef"]["Entity"], f["Property"])
                    n = self.fields.setdefault(k, f"FIELD_{len(self.fields) + 1}")
                    f["Expression"]["SourceRef"]["Entity"] = "{{%s.table}}" % n
                    f["Property"] = "{{%s.column}}" % n
            for v in node.values():
                self.bindings(v)
            if "queryRef" in node:
                for (t, c), n in self.fields.items():
                    if node["queryRef"] == f"{t}.{c}":
                        node["queryRef"] = "{{%s.table}}.{{%s.column}}" % (n, n)
                    if node.get("nativeQueryRef") == c:
                        node["nativeQueryRef"] = "{{%s.column}}" % n
        elif isinstance(node, list):
            for v in node:
                self.bindings(v)

    def literal_data(self):
        v = self.d.get("visual", {})
        for e in v.get("objects", {}).get("general", []):
            if "filter" in e.get("properties", {}):
                flt = e["properties"]["filter"]
                vals = json.dumps(flt.get("filter", flt).get("Where", []))
                e["properties"].pop("filter")
                self.note("data", "objects.general.filter", "removed", f"saved selection ({len(vals)} chars of literal values)", "DATA")
        if "filterConfig" in self.d:
            self.d.pop("filterConfig")
            self.note("data", "filterConfig", "removed", "visual-level filters (IDs / literals); Desktop recreates them")
        vt = v.get("visualContainerObjects", {}).get("visualTooltip")
        if vt and "section" in json.dumps(vt):
            v["visualContainerObjects"].pop("visualTooltip")
            self.note("data", "visualContainerObjects.visualTooltip", "removed", "report-page tooltip link (page id of the source report)")
        sg = v.get("syncGroup")
        if sg and "groupName" in sg:
            self.note("binding", "syncGroup.groupName", "parameterised", f"was '{sg['groupName']}' → {{{{SYNC_GROUP}}}}")
            sg["groupName"] = "{{SYNC_GROUP}}"

    def texts_and_props(self):
        v = self.d.get("visual", {})
        vtype = v.get("visualType", "")
        for section in ("objects", "visualContainerObjects"):
            objs = v.get(section, {})
            for obj, entries in list(objs.items()):
                for e in entries:
                    props = e.get("properties", {})
                    for prop, val in list(props.items()):
                        path = f"{section}.{obj}.{prop}"
                        lv = self.literal(val)
                        if prop == "text" and isinstance(lv, str):
                            key = "NAME" if (section, obj) == ("visualContainerObjects", "title") else f"TEXT_{len(self.texts) + 1}"
                            self.texts[key] = lv
                            props[prop] = {"expr": {"Literal": {"Value": "'{{%s}}'" % key}}}
                            self.note("text", path, "parameterised", f"{{{{{key}}}}} default '{lv}'")
                            continue
                        sel = (e.get("selector") or {}).get("id", "")
                        if e.get("selector") and not sel:
                            continue                      # data-point selectors (per series) are kept as-is
                        path = f"{section}.{obj}" + (f"[{sel}]" if sel else "") + f".{prop}"
                        vl = next((r for r in self.tokens["component"].get("visual_level", [])
                                   if (r["visual"], r["object"], r["property"]) == (vtype, obj, prop)
                                   and (r.get("selector") or "") == sel), None)
                        if vl:
                            want = T.visual_level_value(self.tokens, vl)
                            props.pop(prop)
                            self.note("visual", path, "dropped", f"{lv} · written by bind_blueprint from component.visual_level ({want})"
                                      + ("" if str(lv) in (str(want), f"{want}.0") else f" · source {lv} differs from house {want}"))
                            continue
                        tv = self.theme_value(vtype, obj, prop, sel)
                        if prop == "fontFamily" and isinstance(lv, str):
                            lv = lv.split(",")[0].strip("' ")
                        if prop == "fontFamily" and isinstance(tv, str):
                            tv = tv.split(",")[0].strip("' ")
                        if tv is not None and (tv == lv or (isinstance(tv, (int, float)) and isinstance(lv, (int, float)) and abs(tv - lv) < 1e-6)):
                            props.pop(prop)
                            self.note("theme", path, "dropped", f"= theme ({lv})")
                            continue
                        if prop == "fontFamily":
                            fam = lv.split(",")[0].strip("' ") if isinstance(lv, str) else lv
                            if fam not in self.fonts:
                                props.pop(prop)
                                self.note("rule", path, "dropped", f"'{fam}' is not a house font → theme {tv}", "TYPO-001")
                            else:
                                props[prop] = T.pbir_font_literal(self.tokens, fam)   # FS1 · stack, never the bare name
                                self.note("decision", path, "kept", f"'{fam}' differs from theme {tv} · check type role", "SLICER-006")
                            continue
                        if prop in ("textSize", "fontSize") and isinstance(lv, float) and int(lv) not in self.scale:
                            self.note("rule", path, "flagged", f"{lv} pt not on the type scale {sorted(self.scale)}", "TYPO-002")
                        if isinstance(lv, str) and lv.startswith("#") and len(lv) == 7:
                            cands = self.color_tokens(lv, vtype, sel)
                            if cands:
                                props[prop] = {"solid": {"color": "{{token:%s}}" % cands[0]}}
                                self.note("color", path, "tokenised", f"{lv} → {cands[0]}" + (f" (also: {', '.join(cands[1:4])})" if len(cands) > 1 else ""))
                            else:
                                self.note("rule", path, "flagged", f"{lv} not in the palette", "COLOR-001")
                entries[:] = [e for e in entries if e.get("properties") or e.get("selector") and not e["selector"].get("id")]
                if not entries:
                    objs.pop(obj)

    def run(self):
        self.ids_and_position()
        self.bindings(self.d)
        self.literal_data()
        self.texts_and_props()
        params = {**{n: {"source": f"{t}[{c}]"} for (t, c), n in self.fields.items()},
                  **{k: {"default": v} for k, v in self.texts.items()}}
        return self.d, {"visualType": self.d.get("visual", {}).get("visualType"), "parameters": params,
                        "source_position": self.raw.get("position"), "findings": self.findings}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="src", required=True)
    ap.add_argument("--id", required=True, help="<family>/<variant>, e.g. slicer/period-dropdown")
    ap.add_argument("--out", default=str(SKILL / "assets" / "blueprints"))
    a = ap.parse_args()
    family, variant = a.id.split("/", 1)
    out = Path(a.out) / family
    out.mkdir(parents=True, exist_ok=True)
    bp, rep = Normalizer(load(a.src)).run()
    (out / f"{variant}.draft.visual.json").write_text(json.dumps(bp, indent=2, ensure_ascii=False), encoding="utf-8")
    (out / f"{variant}.findings.json").write_text(json.dumps(rep, indent=2, ensure_ascii=False), encoding="utf-8")
    kinds = {}
    for f in rep["findings"]:
        kinds[f["kind"]] = kinds.get(f["kind"], 0) + 1
    print(f"DRAFT {a.id} · {rep['visualType']} · params {list(rep['parameters'])} · findings {kinds}")
    for f in rep["findings"]:
        print(f"  [{f['kind']:<9}] {f['action']:<13} {f['path']:<45} {f['detail']}" + (f"  ({f['rule']})" if 'rule' in f else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
