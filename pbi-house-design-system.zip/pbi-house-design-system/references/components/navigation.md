<!--
STATUS: v0.1 (Step 6, batch 2)
PURPOSE: Navigation model, icon buttons, page naming (NAV-*).
LOADED: navigation, buttons, page names, hidden pages.
-->
# Navigation

## 1. Model

| Element | Where | Action |
|---|---|---|
| Landing page ("Intro") | First page, **locked template** (`components/intro-page.md`, PAGE-008/009) | Page navigators in the template list the pages automatically |
| Icon cluster | band.bottom, right (x 1152, 1086, … leftwards) | home → landing · back → `Back` · info → `WebUrl` (tutorial) · reset → `Bookmark` (Erase) or `ClearAllSlicers` |
| Mode toggle | band.bottom, x 1218 (rightmost) | `PageNavigation` to the twin (MODE-005) |
| Detail pages | Hidden, reached by buttons or drillthrough | Must offer back (and home) |

## 2. Icon buttons

| Property | Standard |
|---|---|
| Size | **50 × 50**, y 663 (PC1) |
| Icon | From `assets/icons/` (SVG). Built-in shapes allowed: back, information, reset |
| States | default: icon `accent.primary` (Dark orange, allowed by COLOR-004 · Light slate) on transparent · hover: `hover.fill` · selected: `selection.*` |
| Tooltip | Always set (what the button does) |

## 3. Rules

```yaml
- id: NAV-001
  title: Icon cluster in the bottom band
  status: active
  since: 0.1.0
  severity: critical
  priority: P2
  modes: [dark, light]
  applies_to: [actionButton]
  statement: "Navigation icon buttons MUST be in band.bottom, right-aligned before the mode toggle, 50 × 50, 16 px apart."
  check: auto
  exceptions: allowed

- id: NAV-002
  title: Hidden pages offer a way back
  status: active
  since: 0.1.0
  severity: critical
  priority: P4
  modes: [dark, light]
  applies_to: [page]
  statement: "Every hidden page reached by navigation or drillthrough MUST contain a back (or home) button."
  check: auto
  exceptions: allowed

- id: NAV-003
  title: Buttons have tooltips
  status: active
  since: 0.1.0
  severity: warning
  priority: P1
  modes: [dark, light]
  applies_to: [actionButton]
  statement: "Every icon-only button MUST have a tooltip describing its action."
  check: auto
  exceptions: allowed

- id: NAV-004
  title: Button states use tokens
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [actionButton]
  statement: "Button default / hover / selected / disabled states MUST use the tokens in section 2."
  check: auto
  exceptions: allowed

- id: NAV-005
  title: Navigation targets exist
  status: active
  since: 0.1.0
  severity: critical
  priority: P0
  modes: [dark, light]
  applies_to: [actionButton, pageNavigator, bookmarkNavigator]
  statement: "Every PageNavigation / Bookmark target MUST exist (no orphan bookmarks or pages)."
  check: auto
  exceptions: forbidden

- id: NAV-006
  title: Page display names
  status: active
  since: 0.1.0
  severity: warning
  priority: P5
  modes: [dark, light]
  applies_to: [page]
  statement: "Page display names MUST NOT start with spaces. They MAY start with the emoji prefix convention (e.g. '▶ 📄 '). The page hierarchy MUST be documented in house.lock.yaml › page_hierarchy, not encoded in the name. Page names use Title Case (TEXT-006)."
  check: auto
  exceptions: allowed
```

## 3b. Navigator visuals (v0.4.1)

```yaml
- id: NAV-007
  title: Navigators never show a title bar
  status: active
  since: 0.4.1
  severity: critical
  priority: P2
  modes: [dark, light]
  applies_to: [pageNavigator, bookmarkNavigator]
  statement: "Page and bookmark navigators MUST have title.show = false and container background.show = false (set in the theme and explicitly on the visual)."
  check: auto
  exceptions: forbidden
```

## 4. Decision N1 (2026-10-04)
Keep the emoji prefix, remove leading spaces, and document the hierarchy in `house.lock.yaml`:
```yaml
page_hierarchy:
  - page: "▶ 📊 Summary"
    children: ["▶ 📄 Profit & Loss", "▶ 📄 Revenue"]
```
Renaming pages is a brownfield change. Bookmarks and navigation targets use page IDs, so they survive, but
the plan must still list every renamed page.
