#!/usr/bin/env python3
"""
check_tokens.py: validate tokens/tokens.yaml (Step 7).

Checks
  T1  JSON-schema structure (tokens/tokens.schema.json)
  T2  Literal HEX only in primitive.color
  T3  Mode parity: every semantic colour declares exactly dark + light
  T4  Every reference resolves in both modes, without cycles; colours resolve to #RRGGBB
  T5  Token placeholders used in rule blocks (references/**/*.md) exist
  T6  Accepted deviations (foundations/color.md) reference existing tokens
  T7  Unused primitive colours (warning)

Exit code 0 = OK (warnings allowed), 1 = errors.
Usage: python scripts/check_tokens.py [--tokens path] [--json]
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _tokens as T  # noqa: E402

try:
    import jsonschema
except ImportError:  # schema check becomes a warning
    jsonschema = None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tokens", default=str(T.TOKENS_PATH))
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    errors, warnings = [], []
    tokens = T.load(a.tokens)

    # T1 schema
    schema_path = T.SKILL_ROOT / "tokens" / "tokens.schema.json"
    if jsonschema is None:
        warnings.append("T1 jsonschema not installed: schema check skipped")
    else:
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        validator_cls = getattr(jsonschema, "Draft202012Validator", None) or jsonschema.Draft7Validator
        for e in validator_cls(schema).iter_errors(tokens):
            errors.append(f"T1 schema: {'/'.join(map(str, e.path))}: {e.message}")

    # T2 literal HEX outside primitive.color
    for path, value in T.walk(tokens):
        if isinstance(value, str) and T.HEX.match(value) and not path.startswith("primitive.color."):
            errors.append(f"T2 literal HEX outside primitive.color: {path} = {value}")

    # T3 parity
    for path, node in T.mode_maps(tokens["semantic"]["color"], "semantic.color"):
        if set(node.keys()) != set(T.MODES):
            errors.append(f"T3 mode parity: {path} has {sorted(node.keys())}")

    # T4 resolution
    used_refs = set()
    for path, value in T.walk(tokens):
        if isinstance(value, str) and T.REF.fullmatch(value.strip()):
            used_refs.add(T.expand_alias(T.REF.fullmatch(value.strip()).group(1)))
    for path, node in T.mode_maps(tokens["semantic"]["color"], "semantic.color"):
        for mode in T.MODES:
            try:
                v = T.resolve_path(tokens, path, mode)
                if not (isinstance(v, str) and T.HEX.match(v)):
                    errors.append(f"T4 {path} [{mode}] resolves to non-colour: {v!r}")
            except T.TokenError as e:
                errors.append(f"T4 {path} [{mode}]: {e}")
    for path, value in T.walk(tokens):
        if path.startswith("semantic.color.") or not isinstance(value, str):
            continue
        if T.REF.fullmatch(value.strip()):
            for mode in T.MODES:
                try:
                    T.resolve(tokens, value, mode)
                except T.TokenError as e:
                    errors.append(f"T4 {path} [{mode}]: {e}")

    # T5 placeholders in rule blocks
    special = {"tokens.all_color_values[mode]"}
    for file, data in T.load_rule_blocks():
        for ph in re.findall(r"\{([A-Za-z_][A-Za-z0-9_.\-*\[\]]*)\}", json.dumps(data, ensure_ascii=False, default=str)):
            if ph in special or ph.startswith(("x(", "tokens.")):
                continue
            path = T.expand_alias(ph.rstrip(".*").rstrip("*").rstrip("."))
            try:
                T.get(tokens, path)
            except T.TokenError:
                errors.append(f"T5 {file}: placeholder {{{ph}}} does not resolve ({path})")

    # T6 accepted deviations
    for ad in T.accepted_deviations():
        for pair in ad.get("pairs", []):
            for key in ("fg", "bg"):
                try:
                    T.get(tokens, T.expand_alias(pair[key]))
                except (T.TokenError, KeyError):
                    errors.append(f"T6 {ad.get('id')}: unknown token {pair.get(key)}")

    # T7 unused primitives
    for name in tokens["primitive"]["color"]:
        if f"primitive.color.{name}" not in used_refs:
            warnings.append(f"T7 unused primitive colour: {name}")

    result = {"tokens": a.tokens, "version": tokens["meta"]["version"],
              "errors": errors, "warnings": warnings,
              "status": "FAILED" if errors else "PASSED"}
    if a.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print(f"TOKENS CHECK · v{result['version']} · {result['status']}")
        for e in errors:
            print("  ERROR  ", e)
        for w in warnings:
            print("  warn   ", w)
        if not errors and not warnings:
            print("  all checks passed")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
