# Fixtures

Synthetic visual.json / page.json fragments (no business or personal data). good/ must pass, bad/ must fail with the expected rule IDs.
