<!--
STATUS: v0.1 (Step 6, batch 1)
PURPOSE: Light/Dark twin-page model (D16), Light override profile, MODE-* parity rules.
LOADED: creating pages, Light/Dark work, and any change to a page that has a twin.
-->
# Modes: Dark default, Light twin pages

## 1. Model

Power BI allows **one theme per report**, and there is no runtime theme switch. The house model is:

| Element | Decision |
|---|---|
| Default mode | **Dark** (D15). Landing and visible pages are Dark |
| Theme | `assets/themes/corporate-dark.<ver>.json`, generated from tokens |
| Light | A **twin page** per Dark page: display name `"<Dark name> Light"`, visibility `HiddenInViewMode` |
| Light styling | **Light override profile** `assets/themes/light-overrides.<ver>.json`, generated from tokens: per visual type, the property → token values that differ from Dark |
| Switching | A toggle button in the bottom band (bottom right), icon moon on Dark pages and sun on Light pages, action `PageNavigation` to the twin |

```text
 Dark page "P&L RHG"  ──(🌙 button)──►  Light page "P&L RHG Light" (hidden)
        ▲                                         │
        └───────────────(☀ button)───────────────┘
```

## 2. What may differ between twins

| May differ | Must be identical |
|---|---|
| Colour properties (fill, font colour, background, border colour, outline colour, gridline colour, data colours, CF colours) | Visual set, visual types, names, x/y/width/height/z |
| Toggle icon (moon ↔ sun) and its navigation target | Field bindings (projections), measures, sort |
| Logo image variant (Dark-background ↔ Light-background) | Filters (visual, page), slicer configuration |
| **Mode-specific measures** named `<measure> Light` replacing `<measure>` (e.g. icon or SVG measures coloured for Light) | — |
| Shadow colour if the token differs | Bookmarks targets, tooltips, drillthrough, navigation targets (other than the toggle) |
| — | Font family, size, weight; borders width/radius; padding |

## 3. Rules

```yaml
- id: MODE-001
  title: Twin parity
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [page]
  statement: "A Dark page and its Light twin MUST be identical except for the properties listed as 'May differ' in section 2."
  check: auto            # scripts/check_twins.py
  exceptions: allowed

- id: MODE-002
  title: Every visible page has a twin
  status: active
  since: 0.1.0
  severity: warning
  priority: P5
  modes: [dark]
  applies_to: [page]
  statement: "Every visible Dark standard page MUST have a Light twin named '<name> Light'. Utility pages (data check, tooltips, KPI calculation pages) are exempt if listed in house.lock.yaml › twin_exempt."
  check: auto
  exceptions: allowed

- id: MODE-003
  title: Light styling comes from the override profile
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [light]
  applies_to: ["*"]
  statement: "Every colour override on a Light page MUST match the Light override profile (light-overrides.json) for that visual type and property."
  check: auto
  exceptions: allowed

- id: MODE-004
  title: Twin naming and visibility
  status: active
  since: 0.1.0
  severity: warning
  priority: P5
  modes: [light]
  applies_to: [page]
  statement: "Light twins MUST be named '<Dark name> Light' and set to HiddenInViewMode."
  check: auto
  exceptions: allowed

- id: MODE-005
  title: Mode toggle
  status: active
  since: 0.1.0
  severity: critical
  priority: P5
  modes: [dark, light]
  applies_to: [actionButton]
  statement: "Each twin MUST have exactly one mode toggle in band.bottom (rightmost, 50 × 50 at x 1218, y 663), with PageNavigation to its twin, a moon icon on Dark and a sun icon on Light."
  check: auto
  exceptions: allowed

- id: MODE-006
  title: Changes apply to both twins
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [plan]
  statement: "Every remediation plan or content change that touches a page MUST include the same change on its twin (colour changes resolved per mode)."
  check: auto            # plan validation + MODE-001 after build
  exceptions: forbidden

- id: MODE-007
  title: Dark-first build order
  status: active
  since: 0.1.0
  severity: info
  priority: P6
  modes: [dark, light]
  applies_to: [workflow]
  statement: "Build and approve the Dark page first, then generate the Light twin by duplicating it and applying the Light override profile."
  check: manual
  exceptions: allowed
```

## 3b. Tooling
`scripts/make_light_twin.py --report <.Report> --page "<Dark page>" [--replace]` builds the twin
deterministically (decision D1a): new visual IDs, the Light override profile and role profiles, the token
colour map for explicit colours, logo-white→logo-blue, moon→sun, and toggles linked both ways.
Re-run it with `--replace` after changing the Dark page.

## 4. Notes
- Duplicating a page creates new visual IDs. Bookmarks that target visuals by name must be duplicated or
  retargeted for the twin. The plan must list them.
- `check_twins.py` matches visuals across twins by type + position (+ title), because their IDs differ.
- If a future Power BI version allows runtime theme switching, MODE-* will be revised in a MAJOR version.
