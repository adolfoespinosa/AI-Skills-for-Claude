# Design Compliance Report

**Report:** Operational Report - Fabric.Report · **Design System:** v0.1.0 · **Pages:** 30 (+0 twins) · **Visuals:** 832 · **Date:** 2026-10-05
**Status:** FAILED

| Status | Count | By rule |
|---|---|---|
| Critical | 876 | COLOR-001 ×164, TYPO-001 ×160, LAYOUT-003 ×158, LAYOUT-004 ×151, LAYOUT-005 ×78, LAYOUT-008 ×62, PAGE-004 ×30, KPI-001 ×29, PAGE-001 ×23, COLOR-005 ×9, TYPO-002 ×6, NAV-005 ×5, LAYOUT-001 ×1 |
| Warnings | 559 | LAYOUT-007 ×306, FMT-002 ×205, NAV-006 ×16, MODE-002 ×13, KPI-005 ×12, LAYOUT-002 ×3, TIP-001 ×2, COLOR-009 ×2 |
| Waived | 0 | — |
| Baseline | 0 | — |
| Passed rules | 6 | ACCESS-004, CHART-001, COLOR-006, COLOR-011, MODE-004, PAGE-002 |
| Not evaluated rules | 79 | manual / assisted / not yet automated |

## Critical
| Rule | Page | Visual | Property | Expected | Found |
|---|---|---|---|---|---|
| LAYOUT-005 | Intro | group 108a61bf | position | inside one band | y 240–709 |
| LAYOUT-005 | Intro | image 7a0165a5 | position | inside one band | y 333–720 |
| LAYOUT-005 | Intro | textbox 93d3b081 | position | inside one band | y 60–250 |
| LAYOUT-005 | Intro | image a957cdd5 | position | inside one band | y 11–277 |
| LAYOUT-003 | Intro | card 412c5c9b | x | column start | 292.2 |
| LAYOUT-003 | Intro | tableEx 465e0c6f | x | column start | 307.3 |
| LAYOUT-003 | Intro | textbox 9b6d8088 | x | column start | 1156.3 |
| LAYOUT-003 | Intro | actionButton e248e339 | x | column start | 54.0 |
| LAYOUT-004 | Intro | card 412c5c9b | width | span width | 439.1 |
| LAYOUT-004 | Intro | tableEx 465e0c6f | width | span width | 394.5 |
| LAYOUT-004 | Intro | textbox 9b6d8088 | width | span width | 123.9 |
| LAYOUT-008 | Intro | tableEx 465e0c6f | bounds | no overlap | overlaps card 412c5c9b |
| LAYOUT-005 | ▶ 📊 Summary | group 20d4cc11 | position | inside one band | y 0–656 |
| LAYOUT-003 | ▶ 📊 Summary | shape 16a7682b | x | column start | 1081.0 |
| LAYOUT-003 | ▶ 📊 Summary | group 23bb8698 | x | column start | 657.0 |
| LAYOUT-003 | ▶ 📊 Summary | group 2a961b3b | x | column start | 11.0 |
| LAYOUT-003 | ▶ 📊 Summary | clusteredColumnChart 749731af | x | column start | 657.0 |
| LAYOUT-003 | ▶ 📊 Summary | group 7890a790 | x | column start | 10.0 |
| LAYOUT-003 | ▶ 📊 Summary | group 8324e82c | x | column start | 11.0 |
| LAYOUT-003 | ▶ 📊 Summary | clusteredBarChart bd5dad09 | x | column start | 11.0 |
| LAYOUT-003 | ▶ 📊 Summary | advancedSlicerVisual f5a0441b | x | column start | 660.7 |
| LAYOUT-003 | ▶ 📊 Summary | group e235df67 | x | column start | 0.0 |
| LAYOUT-004 | ▶ 📊 Summary | shape 16a7682b | width | span width | 170.9 |
| LAYOUT-004 | ▶ 📊 Summary | group 23bb8698 | width | span width | 603.0 |
| LAYOUT-004 | ▶ 📊 Summary | group 2a961b3b | width | span width | 1248.0 |
| LAYOUT-004 | ▶ 📊 Summary | clusteredColumnChart 749731af | width | span width | 603.0 |
| LAYOUT-004 | ▶ 📊 Summary | group 7890a790 | width | span width | 1249.3 |
| LAYOUT-004 | ▶ 📊 Summary | group 8324e82c | width | span width | 604.0 |
| LAYOUT-004 | ▶ 📊 Summary | clusteredBarChart bd5dad09 | width | span width | 604.7 |
| LAYOUT-004 | ▶ 📊 Summary | advancedSlicerVisual f5a0441b | width | span width | 57.5 |
| LAYOUT-008 | ▶ 📊 Summary | group 7890a790 | bounds | no overlap | overlaps group 2a961b3b |
| LAYOUT-008 | ▶ 📊 Summary | advancedSlicerVisual f5a0441b | bounds | no overlap | overlaps clusteredColumnChart 749731af |
| LAYOUT-005 | ▶ 📄 Profit & Loss | group 1f004e77 | position | inside one band | y 1–657 |
| LAYOUT-005 | ▶ 📄 Profit & Loss | tableEx da229b26 | position | inside one band | y 91–657 |
| LAYOUT-005 | ▶ 📄 Profit & Loss | waterfallChart e1911ad8 | position | inside one band | y 395–657 |
| LAYOUT-003 | ▶ 📄 Profit & Loss | advancedSlicerVisual 3b18fde9 | x | column start | 490.1 |
| LAYOUT-003 | ▶ 📄 Profit & Loss | textbox 86093dc6 | x | column start | 746.7 |
| LAYOUT-003 | ▶ 📄 Profit & Loss | pageNavigator 9905f92c | x | column start | 2.9 |
| LAYOUT-003 | ▶ 📄 Profit & Loss | shape cac22f5b | x | column start | 11.1 |
| LAYOUT-003 | ▶ 📄 Profit & Loss | cardVisual d4e66b79 | x | column start | 360.3 |
| LAYOUT-003 | ▶ 📄 Profit & Loss | lineChart d959adbc | x | column start | 489.8 |
| LAYOUT-003 | ▶ 📄 Profit & Loss | textbox f11353b8 | x | column start | 1148.5 |
| LAYOUT-003 | ▶ 📄 Profit & Loss | group a2de6f7b | x | column start | 0.0 |
| LAYOUT-004 | ▶ 📄 Profit & Loss | advancedSlicerVisual 3b18fde9 | width | span width | 98.2 |
| LAYOUT-004 | ▶ 📄 Profit & Loss | shape 54a01784 | width | span width | 88.9 |
| LAYOUT-004 | ▶ 📄 Profit & Loss | textbox 86093dc6 | width | span width | 314.1 |
| LAYOUT-004 | ▶ 📄 Profit & Loss | pageNavigator 9905f92c | width | span width | 462.1 |
| LAYOUT-004 | ▶ 📄 Profit & Loss | shape cac22f5b | width | span width | 462.0 |
| LAYOUT-004 | ▶ 📄 Profit & Loss | cardVisual d4e66b79 | width | span width | 112.4 |
| LAYOUT-004 | ▶ 📄 Profit & Loss | lineChart d959adbc | width | span width | 766.8 |
| LAYOUT-004 | ▶ 📄 Profit & Loss | textbox f11353b8 | width | span width | 58.6 |
| LAYOUT-008 | ▶ 📄 Profit & Loss | lineChart d959adbc | bounds | no overlap | overlaps advancedSlicerVisual 3b18fde9 |
| LAYOUT-008 | ▶ 📄 Profit & Loss | lineChart d959adbc | bounds | no overlap | overlaps textbox 86093dc6 |
| LAYOUT-005 | ▶ 📄 Revenue | tableEx 4269e2de | position | inside one band | y 91–657 |
| LAYOUT-005 | ▶ 📄 Revenue | group a1835d8b | position | inside one band | y 0–656 |
| LAYOUT-005 | ▶ 📄 Revenue | columnChart cd6d2ad0 | position | inside one band | y 395–661 |
| LAYOUT-003 | ▶ 📄 Revenue | advancedSlicerVisual 0b820961 | x | column start | 490.1 |
| LAYOUT-003 | ▶ 📄 Revenue | cardVisual 29f9a75c | x | column start | 360.3 |
| LAYOUT-003 | ▶ 📄 Revenue | textbox 3379122a | x | column start | 731.9 |
| LAYOUT-003 | ▶ 📄 Revenue | textbox 7016836f | x | column start | 746.7 |
| … | 816 more in the JSON report | | | | |

## Warnings
| Rule | Page | Visual | Property | Expected | Found |
|---|---|---|---|---|---|
| LAYOUT-002 | Intro |   | displayOption | FitToPage | ActualSize |
| LAYOUT-007 | Intro | group 108a61bf | x | integer | 979.89 |
| LAYOUT-007 | Intro | card 412c5c9b | x | integer | 292.24 |
| LAYOUT-007 | Intro | tableEx 465e0c6f | x | integer | 307.27 |
| LAYOUT-007 | Intro | image 7a0165a5 | y | integer | 332.55 |
| LAYOUT-007 | Intro | textbox 93d3b081 | x | integer | 281.48 |
| LAYOUT-007 | Intro | textbox 9b6d8088 | x | integer | 1156.31 |
| LAYOUT-007 | Intro | image a957cdd5 | x | integer | 19.09 |
| LAYOUT-007 | Intro | actionButton b2152ccf | x | integer | 80.67 |
| LAYOUT-007 | Intro | actionButton e248e339 | y | integer | 666.67 |
| LAYOUT-007 | ▶ 📊 Summary | actionButton 0820ed54 | x | integer | 1144.10 |
| LAYOUT-007 | ▶ 📊 Summary | slicer 087c9dd7 | x | integer | 480.71 |
| LAYOUT-007 | ▶ 📊 Summary | shape 16a7682b | y | integer | 278.67 |
| LAYOUT-007 | ▶ 📊 Summary | group 20d4cc11 | width | integer | 1279.29 |
| LAYOUT-007 | ▶ 📊 Summary | group 23bb8698 | height | integer | 197.34 |
| LAYOUT-007 | ▶ 📊 Summary | actionButton 36400340 | x | integer | 1104.92 |
| LAYOUT-007 | ▶ 📊 Summary | group 7890a790 | width | integer | 1249.34 |
| LAYOUT-007 | ▶ 📊 Summary | group 8324e82c | y | integer | 479.12 |
| LAYOUT-007 | ▶ 📊 Summary | clusteredBarChart bd5dad09 | width | integer | 604.73 |
| LAYOUT-007 | ▶ 📊 Summary | actionButton d18cc6f2 | x | integer | 1193.75 |
| LAYOUT-007 | ▶ 📊 Summary | advancedSlicerVisual f5a0441b | x | integer | 660.75 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | group 1f004e77 | y | integer | 0.62 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | advancedSlicerVisual 3b18fde9 | x | integer | 490.11 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | shape 54a01784 | x | integer | 383.35 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | textbox 86093dc6 | x | integer | 746.67 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | pageNavigator 9905f92c | x | integer | 2.86 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | group a2de6f7b | width | integer | 1062.73 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | shape cac22f5b | x | integer | 11.15 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | cardVisual d4e66b79 | x | integer | 360.28 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | lineChart d959adbc | x | integer | 489.83 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | tableEx da229b26 | x | integer | 10.88 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | waterfallChart e1911ad8 | x | integer | 490.12 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | group f0160ba8 | width | integer | 183.85 |
| LAYOUT-007 | ▶ 📄 Profit & Loss | textbox f11353b8 | x | integer | 1148.47 |
| LAYOUT-007 | ▶ 📄 Revenue | advancedSlicerVisual 0b820961 | x | integer | 490.11 |
| LAYOUT-007 | ▶ 📄 Revenue | cardVisual 29f9a75c | x | integer | 360.28 |
| LAYOUT-007 | ▶ 📄 Revenue | textbox 3379122a | x | integer | 731.85 |
| LAYOUT-007 | ▶ 📄 Revenue | tableEx 4269e2de | width | integer | 462.07 |
| LAYOUT-007 | ▶ 📄 Revenue | group 6067c9e0 | width | integer | 195.36 |
| LAYOUT-007 | ▶ 📄 Revenue | textbox 7016836f | x | integer | 746.67 |
| LAYOUT-007 | ▶ 📄 Revenue | lineChart 705b34cc | x | integer | 489.83 |
| LAYOUT-007 | ▶ 📄 Revenue | shape 7fbb8747 | x | integer | 10.53 |
| LAYOUT-007 | ▶ 📄 Revenue | shape 836cd164 | x | integer | 383.35 |
| LAYOUT-007 | ▶ 📄 Revenue | group a1835d8b | width | integer | 1279.29 |
| LAYOUT-007 | ▶ 📄 Revenue | clusteredBarChart c2919a69 | x | integer | 827.38 |
| LAYOUT-007 | ▶ 📄 Revenue | columnChart cd6d2ad0 | x | integer | 490.21 |
| LAYOUT-007 | ▶ 📄 Revenue | actionButton cf4ff4f9 | x | integer | 10.53 |
| LAYOUT-007 | ▶ 📄 Revenue | group e350cbf0 | width | integer | 1061.89 |
| LAYOUT-007 | ▶ 📄 Revenue | clusteredBarChart e7495c5c | y | integer | 395.54 |
| LAYOUT-007 | ▶ 📄 Room Costs | group 146eaa97 | width | integer | 173.75 |
| LAYOUT-007 | ▶ 📄 Room Costs | tableEx 17a38cc9 | x | integer | 10.88 |
| LAYOUT-007 | ▶ 📄 Room Costs | group 27653c46 | width | integer | 1061.89 |
| LAYOUT-007 | ▶ 📄 Room Costs | group 3700d2dc | width | integer | 1279.29 |
| LAYOUT-007 | ▶ 📄 Room Costs | lineChart 69e536de | x | integer | 489.83 |
| LAYOUT-007 | ▶ 📄 Room Costs | advancedSlicerVisual 74646ab3 | x | integer | 489.62 |
| LAYOUT-007 | ▶ 📄 Room Costs | textbox 7a2620d4 | x | integer | 1086.20 |
| LAYOUT-007 | ▶ 📄 Room Costs | shape 7bf4278e | x | integer | 10.38 |
| LAYOUT-007 | ▶ 📄 Room Costs | cardVisual a95efd0d | x | integer | 360.80 |
| LAYOUT-007 | ▶ 📄 Room Costs | shape b213f0da | x | integer | 383.35 |
| LAYOUT-007 | ▶ 📄 Room Costs | waterfallChart b67a8da8 | x | integer | 489.84 |
| … | 499 more in the JSON report | | | | |

## Not evaluated
ACCESS-001, ACCESS-002, ACCESS-003, ASSET-001, CHART-002, CHART-003, CHART-004, CHART-005, CHART-006, CHART-007, COLOR-002, COLOR-003, COLOR-004, COLOR-007, COLOR-008, COLOR-010, COLOR-012, DATA-001, DATA-002, DATA-003, DATA-004, DATA-005, FMT-001, FMT-003, FMT-004, KPI-002, KPI-003, KPI-004, KPI-006, KPI-007, LAYOUT-006, LAYOUT-009, LAYOUT-010, MODE-001, MODE-003, MODE-005, MODE-006, MODE-007, NAV-001, NAV-002, NAV-003, NAV-004, PAGE-003, PAGE-005, PAGE-006, PAGE-007, PANEL-001, PANEL-002, PANEL-003, PANEL-004, PANEL-005, PANEL-006, PANEL-007, SLICER-001, SLICER-002, SLICER-003, SLICER-004, SLICER-005, SLICER-006, SLICER-007, TABLE-001, TABLE-002, TABLE-003, TABLE-004, TABLE-005, TABLE-006, TABLE-007, TABLE-008, TEXT-001, TEXT-002, TEXT-003, TEXT-004, TEXT-005, TEXT-006, TIP-002, TIP-003, TYPO-003, TYPO-004, TYPO-005

**Next step:** remediation plan (`remediation-plan.yaml`)
