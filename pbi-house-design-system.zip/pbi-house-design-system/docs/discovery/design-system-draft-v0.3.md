# Design System: borrador v0.3 (colores Light/Dark exactos)

**Step 3 (casi cerrado)** · Fecha: 2026-10-04

Corpus:
- (1) *Operational Report – Fabric*: Dark, 30 páginas
- (2) *RHG Consolidated Results*: 9 páginas, incluido el **par gemelo** `▶ P&L RHG` (Dark) / `▶ P&L RHG Light` (Light, oculta)

Método: se compararon visual por visual las dos páginas gemelas. Los colores del tema (`ThemeDataColor`) se resolvieron a HEX con el tema `RHG_finance_template`. Correspondencia validada: `ColorId 0` = foreground, `1` = background, `2+n` = `dataColors[n]`; `Percent` < 0 oscurece y > 0 aclara.

Leyenda:
- ✅ decidido por ti
- 🟢 exacto, extraído del PBIR
- 🟡 por confirmar

---

## 1. Decisiones de esta ronda

| ID | Decisión |
|---|---|
| COLOR-R1 | ✅ **Regla del naranja (Dark):** en números, barras o flechas de variación = negativo. En títulos, bordes decorativos y hover = solo acento. Nunca naranja en un número que no sea negativo |
| D16 | ✅ **Light/Dark = páginas gemelas.** Cada página Dark tiene una gemela `"<nombre> Light"` oculta; el botón 🌙/☀ (40×40, banda inferior derecha) **navega** entre ellas |
| P5 | ✅ Rojo negativo Light = **`#C00D0D`** |
| P6 | ✅ **Sombra solo en la cabecera de página** (color `#343B41` = `#687682` −50%) |
| P4 | 🟢 Azul = **`#336293`** (se usa en ambos modos; ver regla en la sección 2.4) |

---

## 2. Tokens semánticos: valores exactos

### 2.1 Superficies

| Token | Dark | Light | Notas |
|---|---|---|---|
| `surface.page` | `#425463` | `#FFFFFF` | Fondo de página |
| `surface.outspace` | `#425463` | `#E6E6E6` | Fuera del canvas |
| `surface.panel` | `#425463` | `#E6E6E6` | Fondo de paneles y gráficos |
| `surface.header` (cabecera de página) | `#425463`, borde `#FFFFFF` | `#E6E6E6`, borde `#425463` | + sombra (P6) |
| `surface.panel-title` (barra de título) | **`#E6E6E6`** | **`#425463`** | ⚠ Invertido entre modos: la barra **contrasta** siempre con el panel |
| `surface.table` | transparente | `#FFFFFF` | Cuerpo de tabla |
| `surface.data-label` | `#425463` | `#B2B2B2` | Fondo de etiqueta (waterfall) |

### 2.2 Texto

| Token | Dark | Light | Notas |
|---|---|---|---|
| `text.primary` | `#FFFFFF` | **`#425463`** | En Light el texto es **pizarra, no negro** |
| `text.on-panel-title` | `#425463` | `#FFFFFF` | |
| `text.panel-subtitle` | `#336293` | `#ADC0D4` | "Mth – Jun 2026", "YTD", subtítulos de gráfico |
| `text.period` (junto al título de página) | `#FFFFFF` | `#336293` | |
| `text.tab-active` (pestañas de texto) | `#336293` | `#FFFFFF` | Sigue al fondo de la barra de título |
| `text.tab-inactive` | `#8E98A1` | `#687682` | Ambos modos también usan `#B2B2B2` → 🟡 unificar |

### 2.3 Bordes, rejillas y elevación

| Token | Dark | Light |
|---|---|---|
| `border.container` | `#FFFFFF` · 1 px · radio 10 | `#425463` · 1 px · radio 10 |
| `gridline` | `#98999C` (`#53565A` +40%), punteada | ídem |
| `shadow.header` | `#343B41` | `#343B41` |

### 2.4 Semántica de negocio

| Token | Dark | Light |
|---|---|---|
| `status.positive` / aumento | `#FFFFFF` | `#425463` (= `text.primary`) |
| `status.negative` / disminución | **`#F3B244`** | **`#C00D0D`** |
| `status.warning` | no existe | no existe |

**Regla derivada para el azul `#336293`:** solo se usa **sobre superficies claras**. Por eso en Dark aparece en la barra de título (`#E6E6E6`) y en Light sobre la página. Así se evita azul sobre pizarra, que tiene poco contraste.

### 2.5 Escenarios y gráficos

| Token | Dark | Light | Estado |
|---|---|---|---|
| `scenario.actual` (línea, marcadores, área) | `#FFFFFF` | `#425463` | 🟢 |
| `scenario.forecast` | igual que actual, **discontinua** | ídem | 🟡 (screenshot) |
| `scenario.reference` (BUD/LY/TGT) | `#ADC0D4` | `#ADC0D4` | ✅ Q2 · 🟡 en el PBIR el punto REF está en `#FFFFFF`; confirmar si la línea es `#ADC0D4` en ambos modos |
| `waterfall.total` | `#ADC0D4` | `#ADC0D4` | 🟢 |

### 2.6 Controles (estados)

| Componente / estado | Dark | Light |
|---|---|---|
| Button slicer, **seleccionado** | relleno `#FFFFFF` · texto `#53565A` | relleno `#425463` · texto `#FFFFFF` |
| Button slicer, **no seleccionado** | relleno `#425463` · borde y texto `#FFFFFF` | relleno `#FFFFFF` · borde y texto `#425463` |
| Botón de acción, seleccionado | `#F3B244` | `#B3BBC1` |
| Botón de acción, hover | `#8E98A1` | `#E6E6E6` |
| List slicer, selección | `#F3B244` | **`#C00D0D`** ⚠ |

Patrón general: **seleccionado = inverso de la superficie.**

> ⚠ **Conflicto en Light:** el list slicer usa el rojo negativo (`#C00D0D`) como color de **selección**. Equivale a la regla del naranja en Dark: el rojo se lee como "malo".
> **Propuesta:** en Light, selección = `#425463` y el rojo queda reservado a negativos (regla espejo de COLOR-R1).

### 2.7 Formato condicional en datos (`DIM_Layout`)

| Tipo de fila | Fondo | Fuente | Notas |
|---|---|---|---|
| Total (Highlight Code de total) | `#8E98A1` (`#425463` +40%) | `#FFFFFF` | Igual en ambos modos |
| Destacada | `#425463` | `#ADC0D4` | Igual en ambos modos |
| Normal | — | — | Hereda `text.primary` |

Los HEX de `DIM_Layout` **deben estar en los tokens**; la regla `DATA-001` validará la tabla contra ellos.

---

## 3. Paleta primitiva (todo lo que existe)

| Primitivo | HEX | Origen |
|---|---|---|
| `slate-700` | `#425463` | Marca: pizarra |
| `slate-500` | `#687682` | Pizarra media |
| `slate-300` | `#8E98A1` | Pizarra +40% |
| `slate-ink` | `#53565A` | Gris oscuro |
| `slate-shadow` | `#343B41` | Sombra |
| `grey-200` | `#E6E6E6` | Gris claro |
| `grey-400` | `#B2B2B2` / `#B1B3B3` | 🟡 dos grises casi iguales → unificar |
| `grey-cool` | `#B3BBC1` | Gris frío |
| `white` | `#FFFFFF` | |
| `orange` | `#F3B244` | Acento / negativo Dark |
| `red` | `#C00D0D` | Negativo Light |
| `blue` | `#336293` | Información sobre fondo claro |
| `blue-light` | `#ADC0D4` | Referencia / total |

**Deriva** (se eliminan): `#0E2841`, `#B3C1B7`, `#86919B`; `good #32CD32` y `bad #FF6347` del tema; la cola de `dataColors` (colores por defecto de Power BI).

---

## 4. Consecuencias de D16 (páginas gemelas)

1. **Power BI solo admite un tema por informe.** Hoy el tema es **Dark** y la página Light se consigue con **overrides por visual** (la Light tiene 921 propiedades frente a 829 de la Dark).
   → La skill generará el **tema Dark** y un **perfil de overrides Light** a partir de los mismos tokens. Light deja de "arreglarse a mano".
2. **Las gemelas tienen que ser iguales salvo en el formato.** Nueva regla **MODE-001 (critical, auto):** las dos páginas tienen los mismos visuales, posiciones, campos, filtros y bookmarks; solo cambian las propiedades de color. El checker compara las gemelas y detecta desincronizaciones (p. ej. una medida añadida solo en Dark).
3. **Doble mantenimiento:** cada cambio de contenido se hace dos veces. Lo hará `report-cli` siguiendo el plan de remediación, que siempre incluirá la gemela.
4. **Convención de nombres:** `<página>` + `<página> Light` (oculta), con navegación por el botón 🌙/☀ → regla NAV-00x.

---

## 5. Tipografía (confirmada en el corpus completo)

- Familia: **Segoe UI** Regular / Semibold / Bold. Calibri y Arial aparecen también en Consolidated → **deriva**.
- Escala por rol, igual en los dos informes:

| Rol | Tamaño |
|---|---|
| Etiquetas, ejes, celdas, items de slicer | 8 pt |
| Cabecera de slicer, subtítulos | 9 pt |
| Títulos de visual o panel, botones | 10 pt |
| Valor de KPI pequeño, título de pivot | 12 pt |
| Valor de KPI mediano, título de card, periodo | 15 pt |
| Valor de KPI grande | 20 pt |
| Valor de KPI hero, título de página | 25 pt |

---

## 6. Últimas preguntas antes de cerrar el Step 3

| # | Pregunta | Propuesta |
|---|---|---|
| R1 | ¿Selección en Light = `#425463`, con el rojo reservado a negativos? | Sí (espejo de COLOR-R1) |
| R2 | ¿Modo por defecto = **Dark**? (las páginas de entrada de ambos informes son Dark) (D15) | Dark |
| R3 | Pestañas inactivas: ¿`#8E98A1` (Dark) y `#687682` (Light), eliminando `#B2B2B2`? | Sí |
| R4 | ¿Unificar `#B1B3B3` y `#B2B2B2` en un solo gris? | Sí, `#B1B3B3` (ya está en el tema) |
| R5 | La línea REF: ¿`#ADC0D4` en ambos modos? | Sí |

Con estas 5 respuestas el Step 3 queda cerrado y paso al **Step 4: estructura de la skill**.
