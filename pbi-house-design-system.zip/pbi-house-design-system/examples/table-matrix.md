<!-- STATUS: v0.1 (Step 9) · LOADED: on demand -->
# Examples: Tables and matrices

## Good: layout-driven P&L (financial matrix)
```yaml
- id: statement
  kind: tableEx
  role: financial_matrix                                   # TABLE-002: type.table_cell (8), row padding 1
  geometry: { col: 1, span: 12, y: 88, h: 568 }            # T-STATEMENT
  title: { text: "P&L RHG (in EUR thousands)", align: left }   # TEXT-001 units, PANEL-007
  header: { fill: color.surface.panel_title, text: color.text.on_panel_title, type: type.table_header }  # TABLE-001
  gridlines: false · banding: false                        # TABLE-003
  blocks: [Mth: ACT | vs TGT | vs BUD, gap, YTD: ACT | vs TGT | vs BUD]   # TABLE-005
  row_style: from DIM_Layouts (Highlight Code → total / highlight band)   # TABLE-004, DATA-001
  formats: from DIM_Layouts ABS/DEV/%DEV Format ("#,##", "#,#0.0%", "#,#0.0 pp")   # FMT-001, F1
```

## Bad
```yaml
- kind: pivotTable
  values: { fontSize: 11, fontFamily: Calibri }  # ✗ TYPO-002 · ✗ TYPO-001
  rows: total row coloured with a static override "#8E98A1"   # ✗ TABLE-004 (must come from the layout table)
  negatives: "(3,842)" in red                    # ✗ FMT-003 minus sign · ✗ COLOR-006 static red
  gridlines: true                                # ✗ TABLE-003
```
