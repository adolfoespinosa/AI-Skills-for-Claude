# Resolved tokens (generated)

> Generated from `tokens/tokens.yaml` v0.1.0. Do not edit; regenerate after changing tokens.

| Token | Dark | Light |
|---|---|---|
| `color.surface.page` | `#425463` | `#FFFFFF` |
| `color.surface.outspace` | `#425463` | `#E6E6E6` |
| `color.surface.panel` | `#425463` | `#E6E6E6` |
| `color.surface.header` | `#425463` | `#E6E6E6` |
| `color.surface.panel_title` | `#E6E6E6` | `#425463` |
| `color.surface.table` | `#425463` | `#FFFFFF` |
| `color.surface.data_label` | `#425463` | `#B1B3B3` |
| `color.surface.total_row` | `#8E98A1` | `#8E98A1` |
| `color.surface.highlight_row` | `#425463` | `#425463` |
| `color.text.primary` | `#FFFFFF` | `#425463` |
| `color.text.on_panel_title` | `#425463` | `#FFFFFF` |
| `color.text.panel_subtitle` | `#336293` | `#ADC0D4` |
| `color.text.period` | `#FFFFFF` | `#336293` |
| `color.text.tab_active` | `#336293` | `#FFFFFF` |
| `color.text.tab_inactive` | `#8E98A1` | `#687682` |
| `color.text.on_total_row` | `#FFFFFF` | `#FFFFFF` |
| `color.text.on_highlight_row` | `#ADC0D4` | `#ADC0D4` |
| `color.border.container` | `#FFFFFF` | `#425463` |
| `color.gridline` | `#98999C` | `#98999C` |
| `color.accent.primary` | `#F3B244` | `#425463` |
| `color.info.on_light` | `#336293` | `#336293` |
| `color.status.positive` | `#FFFFFF` | `#425463` |
| `color.status.negative` | `#F3B244` | `#C00D0D` |
| `color.selection.fill` | `#FFFFFF` | `#425463` |
| `color.selection.text` | `#53565A` | `#FFFFFF` |
| `color.selection.unselected_fill` | `#425463` | `#FFFFFF` |
| `color.selection.unselected_text` | `#FFFFFF` | `#425463` |
| `color.hover.fill` | `#8E98A1` | `#E6E6E6` |
| `color.scenario.actual` | `#FFFFFF` | `#425463` |
| `color.scenario.forecast` | `#FFFFFF` | `#425463` |
| `color.scenario.reference` | `#ADC0D4` | `#ADC0D4` |
| `color.waterfall.increase` | `#FFFFFF` | `#425463` |
| `color.waterfall.decrease` | `#F3B244` | `#C00D0D` |
| `color.waterfall.total` | `#ADC0D4` | `#ADC0D4` |
| `color.shadow.header` | `#343B41` | `#343B41` |
| `color.data.categorical_1` | `#FFFFFF` | `#425463` |
| `color.data.categorical_2` | `#ADC0D4` | `#687682` |
| `color.data.categorical_3` | `#B3BBC1` | `#8E98A1` |
| `color.data.categorical_4` | `#8E98A1` | `#B1B3B3` |

| Type role | Size | Family |
|---|---|---|
| `type.page_title` | 25 | Segoe UI Semibold |
| `type.kpi_hero` | 25 | Segoe UI Semibold |
| `type.kpi_large` | 20 | Segoe UI Semibold |
| `type.kpi_medium` | 15 | Segoe UI Semibold |
| `type.period` | 15 | Segoe UI Semibold |
| `type.kpi_small` | 12 | Segoe UI Semibold |
| `type.panel_title` | 10 | Segoe UI Bold |
| `type.control` | 9 | Segoe UI |
| `type.subtitle` | 9 | Segoe UI |
| `type.table_header` | 8 | Segoe UI Bold |
| `type.table_cell` | 8 | Segoe UI |
| `type.table_cell_list` | 10 | Segoe UI |
| `type.label` | 8 | Segoe UI |
| `type.footnote` | 8 | Segoe UI |
