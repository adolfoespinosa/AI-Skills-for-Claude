#!/usr/bin/env python3
"""
install_header.py: install / refresh the corporate page header on standard pages (HD1, PAGE-001/003/011).

Header (all pages except Intro and tooltip pages), template assets/templates/page-header/header.template.json:
  Header Frame  shape  · surface.header fill · 1 px border.container · radius 10 · shadow.header (bottom right, outer)
  Header Logo   image  · rectangular RHG logo (logo-white.png on Dark, logo-blue.png on Light)
  Header Title  textbox· "Title" by default · Segoe (Bold) · accent.primary (orange Dark / slate Light) · centred
  Header Badge  image  · empty image · padding 0 · caption Segoe UI Semibold 8 text.primary centred ·
                         border.container 1 px · 4 corners 10 px · background surface.header 0 % transparency
Geometry comes from tokens › component.header. Colours are resolved PER MODE (the page name decides:
"<page> Light" = light), so the Light twin is exact and no colour re-mapping is involved.

Deterministic helper executed in the powerbi-report-cli authoring step (decision D1a). make_light_twin.py calls it
on every new Light twin. Re-running replaces the four header visuals (matched by their Selection-pane names) and
keeps the current title and badge caption unless --title / --badge-title are given.

Usage:
  python scripts/install_header.py --report "<path>/<name>.Report" --page "<page>" [--title "P&L RHG"] [--badge-title "EUR"]
  python scripts/install_header.py --report "<path>/<name>.Report" --all        # every standard page (+ twins)
"""
from __future__ import annotations

import argparse
import copy
import json
import re
import secrets
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _tokens as T  # noqa: E402

SKILL = T.SKILL_ROOT
TEMPLATE = SKILL / "assets" / "templates" / "page-header" / "header.template.json"
SCHEMA = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.13.0/schema.json"
NAMES = {"Header Frame", "Header Logo", "Header Title", "Header Badge", "Header Period"}
REQUIRED = ("Header Frame", "Header Logo", "Header Title", "Header Badge")       # Header Period is optional (needs a measure)


def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def dump(p, d): Path(p).write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding="utf-8")


def visual_name(d: dict, tokens: dict | None = None) -> str:
    """Selection-pane name; the badge shows its caption as title, so it is recognised by type + geometry."""
    m = re.search(r"'([^']*)'", json.dumps(d.get("visual", {}).get("visualContainerObjects", {}).get("title", [])))
    name = m.group(1) if m else ""
    if name in NAMES:
        return name
    g = (tokens or T.load())["component"]["header"]["badge"]
    p = d.get("position", {})
    if d.get("visual", {}).get("visualType") == "image" and all(abs(p.get(k, -1) - g[k2]) < 0.5 for k, k2 in
                                                                (("x", "x"), ("y", "y"), ("width", "width"), ("height", "height"))):
        return "Header Badge"
    return name


def resolve(node, tokens, mode, ctx):
    """Replace template placeholders for one mode."""
    if isinstance(node, dict):
        return {k: resolve(v, tokens, mode, ctx) for k, v in node.items()}
    if isinstance(node, list):
        return [resolve(v, tokens, mode, ctx) for v in node]
    if not isinstance(node, str) or "{{" not in node:
        return node
    m = re.fullmatch(r"\{\{c:([a-z_.]+)\}\}", node)
    if m:
        hexv = T.resolve_path(tokens, f"semantic.color.{m[1]}", mode)
        return {"solid": {"color": {"expr": {"Literal": {"Value": f"'{hexv}'"}}}}}
    m = re.fullmatch(r"\{\{n:([a-z_.]+)\|([DL])\}\}", node)
    if m:
        val = T.resolve(tokens, T.get(tokens, m[1]))
        return {"expr": {"Literal": {"Value": f"{val}{m[2]}"}}}
    m = re.fullmatch(r"\{\{f:([a-z_]+)\}\}", node)
    if m:
        return T.pbir_font_literal(tokens, T.resolve(tokens, tokens["semantic"]["type"][m[1]]["family"]))
    for k, v in ctx.items():
        node = node.replace("{{%s}}" % k, str(v))
    return node


def install_on_page(rep: Path, page_id: str, title: str | None = None, badge_title: str | None = None,
                    period: str | None = None) -> str:
    tokens = T.load()
    hdr = tokens["component"]["header"]
    pdir = rep / "definition" / "pages" / page_id
    page = load(pdir / "page.json")
    mode = "light" if page.get("displayName", "").strip().endswith(" Light") else "dark"
    vdir = pdir / "visuals"
    vdir.mkdir(exist_ok=True)

    # keep current texts, remove the old header visuals (house names, or legacy chrome inside band.header)
    old_title, old_badge, old_period = None, None, None
    for vj in list(vdir.glob("*/visual.json")):
        d = load(vj)
        n = visual_name(d, tokens)
        if n in NAMES:
            if n == "Header Title":
                runs = d["visual"]["objects"]["general"][0]["properties"]["paragraphs"][0]["textRuns"]
                old_title = "".join(r.get("value", "") for r in runs)
            if n == "Header Badge":
                old_badge = re.search(r"'([^']*)'", json.dumps(d["visual"]["visualContainerObjects"]["title"][0]["properties"]["text"]))
                old_badge = old_badge.group(1) if old_badge else None
            if n == "Header Period":
                f = d["visual"]["query"]["queryState"]["Data"]["projections"][0]["field"]["Measure"]
                old_period = f"{f['Expression']['SourceRef']['Entity']}[{f['Property']}]"
            shutil.rmtree(vj.parent)
    title = title if title is not None else (old_title or hdr["title"]["text"])
    badge_title = badge_title if badge_title is not None else (old_badge if old_badge is not None else hdr["badge"]["caption"])

    period = period if period is not None else old_period
    for body in header_visuals(tokens, mode, title, badge_title, period):
        (vdir / body["name"]).mkdir()
        dump(vdir / body["name"] / "visual.json", body)
    ensure_logo(rep, hdr["logo"][mode])
    return mode


def header_visuals(tokens: dict, mode: str, title: str, badge_title: str, period: str | None = None) -> list[dict]:
    """The four header visual.json bodies for one mode (importable: used by the testbed builder)."""
    hdr = tokens["component"]["header"]
    ptable, pmeasure = (re.match(r"^\s*'?([^'\[]+)'?\[([^\]]+)\]\s*$", period).groups() if period else (None, None))
    ctx = {"LOGO": hdr["logo"][mode], "TITLE": title, "BADGE_TITLE": badge_title.replace("'", "''"),
           "PERIOD_TABLE": ptable, "PERIOD_MEASURE": pmeasure, "period_align": hdr["period"]["align"],
           "textbox_font": hdr["title"]["textbox_font"], "title_size": hdr["title"]["size"], "badge_fit": hdr["badge"]["fit"],
           "hex:title": T.resolve(tokens, hdr["title"]["color"], mode)}
    out = []
    for spec in load(TEMPLATE)["visuals"]:
        if spec.get("optional") == "PERIOD" and not period:
            continue
        g = hdr[spec["geometry"]]
        out.append({"$schema": SCHEMA, "name": secrets.token_hex(10),
                    "position": {"x": g["x"], "y": g["y"], "z": spec["z"], "height": g["height"], "width": g["width"],
                                 "tabOrder": spec["z"]},
                    "visual": resolve(copy.deepcopy(spec["visual"]), tokens, mode, ctx)})
    return out


def ensure_logo(rep: Path, name: str):
    rr = rep / "StaticResources" / "RegisteredResources"
    rr.mkdir(parents=True, exist_ok=True)
    if not (rr / name).exists():
        shutil.copy(SKILL / "assets" / "logo" / name, rr / name)
    rj = rep / "definition" / "report.json"
    report = load(rj)
    pkg = next((p for p in report.setdefault("resourcePackages", []) if p.get("type") == "RegisteredResources"), None)
    if pkg is None:
        pkg = {"name": "RegisteredResources", "type": "RegisteredResources", "items": []}
        report["resourcePackages"].append(pkg)
    if name not in {i["name"] for i in pkg["items"]}:
        pkg["items"].append({"name": name, "path": name, "type": "Image"})
        dump(rj, report)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--page")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--title")
    ap.add_argument("--badge-title")
    ap.add_argument("--period", help="period measure for the header card, e.g. \"_Measures[Selected Period]\" (kept on re-install)")
    a = ap.parse_args()
    rep = Path(a.report)
    meta = load(rep / "definition" / "pages" / "pages.json")
    pages = {pid: load(rep / "definition" / "pages" / pid / "page.json") for pid in meta["pageOrder"]}
    if a.all:
        targets = [pid for pid, p in pages.items() if p.get("displayName", "").strip() != "Intro" and p.get("type") != "Tooltip"]
    else:
        targets = [pid for pid, p in pages.items() if p.get("displayName", "").strip() == (a.page or "").strip()]
        if not targets:
            print(f"ERROR: page '{a.page}' not found")
            return 2
    for pid in targets:
        mode = install_on_page(rep, pid, a.title, a.badge_title, a.period)
        print(f"HEADER · '{pages[pid]['displayName'].strip()}' ({mode})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
