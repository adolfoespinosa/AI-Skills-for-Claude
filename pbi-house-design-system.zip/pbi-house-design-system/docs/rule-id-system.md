# Sistema de identificación de reglas (Deliverable 6)

Estado: **v1.0, aprobado en el Step 4** · Aplica a todos los bloques de regla de `references/**`

## 1. Formato del ID

```text
<DOMINIO>-<NNN>      p. ej. COLOR-004, KPI-001, MODE-001
```

- `NNN` es secuencial dentro del dominio y empieza en 001.
- **Inmutable:** un ID no se renumera ni se reutiliza jamás, aunque la regla se elimine.
- Una regla deprecada conserva su ID con `status: deprecated` y `replaced_by`.

## 2. Dominios

El modo (Light/Dark) es un **atributo** de la regla, no un dominio.

| Dominio | Ámbito | Fichero |
|---|---|---|
| `COLOR` | Semántica de color, estados, escenarios | `foundations/color.md` |
| `TYPO` | Familias, escala y roles tipográficos | `foundations/typography.md` |
| `LAYOUT` | Canvas, grid C, bandas, alineación, separaciones | `foundations/layout-grid.md` |
| `MODE` | Páginas gemelas, paridad, overrides Light | `foundations/modes.md` |
| `PAGE` | Cabecera y banda inferior (chrome de página) | `components/page-chrome.md` |
| `PANEL` | Panel con barra de título | `components/panel.md` |
| `KPI` | KPI cards | `components/kpi-card.md` |
| `CHART` | Gráficos | `components/charts.md` |
| `TABLE` | `tableEx` y `pivotTable` | `components/table-matrix.md` |
| `SLICER` | Dropdown, button slicer, pestañas de texto, list rail | `components/slicers-filters.md` |
| `NAV` | Botones, navegadores, toggle de modo, nombres de página | `components/navigation.md` |
| `TIP` | Tooltips | `components/tooltips.md` |
| `TEXT` | Títulos, subtítulos, notas | `components/text-titles.md` |
| `FMT` | Formatos numéricos y de fecha (lado modelo) | `formatting-standards.md` |
| `DATA` | Formato guiado por datos (`DIM_Layout`) | `data-driven-formatting.md` |
| `ACCESS` | Accesibilidad. **No admite excepciones** (D9) | `foundations/color.md` + `typography.md` (sección ACCESS) |
| `ASSET` | Logos, iconos, imágenes | `components/page-chrome.md` |

Para añadir un dominio nuevo hace falta una versión MINOR y una entrada en esta tabla.

## 3. Esquema del bloque de regla

Cada regla vive en un bloque ```yaml dentro de su `.md` (D3). `check_compliance.py` los parsea; Claude los lee en contexto.

```yaml
- id: KPI-001
  title: KPI cards use the new card visual
  status: active               # active | deprecated
  since: 1.0.0
  severity: critical           # critical | warning | info
  priority: P4                 # P0 platform · P1 access · P2 brand · P3 semantic · P4 component · P5 template
  modes: [dark, light]
  applies_to: [cardVisual, card]       # PBIR visualType
  statement: "KPI cards MUST use visualType cardVisual. Legacy 'card' is forbidden."
  expect:                      # machine-checkable expectations (token refs only, no literals)
    - visualType: cardVisual
  check: auto                  # auto | assisted | manual
  exceptions: allowed          # allowed | forbidden
  allowed_variations: []
  rationale: "Q4 decision; legacy card lacks reference labels and states."
  replaced_by: null
```

### Reglas de redacción
1. `statement` usa **MUST / MUST NOT / SHOULD** (RFC 2119). Prohibido "debería verse profesional".
2. `expect` solo contiene **referencias a tokens** (`{semantic.color.status.negative}`), nunca HEX.
3. Cada regla verifica **una sola cosa**. Si tiene un "y", se divide en dos.
4. `check: manual` solo cuando sea imposible automatizarla. El informe la lista como **Not evaluated**, nunca como Passed.

## 4. Severidad y efecto

| Severidad | Efecto en el compliance | ¿Bloquea la publicación? |
|---|---|---|
| `critical` | FAILED | Sí, salvo excepción aprobada (WAIVED) |
| `warning` | PASSED WITH WARNINGS | No |
| `info` | Informativo | No |

Las reglas nuevas entran como `warning` y se promueven a `critical` en la siguiente versión MAJOR (D11).

## 5. Estados en el informe de compliance

`PASSED` · `FAILED` · `WAIVED` (excepción activa) · `BASELINE` (deuda conocida) · `NOT EVALUATED` (manual)
