#!/usr/bin/env python3
"""
check_contrast.py: WCAG contrast for the token pairs declared in tokens.yaml › checks.contrast_pairs,
in both modes (ACCESS-001 / ACCESS-002).

Thresholds: text 4.5 · large 3.0 · graphic 3.0
Pairs matching an accepted deviation (foundations/color.md › accepted_deviations) are reported as
ACCEPTED-DEVIATION instead of FAILED.

Exit code 0 = no unaccepted failures, 1 = failures.
Usage: python scripts/check_contrast.py [--json]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _tokens as T  # noqa: E402

THRESHOLD = {"text": 4.5, "large": 3.0, "graphic": 3.0}


def deviation_for(fg: str, bg: str, mode: str, deviations: list[dict]):
    for ad in deviations:
        for p in ad.get("pairs", []):
            modes = p["mode"] if isinstance(p["mode"], list) else [p["mode"]]
            if T.expand_alias(p["fg"]) == fg and T.expand_alias(p["bg"]) == bg and mode in modes:
                return ad["id"]
    return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    tokens = T.load()
    deviations = T.accepted_deviations()
    rows = []
    for pair in tokens["checks"]["contrast_pairs"]:
        fg, bg, kind = T.expand_alias(pair["fg"]), T.expand_alias(pair["bg"]), pair["kind"]
        for mode in T.MODES:
            cf, cb = T.resolve_path(tokens, fg, mode), T.resolve_path(tokens, bg, mode)
            ratio = round(T.contrast(cf, cb), 2)
            ok = ratio >= THRESHOLD[kind]
            ad = None if ok else deviation_for(fg, bg, mode, deviations)
            status = "PASSED" if ok else ("ACCEPTED-DEVIATION" if ad else "FAILED")
            rows.append({"mode": mode, "fg": fg.replace("semantic.color.", ""), "bg": bg.replace("semantic.color.", ""),
                         "fg_hex": cf, "bg_hex": cb, "kind": kind, "ratio": ratio,
                         "min": THRESHOLD[kind], "status": status, "deviation": ad})

    failed = [r for r in rows if r["status"] == "FAILED"]
    if a.json:
        print(json.dumps({"status": "FAILED" if failed else "PASSED", "pairs": rows}, indent=2))
    else:
        print(f"CONTRAST CHECK · {len(rows)} pair-modes · {'FAILED' if failed else 'PASSED'}")
        print(f"  {'mode':5} {'ratio':>6} {'min':>4}  {'status':18} {'fg':26} on {'bg':22} {'':8}")
        for r in rows:
            tag = r["deviation"] or ""
            print(f"  {r['mode']:5} {r['ratio']:6.2f} {r['min']:4.1f}  {r['status']:18} {r['fg']:26} on {r['bg']:22} {tag}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
