<!-- STATUS: v0.1 (Step 9) · LOADED: on demand -->
# Examples: Slicers and filters

## Good: bottom band (left cluster)
```text
x 12   Year ▾ (dropdown, span 2, h 56, y 660)          SLICER-001
x 118  Period ▾ (dropdown, span 3)                      gap 16
x 277  [vs LY|vs TGT] 100 × 50   y 663                  SLICER-002 · PAGE-007
x 393  [ABS|DEV|DEV%] 150 × 50
x 559  [K|M] 100 × 50
x 675  [EUR|FXN|LC] 150 × 50
```
Selected button = `selection.fill` + `selection.text` in Bold; unselected = `selection.unselected_*`;
hover = `hover.control` (SLICER-003). Dropdowns are filled with `control.dropdown_*` in both modes.

## Bad
- Year slicer placed top-right in the header → ✗ PAGE-004 / SLICER-001
- Button slicer with "Select all" and multi-select for K/M → ✗ SLICER-002
- Light page list slicer selection in red → ✗ COLOR-006 (red is only for negatives, R1)
