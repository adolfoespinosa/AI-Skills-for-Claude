#!/usr/bin/env python3
"""
extract_pbir.py — Design reverse-engineering extractor for PBIR reports (prototype v0.1)

Reads ONLY the report definition (<name>.Report/definition + StaticResources).
Never reads the semantic model or data: no business data, no personal data.

Outputs (in --out):
  pages.csv        one row per page (size, type, visibility, display option)
  visuals.csv      one row per visual/group, with ABSOLUTE positions (groups resolved)
  properties.csv   one row per literal formatting property (object, property, selector, value)
  theme_flat.csv   custom theme flattened (path, value)
  resources.csv    registered images/themes

Usage:
  python extract_pbir.py --report "<path>/<name>.Report" --out <outdir> [--tag reference|legacy]
"""
import argparse, csv, json, os, re
from pathlib import Path

HEX = re.compile(r"#[0-9A-Fa-f]{6}(?:[0-9A-Fa-f]{2})?\b")


def load(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def literal(v):
    """Return a python value for a PBIR expression literal, or None."""
    if isinstance(v, dict):
        if "expr" in v:
            return literal(v["expr"])
        if "Literal" in v:
            raw = v["Literal"].get("Value")
            if isinstance(raw, str):
                if raw.startswith("'") and raw.endswith("'"):
                    return raw[1:-1]
                if raw.endswith("D") or raw.endswith("L"):
                    try:
                        return float(raw[:-1])
                    except ValueError:
                        return raw
                if raw in ("true", "false"):
                    return raw == "true"
            return raw
        if "solid" in v and "color" in v["solid"]:
            return literal(v["solid"]["color"])
        if "ThemeDataColor" in v:
            t = v["ThemeDataColor"]
            return f"theme:{t.get('ColorId')}:{t.get('Percent')}"
    return None


def walk_objects(objs, group, sink):
    """objs = {objectName: [ {properties:{...}, selector:{...}} ]}"""
    for oname, entries in (objs or {}).items():
        for e in entries or []:
            sel = e.get("selector", {})
            sel_s = sel.get("id") or sel.get("metadata") or ("data" if "data" in sel else "")
            for pname, pval in (e.get("properties") or {}).items():
                val = literal(pval)
                if val is None:
                    # conditional / measure-driven
                    s = json.dumps(pval)
                    kind = "measure" if "Measure" in s else ("rule" if "Conditional" in s or "FillRule" in s else "expr")
                    val = f"<{kind}>"
                sink.append((group, oname, pname, sel_s, val))


def flatten(d, prefix=""):
    if isinstance(d, dict):
        for k, v in d.items():
            yield from flatten(v, f"{prefix}.{k}" if prefix else k)
    elif isinstance(d, list):
        for i, v in enumerate(d):
            yield from flatten(v, f"{prefix}[{i}]")
    else:
        yield prefix, d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--tag", default="reference")
    a = ap.parse_args()

    rep = Path(a.report)
    defn = rep / "definition"
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    rname = rep.name.replace(".Report", "")

    report = load(defn / "report.json")
    order = load(defn / "pages" / "pages.json").get("pageOrder", [])

    # ---- theme
    ct = report.get("themeCollection", {}).get("customTheme", {})
    theme_rows = []
    if ct:
        tp = rep / "StaticResources" / "RegisteredResources" / ct["name"]
        if tp.exists():
            for path, val in flatten(load(tp)):
                if path.startswith("icons."):
                    continue  # embedded SVG data, not useful here
                theme_rows.append((rname, ct["name"], path, val))

    # ---- resources
    res_rows = []
    rr = rep / "StaticResources" / "RegisteredResources"
    if rr.exists():
        for f in sorted(rr.iterdir()):
            res_rows.append((rname, f.name, f.suffix.lower(), f.stat().st_size))

    page_rows, vis_rows, prop_rows = [], [], []
    for idx, pid in enumerate(order):
        pdir = defn / "pages" / pid
        pg = load(pdir / "page.json")
        pname = (pg.get("displayName") or pid).strip()
        page_rows.append((rname, a.tag, idx, pid, pname, pg.get("width"), pg.get("height"),
                          pg.get("displayOption"), pg.get("type", "Standard"),
                          pg.get("visibility", "AlwaysVisible")))
        psink = []
        walk_objects(pg.get("objects"), "page", psink)
        for g, o, p, s, v in psink:
            prop_rows.append((rname, pname, "__page__", "page", g, o, p, s, v))

        vdir = pdir / "visuals"
        if not vdir.exists():
            continue
        raw = {}
        for vd in vdir.iterdir():
            f = vd / "visual.json"
            if f.exists():
                raw[vd.name] = load(f)

        def absolute(vid, seen=()):
            d = raw[vid]
            p = d.get("position", {})
            x, y = p.get("x", 0), p.get("y", 0)
            parent = d.get("parentGroupName")
            if parent and parent in raw and parent not in seen:
                px, py = absolute(parent, seen + (vid,))
                return x + px, y + py
            return x, y

        for vid, d in raw.items():
            v = d.get("visual", {})
            vtype = v.get("visualType") or ("group" if "visualGroup" in d else "unknown")
            p = d.get("position", {})
            ax, ay = absolute(vid)
            sink = []
            walk_objects(v.get("objects"), "objects", sink)
            walk_objects(v.get("visualContainerObjects"), "container", sink)
            for g, o, pr, s, val in sink:
                prop_rows.append((rname, pname, vid, vtype, g, o, pr, s, val))

            def get(group, obj, prop):
                for g, o, pr, s, val in sink:
                    if g == group and o == obj and pr == prop and s in ("", None):
                        return val
                return ""

            vis_rows.append((
                rname, a.tag, pname, pid, vid, vtype, d.get("parentGroupName", ""),
                round(ax, 1), round(ay, 1), round(p.get("width", 0), 1), round(p.get("height", 0), 1),
                p.get("z", ""), p.get("tabOrder", ""),
                get("container", "title", "show"), get("container", "title", "text"),
                get("container", "title", "fontSize"), get("container", "title", "fontFamily"),
                get("container", "background", "show"), get("container", "background", "color"),
                get("container", "border", "show"), get("container", "border", "radius"),
                get("container", "dropShadow", "show"),
                d.get("isHidden", False),
            ))

    def w(name, header, rows):
        with open(out / name, "w", newline="", encoding="utf-8") as f:
            cw = csv.writer(f)
            cw.writerow(header)
            cw.writerows(rows)

    w("pages.csv", ["report", "tag", "order", "page_id", "page", "width", "height", "display", "type", "visibility"], page_rows)
    w("visuals.csv", ["report", "tag", "page", "page_id", "visual_id", "visual_type", "parent_group",
                      "x_abs", "y_abs", "width", "height", "z", "tab_order",
                      "title_show", "title_text", "title_font_size", "title_font",
                      "bg_show", "bg_color", "border_show", "border_radius", "shadow_show", "hidden"], vis_rows)
    w("properties.csv", ["report", "page", "visual_id", "visual_type", "group", "object", "property", "selector", "value"], prop_rows)
    w("theme_flat.csv", ["report", "theme", "path", "value"], theme_rows)
    w("resources.csv", ["report", "file", "ext", "bytes"], res_rows)
    print(f"{rname}: {len(page_rows)} pages, {len(vis_rows)} visuals, {len(prop_rows)} properties -> {out}")


if __name__ == "__main__":
    main()
