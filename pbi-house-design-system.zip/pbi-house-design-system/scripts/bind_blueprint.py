#!/usr/bin/env python3
"""
bind_blueprint.py: instantiate an approved blueprint (assets/blueprints/<family>/<variant>) on a report page (D19, D1a).

  - fields      --bind FIELD_1="Date[Period]"   (every required FIELD_n must be bound)
  - parameters  --param HEADER="Month"          (defaults from the manifest)
  - position    grid slot from the manifest (band y/height, span, col) · override with --col / --span
  - colours     "{{token:<semantic path>}}" → ThemeDataColor when the token is mode-invariant and maps to a locked
                theme slot (theme_compat), else the Dark literal (make_light_twin re-colours it on the Light twin)
  - IDs         new visual ID, tabOrder = number of visuals on the page

Run on the Dark page only, then rebuild the Light twin (make_light_twin.py --replace).

Usage: python scripts/bind_blueprint.py --report "<path>/<name>.Report" --page "<page>" --blueprint slicer/period-dropdown
                                        --bind FIELD_1="Date[Period]" [--param KEY=VALUE ...] [--col 3] [--span 3]
"""
from __future__ import annotations

import argparse
import json
import re
import secrets
import sys
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _tokens as T  # noqa: E402

SKILL = T.SKILL_ROOT
FIELD = re.compile(r"^\s*'?(?P<t>[^'\[]+)'?\[(?P<c>[^\]]+)\]\s*$")


def grid_x(col: int, layout: dict) -> float:
    return layout["margin"] + (col - 1) * (layout["column"] + layout["gutter"])


def grid_w(span: int, layout: dict) -> float:
    return span * layout["column"] + (span - 1) * layout["gutter"]


def token_color(tokens: dict, path: str):
    full = f"semantic.color.{path}"
    dark, light = (T.resolve_path(tokens, full, m).upper() for m in ("dark", "light"))
    if dark == light:
        tc = tokens["component"]["theme_compat"]
        slots = [T.resolve(tokens, tc["foreground"]), T.resolve(tokens, tc["background"])] + \
                [T.resolve(tokens, s) for s in tc["data_slots"]]
        for cid, hexv in enumerate(slots):
            if hexv.upper() == dark:
                return {"expr": {"ThemeDataColor": {"ColorId": cid, "Percent": 0}}}
    return {"expr": {"Literal": {"Value": f"'{dark}'"}}}


def fix_fonts(node, tokens):
    """FS1: every fontFamily literal written as the Power BI font stack (bare names render with a wrong weight)."""
    if isinstance(node, dict):
        for k, v in node.items():
            if k in ("fontFamily", "fontFace") and isinstance(v, dict) and "Literal" in v.get("expr", {}):
                val = v["expr"]["Literal"]["Value"].strip("'")
                if T.is_bare_font(val) and val in tokens["primitive"].get("font_stack", {}):
                    node[k] = T.pbir_font_literal(tokens, val)
            else:
                fix_fonts(v, tokens)
    elif isinstance(node, list):
        for v in node:
            fix_fonts(v, tokens)


class BindError(Exception):
    pass


def render(blueprint: str, bind: dict[str, str], params: dict[str, str] | None = None,
           col: int | None = None, span: int | None = None, tab: int = 0, vid: str | None = None,
           preset: str | None = None, x: float | None = None) -> dict:
    """Return a bound visual.json dict (importable: used by the testbed builder)."""
    family, variant = blueprint.split("/", 1)
    bdir = SKILL / "assets" / "blueprints" / family
    man = yaml.safe_load((bdir / f"{variant}.manifest.yaml").read_text(encoding="utf-8"))
    text = (bdir / f"{variant}.visual.json").read_text(encoding="utf-8")
    tokens = T.load()
    layout = tokens["layout"]["grid"]

    values = {k: str(v.get("default")) for k, v in man["parameters"].items() if "default" in v}
    if preset:
        if preset not in man.get("presets", {}):
            raise BindError(f"unknown preset '{preset}' (available: {list(man.get('presets', {}))})")
        values.update({k: str(v) for k, v in man["presets"][preset].items() if k.isupper()})
    values.update(params or {})
    need = [k for k, v in man["parameters"].items() if v.get("required_value") and k not in values]
    if need:
        raise BindError(f"parameters without value: {need}")
    for k, v in bind.items():
        m = FIELD.match(v)
        if not m:
            raise BindError(f"{k} expects Table[Column], got {v}")
        values[f"{k}.table"], values[f"{k}.column"] = m["t"].strip(), m["c"].strip()
    missing = [k for k, v in man["parameters"].items() if v.get("required") and f"{k}.table" not in values]
    if missing:
        raise BindError(f"required bindings missing: {missing}")

    slot = man["slot"]
    col, span = col or slot.get("col"), span or slot.get("span")
    width = int(values["COLUMNS"]) * slot["width_per_column"] if "width_per_column" in slot else grid_w(span or 1, layout)
    pos = {"X": round(x if x is not None else grid_x(col or 1, layout), 2), "Y": slot["y"], "Z": slot["z"],
           "W": round(width, 2), "H": slot["height"], "TAB": tab}
    for k, v in pos.items():                                    # numeric placeholders: drop the quotes
        text = text.replace(f'"{{{{{k}}}}}"', json.dumps(v))
    text = text.replace("{{VISUAL_ID}}", vid or secrets.token_hex(10))
    for k, v in values.items():
        v = json.dumps(v, ensure_ascii=False)[1:-1]
        text = text.replace("{{%s}}" % k, v if k.startswith("FIELD_") else v.replace("'", "''"))   # '' inside DAX literals
    text = re.sub(r'"\{\{num:([A-Za-z0-9_.]+)\}\}"',
                  lambda m: json.dumps({"expr": {"Literal": {"Value": f"{T.resolve_path(tokens, 'semantic.' + m[1])}L"}}}), text)
    text = re.sub(r'"\{\{token:([A-Za-z0-9_.]+)\}\}"', lambda m: json.dumps(token_color(tokens, m[1])), text)
    left = sorted(set(re.findall(r"\{\{[^}]+\}\}", text)))
    if left:
        raise BindError(f"unresolved placeholders {left}")
    body = json.loads(text)
    fix_fonts(body, tokens)                                     # FS1 · bare font names → Power BI stacks
    T.apply_visual_level(body, tokens)                          # SLICER-008/009 · styles themes ignore
    if body.get("visual", {}).get("syncGroup", {}).get("groupName") == "":
        body["visual"].pop("syncGroup")                         # SYNC_GROUP "" = not synced
    return body


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--page", required=True)
    ap.add_argument("--blueprint", required=True)
    ap.add_argument("--bind", action="append", default=[])
    ap.add_argument("--param", action="append", default=[])
    ap.add_argument("--col", type=int)
    ap.add_argument("--span", type=int)
    ap.add_argument("--preset")
    ap.add_argument("--x", type=float, help="absolute x (button groups placed after the previous group)")
    a = ap.parse_args()

    rep = Path(a.report)
    defn = rep / "definition"
    meta = json.loads((defn / "pages" / "pages.json").read_text(encoding="utf-8"))
    pid = next((p for p in meta["pageOrder"]
                if json.loads((defn / "pages" / p / "page.json").read_text(encoding="utf-8")).get("displayName", "").strip() == a.page.strip()), None)
    if not pid:
        print(f"ERROR: page '{a.page}' not found")
        return 2
    vis_dir = defn / "pages" / pid / "visuals"
    try:
        body = render(a.blueprint, dict(kv.split("=", 1) for kv in a.bind), dict(kv.split("=", 1) for kv in a.param),
                      a.col, a.span, preset=a.preset, x=a.x, tab=len(list(vis_dir.glob("*/visual.json"))) if vis_dir.exists() else 0)
    except BindError as e:
        print(f"ERROR: {e}")
        return 2
    vid, pos = body["name"], body["position"]
    (vis_dir / vid).mkdir(parents=True)
    (vis_dir / vid / "visual.json").write_text(json.dumps(body, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"BOUND {a.blueprint} → page '{a.page}' · visual {vid} · x {pos['x']} y {pos['y']} {pos['width']}×{pos['height']}")
    print("  next: make_light_twin.py --replace for this page")
    return 0


if __name__ == "__main__":
    sys.exit(main())
