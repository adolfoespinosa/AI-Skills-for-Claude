<!--
STATUS: v0.1 (Step 6, batch 1). Numbers resolve from tokens/tokens.yaml › layout (Step 7).
PURPOSE: Canvas, grid C, vertical bands, spacing and alignment rules (LAYOUT-*).
LOADED: any task that places, resizes or aligns visuals, or creates a page.
-->
# Layout and Grid

## 1. Canvas

| Token | Value |
|---|---|
| `layout.canvas` | 1280 × 720 · display option `FitToPage` |
| `layout.tooltip.small` | 176 × 48 (TP1) |
| `layout.tooltip.medium` | 320 × 320 (TP1) |

## 2. Horizontal grid (grid C)

```text
margin = 12   gutter = 16   columns = 24   column = 37   usable width = 1256

x(column n)   = 12 + (n − 1) × 53            n = 1..24
width(span s) = 37 × s + 16 × (s − 1)        s = 1..24
right edge    = x + width   (last column ends at 1268)
```

| Span | Width | Typical use |
|---|---|---|
| 3 | 143 | 1 of 8 |
| 4 | 196 | 1 of 6 (KPI row) |
| 6 | 302 | 1 of 4 |
| 8 | 408 | 1 of 3 |
| 12 | 620 | Half page |
| 16 / 8 | 832 / 408 | Two-thirds + one-third |
| 24 | 1256 | Full width |

**Row of N equal items when N does not divide 24** (e.g. 5): width = (1256 − 16·(N−1)) / N, rounded down to an
integer. The leftover pixels go to the last item. This is the only allowed off-grid width (LAYOUT-004).

## 3. Vertical bands

| Band | y from → to | Height | Contents |
|---|---|---|---|
| Top margin | 0 → 8 | 8 | Empty |
| `band.header` | 8 → 72 | 64 | Page header (see `components/page-chrome.md`) |
| Gap | 72 → 88 | 16 | Empty |
| `band.content` | 88 → 656 | 568 | Panels and visuals |
| `band.bottom` | 656 → 720 | 64 | Filters, button-slicer groups, navigation, mode toggle |

Inside `band.content`, vertical gaps between stacked panels are **16** (the gutter). Heights are multiples of 8,
except the last panel in a column, which ends exactly at y = 656.

## 4. Rules

```yaml
- id: LAYOUT-001
  title: Canvas size
  status: active
  since: 0.1.0
  severity: critical
  priority: P5
  modes: [dark, light]
  applies_to: [page]
  statement: "Standard, drillthrough and twin pages MUST be 1280 × 720. Tooltip pages MUST use an approved tooltip size."
  expect:
    - page.size: "{layout.canvas}"
  check: auto
  exceptions: allowed

- id: LAYOUT-002
  title: Display option
  status: active
  since: 0.1.0
  severity: warning
  priority: P5
  modes: [dark, light]
  applies_to: [page]
  statement: "Standard pages MUST use displayOption FitToPage. Tooltip pages use ActualSize."
  check: auto
  exceptions: allowed

- id: LAYOUT-003
  title: Visuals start on a column
  status: active
  since: 0.1.0
  severity: critical
  priority: P4
  modes: [dark, light]
  applies_to: ["top-level visuals and groups (excluding full-page background shapes)"]
  statement: "The absolute x of every top-level visual or group MUST equal a column start x(n) (tolerance 0.5 px)."
  expect:
    - x_abs_in: "x(1..24)"
  check: auto
  exceptions: allowed

- id: LAYOUT-004
  title: Widths are spans
  status: active
  since: 0.1.0
  severity: critical
  priority: P4
  modes: [dark, light]
  applies_to: ["top-level visuals and groups"]
  statement: "Width MUST equal width(s) for an integer span s, or the equal-split width of an N-item row (section 2) (tolerance 0.5 px)."
  check: auto
  exceptions: allowed

- id: LAYOUT-005
  title: Elements stay inside their band
  status: active
  since: 0.1.0
  severity: critical
  priority: P5
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Every visual MUST lie entirely inside one band: header, content or bottom."
  check: auto
  exceptions: allowed

- id: LAYOUT-006
  title: Consistent gaps
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: ["adjacent top-level visuals in band.content"]
  statement: "Horizontal and vertical gaps between adjacent panels MUST equal the gutter (16)."
  check: auto
  exceptions: allowed

- id: LAYOUT-007
  title: Integer positions
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: ["*"]
  statement: "x, y, width and height MUST be integers (no drag decimals)."
  check: auto
  exceptions: allowed

- id: LAYOUT-008
  title: No overlap
  status: active
  since: 0.1.0
  severity: critical
  priority: P4
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Visual bounding boxes MUST NOT overlap, except a container shape placed behind its own content (lower z) or elements inside the same group."
  check: auto
  exceptions: allowed

- id: LAYOUT-009
  title: Content fills the content band
  status: active
  since: 0.1.0
  severity: warning
  priority: P5
  modes: [dark, light]
  applies_to: [page]
  statement: "The lowest panel of each column MUST end at y = 656 (no dead band above the bottom band)."
  check: auto
  exceptions: allowed

- id: LAYOUT-010
  title: Heights on the 8 px rhythm
  status: active
  since: 0.1.0
  severity: info
  priority: P4
  modes: [dark, light]
  applies_to: ["top-level visuals in band.content"]
  statement: "Heights SHOULD be multiples of 8, except where LAYOUT-009 requires a panel to end at 656."
  check: auto
  exceptions: allowed
```

## 4b. Exemption: bottom band
Elements in `band.bottom` follow `components/page-chrome.md` (PAGE-007): 50 × 50 buttons, 16 px gaps, right
cluster aligned to x 1268. LAYOUT-003 and LAYOUT-004 apply there **only to the first element** of the left
cluster.

## 5. Notes for implementation
- Positions inside a visual group are **relative to the group** in PBIR. The checker resolves absolute
  positions; plans must state which one they use.
- Container shapes sit behind their content: same x/y/width/height as the panel, lower z.
- Migrating a legacy page to grid C is a remediation plan (brownfield workflow), always applied to both twins.
