<!--
STATUS: v0.1 (Step 6, batch 2)
PURPOSE: tableEx / pivotTable standard, financial statement conventions (TABLE-*).
LOADED: designing or modifying tables and matrices.
-->
# Tables and Matrices

## 1. Two table roles (T1)

| Role | Visual | Cell size | Row padding | Use |
|---|---|---|---|---|
| **Financial matrix** | `tableEx` (layout-driven) or `pivotTable` | `type.table_cell` (8) | 1 | P&L, statements, dense KPI tables |
| **List** | `tableEx` | `type.table_cell_list` (10) | 6 | Hotel lists, rankings, ≤ 8 columns |

Row padding values are the two clusters found in the corpus (1 and 6).

## 2. Anatomy (financial matrix)

```text
┌ panel title bar ────────────────────────────────────────────────┐
│ subtitle:            Mth - Jun 2026          YTD                 │
│ ▓ header ▓ ACT ▓ vs TGT ▓ vs BUD ▓   ▓ ACT ▓ vs TGT ▓ vs BUD ▓    │ header = surface.panel_title / text.on_panel_title
│ ███ Revenue ███████████████████████   ████████████████████████   │ total row (DIM_Layout)
│   Payroll            35,751 …           204,442 …                 │ normal row, indented by layout
│     %Rev Payroll      25.1% …              29.5% …                │ ratio row
└──────────────────────────────────────────────────────────────────┘
       time blocks separated by a gap, not by a border
```

## 3. Rules

```yaml
- id: TABLE-001
  title: Header style
  status: active
  since: 0.1.0
  severity: critical
  priority: P2
  modes: [dark, light]
  applies_to: [tableEx, pivotTable]
  statement: "Column headers MUST use background surface.panel_title, font text.on_panel_title, type.table_header."
  check: auto
  exceptions: allowed

- id: TABLE-002
  title: Cell size by role
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [tableEx, pivotTable]
  statement: "Financial matrices MUST use type.table_cell with row padding 1; lists MUST use type.table_cell_list with row padding 6."
  check: auto
  exceptions: allowed

- id: TABLE-003
  title: No gridlines, no banding
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [tableEx, pivotTable]
  statement: "Horizontal and vertical gridlines and row banding MUST be off. Structure comes from total and highlight rows and from time-block gaps."
  check: auto
  exceptions: allowed

- id: TABLE-004
  title: Row styling from the layout table
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [tableEx, pivotTable]
  statement: "In layout-driven matrices, total and highlight row colours and indentation MUST come from the layout table (DATA-*), never from static per-visual overrides."
  check: assisted
  exceptions: allowed

- id: TABLE-005
  title: Time blocks separated by a gap
  status: active
  since: 0.1.0
  severity: info
  priority: P4
  modes: [dark, light]
  applies_to: [tableEx, pivotTable]
  statement: "Period blocks (Mth / YTD / LTM) SHOULD be separated by a gap column painted in the panel surface (or by separate visuals), not by borders."
  check: assisted
  exceptions: allowed

- id: TABLE-006
  title: Alignment
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [tableEx, pivotTable]
  statement: "Numeric columns MUST be right-aligned; text columns left-aligned; column headers aligned like their values."
  check: auto
  exceptions: allowed

- id: TABLE-007
  title: Negatives and ratios
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [tableEx, pivotTable]
  statement: "Negatives MUST show a minus sign (FMT-*); status colour on variance columns MUST be conditional (COLOR-003/006)."
  check: assisted
  exceptions: allowed

- id: TABLE-008
  title: Table surface
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [tableEx, pivotTable]
  statement: "Table body background MUST be surface.table and values MUST use text.primary unless conditionally formatted."
  check: auto
  exceptions: allowed
```

## Financial-matrix role (decision TB2, 2026-10-07)

Source: *RHG Consolidated Results › ▶ P&L RHG*. Applied with `scripts/apply_table_role.py` (template
`assets/templates/table-roles/financial-matrix.json`); recorded on the visual as annotations so
`make_light_twin.py` re-applies it with Light colours. Everything not listed keeps the theme / current values.

| Part | Standard | Dark | Light |
|---|---|---|---|
| Title | Segoe UI Semibold **9**, left, band `surface.panel_title` | text `#425463` on `#E6E6E6` | text `#FFFFFF` on `#425463` |
| Subtitle | Segoe UI Semibold **8**, left; blank `" "` until a subtitle measure exists | `#336293` | `#ADC0D4` |
| Divider | solid, **5 px** | `#425463` | `#FFFFFF` |
| Spacing | above subtitle 5 · above divider 5 · above plot area 5 | | |
| Column headers | right-aligned, Segoe UI Semibold **8**, widths **custom** (`fixedWidth`) | | |
| Widths | first column **150** · dummy **10** · others **55** (default) | | |
| Dummy column | measure `Dummy Column = ""`, header **"."**, right after the first column; header and values painted `surface.table` (invisible separator) | `#425463` | `#FFFFFF` |
| Grid | row padding **2** | | |

```bash
python ${CLAUDE_SKILL_DIR}/scripts/apply_table_role.py --report "<.Report>" --page "<Dark page>" --visual <id> \
       --first "<Table>.<first column>" --dummy "<Table>.Dummy Column" [--insert-dummy]
```

Model prerequisite (model-requests.yaml → semantic-model-authoring): `Dummy Column = ""` (no format string).
