# Informe de validación: Step 10 · pbi-house-design-system v0.1.0

Fecha: 2026-10-05 · Estado: **lista para instalar como versión 0.1.0** (con las brechas que se detallan en la sección 5)

---

## 1. Validación técnica

| Comprobación | Resultado |
|---|---|
| Formato de la skill (`quick_validate`, skill-creator) | ✅ Válida. Descripción de 1006 caracteres (máximo 1024) |
| `SKILL.md` | 216 líneas (límite propio: 300) |
| `check_tokens.py` | ✅ PASSED |
| `check_contrast.py` | ✅ PASSED: 40 combinaciones (30 cumplen, 10 son desviaciones aceptadas AD-001…005, 0 fallos) |
| `build_themes.py` | ✅ Dark: 19 tipos de visual · Light: 100 cambios de propiedad + 2 ajustes por tipo de elemento |
| `tests/run_tests.py` | ✅ **24/24** (estáticos, 16 informes de prueba sintéticos, gemelas, control de cambios) |
| Reglas | 106 reglas en 17 familias; IDs únicos; ningún HEX escrito directamente en las reglas |

## 2. Evals de comportamiento (con skill frente a sin skill)

Cada eval se lanzó con dos subagentes independientes: uno leía la skill y el otro trabajaba sin ella, con la misma petición.

| Eval | Con skill | Sin skill |
|---|---|---|
| **#2** "Create a P&L dashboard with Revenue, EBITDA, EBITDA %, YTD and LTM" | ✅ 6/6. T-STATEMENT con su gemela Light; EBITDA % como fila de ratio; YTD como bloque de columnas y LTM como pestañas de texto; filtros en la banda inferior; geometría exacta del grid; peticiones al modelo; **no hace ninguna pregunta** | ❌ 1/6. Propone una cuadrícula de KPI cards; filtros en la cabecera; escribe DAX (se mete en el terreno del modelo); hace 5 preguntas; sin gemela Light |
| **#3** "Make this KPI red" (página Light) | ✅ 4/4. Cita COLOR-006 y aplica el cambio también a la gemela (MODE-006); ofrece dos alternativas válidas; redacta la excepción con un rol como aprobador y fecha de revisión; no aplica nada sin que lo confirmes | ❌ 1/4. Propone el rojo `#FF6347` del tema (no corporativo) como cambio fijo; sin control de excepciones |
| **#5** "Redesign the P&L page… don't touch the numbers" | ✅ 4/4. Flujo de rediseño completo; plan de remediación con tokens y la gemela incluida; lista de lo que no se toca; control de cambios, gemelas y compliance; problemas aceptados de informes antiguos; detecta 2 conflictos posibles y pregunta en lugar de decidir | ⚠️ 2/4. Plan genérico razonable, pero pregunta dónde está el sistema de diseño y propone filas alternas (va contra TABLE-003) |
| **#7** "Write a DAX measure for EBITDA YTD" (no debe activarse) | ✅ No se activa; entrega el DAX y menciona el estándar de formato y el traspaso al modelo | ✅ (sin diferencia: es el resultado esperado) |

**Resultado:** con la skill se cumplen **18 de 18** expectativas; sin ella, **4 de 18**.

**Defecto detectado y corregido:** en el eval #5, el subagente usó un ID de regla que no existe ("C3/LAYOUT"). He añadido en el `SKILL.md` que en los planes siempre se cite la regla concreta (por ejemplo, LAYOUT-003).

## 3. Activación (descripción)

La optimización automática de la descripción (`run_loop.py`) necesita la CLI `claude -p` con sesión iniciada, y en este entorno no está disponible. Hice una **revisión manual** con las 16 frases de prueba de `tests/evals/trigger-evals.json`:

| Tipo | Frases | Cubiertas por la descripción |
|---|---|---|
| Deben activar la skill | 10 | 10. Se añadieron "restyling, tidying layouts or changing colours" para peticiones como "the slicers look messy" |
| No deben activarla | 6 | 6. Se añadieron "security (RLS)" y "data questions" a las exclusiones |

**Recomendación:** cuando tengas Claude Code con sesión iniciada, ejecuta `run_loop.py` con `trigger-evals.json` para medir la tasa real de activación (cada frase 3 veces, con 60% de entrenamiento y 40% de prueba).

## 4. Hallazgos sobre tus informes (los primeros resultados reales de la skill)

| Informe | Estado | Lo más relevante |
|---|---|---|
| RHG Consolidated Results | FAILED · 262 críticos | Las gemelas del P&L han divergido (7 visuales solo en una de las dos, 1 con medidas distintas, 3 con filtros distintos); la gemela Light no coincide en nombre por un espacio doble |
| Operational Report | FAILED · 876 críticos | **5 enlaces de navegación o bookmarks rotos**; Arial, Calibri y DIN; 29 cards antiguas; filtros fuera de la banda inferior |

Estas cifras son esperables, porque los informes son anteriores al sistema. **Recomendación:** registrar estos fallos como problemas aceptados en la primera auditoría y corregir primero los enlaces rotos (NAV-005) y la divergencia entre gemelas (MODE-001).

## 5. Brechas conocidas en v0.1.0 (no bloquean la instalación)

| ID | Brecha | Impacto | Qué necesito |
|---|---|---|---|
| G1 | **Logo en SVG** (v0.2: ya se incluyen los PNG/JPG en `assets/logo/`) (versiones para fondo claro y oscuro), pendiente P7 | PAGE-003 se aplica, pero la skill no lleva el fichero | Los dos SVG oficiales |
| G2 | **Iconos** (v0.2: ya hay luna, sol, filtros, play y home en PNG; faltan back, info y reset) | ASSET-001 no se puede cumplir | Un set SVG (home, back, info, reset, filtro, luna, sol) |
| G3 | **Paleta de series de gráficos** provisional (CH1) | Solo afecta a gráficos con varias series que no sean escenarios | Validarla cuando tengas un informe con más gráficos |
| G4 | **Reglas de barras y columnas** provisionales (CH1) | Poca muestra en tu corpus (19 gráficos) | Un informe con más gráficos |
| G5 | El compliance automatiza **27 de 106** reglas | El resto aparece como no evaluado y se revisa a mano o con capturas | Ampliarlo en v0.2 (ver sección 6) |
| G6 | El tema generado **no se ha abierto aún en Power BI Desktop** | Puede haber propiedades que Desktop ignore | Registrarlo en una copia de un informe y revisarlo con capturas |
| G7 | Plantillas SVG para medidas de imagen (sparklines, flechas): vacías | Opcional | Cuando las uses |

## 6. Plan de mejoras (roadmap v0.2 → v1.0)

| Versión | Contenido |
|---|---|
| **v0.1.1** | Prueba en Desktop (G6): registrar `corporate-dark.0.1.0.json` en una copia de *Consolidated Results* y revisar con capturas. Corregir propiedades que Desktop ignore |
| **v0.2.0** | Assets G1 y G2. Ampliar el compliance con las comprobaciones asistidas: PANEL-002/007, TABLE-001/003/006, SLICER-002/003, KPI-002/003, TEXT-004, MODE-003 (comparación con el perfil Light) y DATA-001 (consulta DAX de solo lectura) |
| **v0.3.0** | Primer rediseño real de una página (P&L RHG y su gemela) con el flujo completo. Ajustar reglas con lo aprendido |
| **v1.0.0** | Paleta de gráficos y reglas de barras validadas (G3/G4). Optimización de la descripción con `run_loop`. Revisión de AD-001…005 (fecha prevista 2027-04-04). Las reglas que entraron como warning pasan a critical (cambio de versión mayor) |

## 7. Instalación y uso

1. Pulsa **Guardar skill** en la tarjeta del fichero `pbi-house-design-system.skill`.
2. El paquete excluye `docs/`, `tests/` y `CHANGELOG.md` (según `.skillignore`). Guarda la carpeta completa en un repositorio git como fuente de verdad (D12).
3. **Red de seguridad para la activación:** añade a las instrucciones de tu proyecto: *"When working on Power BI report design (pages, visuals, themes, layout, Light/Dark), always use the pbi-house-design-system skill together with powerbi-report-cli."*
4. Primer uso recomendado: *"Audit the design of RHG Consolidated Results and propose a baseline."*
