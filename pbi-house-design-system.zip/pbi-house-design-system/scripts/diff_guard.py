#!/usr/bin/env python3
"""
diff_guard.py: verify that a design change touched ONLY formatting and position (C13, remediation plans).

Compares two copies of a PBIP project (before / after). Allowed changes:
  * visual.json  → position, visual.objects, visual.visualContainerObjects, (visual.visualType only if listed in --allow-type-change)
  * page.json    → objects, displayName (renames, N1), width/height/displayOption
  * theme files in StaticResources/RegisteredResources, new image/icon resources
  * report.json  → themeCollection, resourcePackages
  * _brief/**    → anything
Forbidden (reported as VIOLATION):
  * visual.query (fields, measures, sort), filterConfig (visual, page, report), visual type changes
  * bookmarks (except target lists when --allow-bookmarks), deleted visuals/pages
  * anything under *.SemanticModel (TMDL, M, measures)

Usage:
  python scripts/diff_guard.py --before <PBIP folder copy> --after <PBIP folder>
  (with git: export the previous revision first, e.g. `git worktree add ../before HEAD~1`)
Exit code: 0 = only allowed changes, 1 = violations.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ALLOWED_VISUAL_KEYS = {"position", "objects", "visualContainerObjects"}


def load(p: Path):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def canon(o):
    return json.dumps(o, sort_keys=True, ensure_ascii=False)


def files(root: Path):
    return {p.relative_to(root).as_posix(): p for p in root.rglob("*") if p.is_file() and ".pbi/" not in p.as_posix()
            and "/cache.abf" not in p.as_posix()}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--before", required=True)
    ap.add_argument("--after", required=True)
    ap.add_argument("--allow-bookmarks", action="store_true")
    a = ap.parse_args()
    b_root, a_root = Path(a.before), Path(a.after)
    fb, fa = files(b_root), files(a_root)
    violations, allowed = [], []

    for rel in sorted(set(fb) | set(fa)):
        pb, pa = fb.get(rel), fa.get(rel)
        if rel.startswith("_brief/") or "/_brief/" in rel:
            continue
        if ".SemanticModel/" in rel:
            if pb is None or pa is None or pb.read_bytes() != pa.read_bytes():
                violations.append((rel, "semantic model changed"))
            continue
        if pb is None:
            if "/RegisteredResources/" in rel:
                allowed.append((rel, "new resource"))
            elif rel.endswith("visual.json") or rel.endswith("page.json"):
                violations.append((rel, "new visual/page (content change, not formatting)"))
            else:
                allowed.append((rel, "new file"))
            continue
        if pa is None:
            if "/RegisteredResources/" in rel:
                allowed.append((rel, "resource removed"))
            else:
                violations.append((rel, "deleted"))
            continue
        if pb.read_bytes() == pa.read_bytes():
            continue
        jb, ja = load(pb), load(pa)
        if rel.endswith("visual.json") and jb and ja:
            vb, va = jb.get("visual", {}), ja.get("visual", {})
            if vb.get("visualType") != va.get("visualType"):
                violations.append((rel, f"visualType {vb.get('visualType')} → {va.get('visualType')}"))
            for k in sorted(set(vb) | set(va)):
                if k in ALLOWED_VISUAL_KEYS or k == "visualType":
                    continue
                if canon(vb.get(k)) != canon(va.get(k)):
                    violations.append((rel, f"visual.{k} changed"))
            for k in sorted(set(jb) | set(ja)):
                if k in ("visual", "position", "$schema"):
                    continue
                if canon(jb.get(k)) != canon(ja.get(k)):
                    (violations if k in ("filterConfig", "parentGroupName", "name") else allowed).append((rel, f"{k} changed"))
            if canon(jb.get("position")) != canon(ja.get("position")):
                allowed.append((rel, "position"))
            if canon(vb.get("objects")) != canon(va.get("objects")) or canon(vb.get("visualContainerObjects")) != canon(va.get("visualContainerObjects")):
                allowed.append((rel, "formatting"))
        elif rel.endswith("page.json") and jb and ja:
            for k in sorted(set(jb) | set(ja)):
                if canon(jb.get(k)) != canon(ja.get(k)):
                    ok = k in ("objects", "displayName", "width", "height", "displayOption", "$schema")
                    (allowed if ok else violations).append((rel, f"page.{k} changed"))
        elif rel.endswith(".bookmark.json"):
            (allowed if a.allow_bookmarks else violations).append((rel, "bookmark changed"))
        elif rel.endswith("report.json") and jb and ja:
            for k in sorted(set(jb) | set(ja)):
                if canon(jb.get(k)) != canon(ja.get(k)):
                    ok = k in ("themeCollection", "resourcePackages", "$schema", "objects")
                    (allowed if ok else violations).append((rel, f"report.{k} changed"))
        elif "/RegisteredResources/" in rel or "/SharedResources/" in rel:
            allowed.append((rel, "theme/resource changed"))
        else:
            violations.append((rel, "changed (unclassified)"))

    print(f"DIFF GUARD · {'FAILED' if violations else 'PASSED'} · {len(allowed)} allowed change(s), {len(violations)} violation(s)")
    for rel, msg in violations[:60]:
        print(f"  VIOLATION  {msg:45} {rel}")
    for rel, msg in allowed[:15]:
        print(f"  ok         {msg:45} {rel}")
    if len(allowed) > 15:
        print(f"  … {len(allowed) - 15} more allowed changes")
    return 1 if violations else 0


if __name__ == "__main__":
    sys.exit(main())
