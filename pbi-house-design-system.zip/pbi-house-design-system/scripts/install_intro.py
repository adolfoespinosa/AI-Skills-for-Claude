#!/usr/bin/env python3
"""
install_intro.py: install / refresh the corporate Intro page (locked brand template, PAGE-008/009/010).

Template (assets/templates/intro-page, v2): Dark-only page with background, world map, round RHG logo,
a title textbox (generic word "Title" by default) and the page navigator (right column).
The navigator height is DYNAMIC: buttons keep a good proportion for the number of tabs (PAGE-010).

Modes
  install (default)  copy the page + images, register images, Intro first + landing page, size the navigator
  --refresh-nav      re-size the navigator of an existing Intro page to the current number of tabs
                     (run it after adding/removing pages; part of every authoring batch)

Navigator sizing: n = visible, non-tooltip pages except Intro (Light twins are hidden, so not counted)
  h = clamp((469 - (n-1)*5) / n, 28, 48) px per button · H = n*h + (n-1)*5 · top stays at y 240

Usage:
  python scripts/install_intro.py --report "<path>/<name>.Report" [--title "Title"] [--replace]
  python scripts/install_intro.py --report "<path>/<name>.Report" --refresh-nav
"""
from __future__ import annotations

import argparse
import json
import secrets
import shutil
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
TEMPLATE = SKILL_ROOT / "assets" / "templates" / "intro-page"


def load(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def dump(p: Path, data):
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def is_intro(page_json: dict) -> bool:
    return page_json.get("displayName", "").strip() == "Intro"


def nav_height(n: int, cfg: dict) -> float:
    pad, top_h = cfg["cell_padding"], cfg["max_height"]
    if n <= 0:
        return cfg["button_max"]
    h = max(cfg["button_min"], min(cfg["button_max"], (top_h - (n - 1) * pad) / n))
    return min(top_h, n * h + (n - 1) * pad)


def count_tabs(defn: Path, meta: dict) -> int:
    n = 0
    for pid in meta.get("pageOrder", []):
        pj = defn / "pages" / pid / "page.json"
        if not pj.exists():
            continue
        p = load(pj)
        if is_intro(p) or p.get("type") == "Tooltip" or p.get("visibility") == "HiddenInViewMode":
            continue
        n += 1
    return n


def size_navigator(defn: Path, intro_id: str, meta: dict, manifest: dict) -> tuple[int, float]:
    cfg = manifest["navigator"]
    n = count_tabs(defn, meta)
    H = nav_height(n, cfg)
    scale = H / cfg["base_height"]
    vis = defn / "pages" / intro_id / "visuals"
    g = load(vis / cfg["group"] / "visual.json")
    g["position"]["height"] = round(H, 2)
    g["position"]["y"] = cfg["top"]
    dump(vis / cfg["group"] / "visual.json", g)
    for vid, spec in cfg["layers"].items():
        v = load(vis / vid / "visual.json")
        v["position"]["height"] = round(spec["base_height"] * scale, 2)
        pages = v["visual"]["objects"].setdefault("pages", [])
        pages[:] = [e for e in pages if e.get("selector", {}).get("id") != intro_id]
        pages.append({"properties": {"showPage": {"expr": {"Literal": {"Value": "false"}}}}, "selector": {"id": intro_id}})
        dump(vis / vid / "visual.json", v)
    return n, H


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--title", default="Title")
    ap.add_argument("--replace", action="store_true")
    ap.add_argument("--refresh-nav", action="store_true")
    a = ap.parse_args()

    rep = Path(a.report)
    defn = rep / "definition"
    meta_p = defn / "pages" / "pages.json"
    if not meta_p.exists():
        print(f"ERROR: not a PBIR report folder: {rep}")
        return 2
    manifest = load(TEMPLATE / "intro.manifest.json")
    meta = load(meta_p)
    existing = [pid for pid in meta.get("pageOrder", [])
                if (defn / "pages" / pid / "page.json").exists() and is_intro(load(defn / "pages" / pid / "page.json"))]

    if a.refresh_nav:
        if not existing:
            print("No Intro page found. Install it first.")
            return 1
        n, H = size_navigator(defn, existing[0], meta, manifest)
        print(f"NAVIGATOR REFRESHED · {n} tab(s) · height {H:.0f}px")
        return 0

    if existing and not a.replace:
        print(f"Intro page already present ({existing[0]}). Use --replace, or --refresh-nav to resize the navigator.")
        return 1
    for pid in existing:
        meta["pageOrder"].remove(pid)
        shutil.rmtree(defn / "pages" / pid, ignore_errors=True)

    new_id = secrets.token_hex(10)
    pdir = defn / "pages" / new_id
    (pdir / "visuals").mkdir(parents=True)
    title = json.dumps(a.title, ensure_ascii=False)[1:-1]
    (pdir / "page.json").write_text((TEMPLATE / "page.json").read_text(encoding="utf-8").replace("{{PAGE_ID}}", new_id),
                                    encoding="utf-8")
    for vd in sorted((TEMPLATE / "visuals").iterdir()):
        (pdir / "visuals" / vd.name).mkdir()
        (pdir / "visuals" / vd.name / "visual.json").write_text(
            (vd / "visual.json").read_text(encoding="utf-8").replace("{{TITLE}}", title), encoding="utf-8")

    rr = rep / "StaticResources" / "RegisteredResources"
    rr.mkdir(parents=True, exist_ok=True)
    report_p = defn / "report.json"
    report = load(report_p)
    pkgs = report.setdefault("resourcePackages", [])
    pkg = next((p for p in pkgs if p.get("type") == "RegisteredResources"), None)
    if pkg is None:
        pkg = {"name": "RegisteredResources", "type": "RegisteredResources", "items": []}
        pkgs.append(pkg)
    names = {i.get("name") for i in pkg.setdefault("items", [])}
    for img in manifest["resources"]:
        shutil.copy(TEMPLATE / "resources" / img, rr / img)
        if img not in names:
            pkg["items"].append({"name": img, "path": img, "type": "Image"})
    dump(report_p, report)

    meta["pageOrder"] = [new_id] + [p for p in meta.get("pageOrder", []) if p != new_id]
    meta["activePageName"] = new_id
    meta["landingPageName"] = new_id
    dump(meta_p, meta)
    n, H = size_navigator(defn, new_id, meta, manifest)

    print(f"INTRO INSTALLED · page {new_id} · first page / landing page · Dark only")
    print(f"  title: {a.title} · images registered: {len(manifest['resources'])} · navigator: {n} tab(s), {H:.0f}px")
    print("  remember: run --refresh-nav after adding or removing pages")
    return 0


if __name__ == "__main__":
    sys.exit(main())
