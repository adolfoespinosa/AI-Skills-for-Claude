# Design Compliance Report

**Report:** <name> · **Design System:** v<x.y.z> · **Pages:** <n> (+<n> twins) · **Date:** <yyyy-mm-dd>
**Status:** <FAILED | PASSED WITH WARNINGS | PASSED WITH WAIVERS | PASSED>

| Status | Count |
|---|---|
| Critical | <n> |
| Warnings | <n> |
| Waived | <n> |
| Accepted deviations | <n> |
| Baseline | <n> |
| Passed | <n> |
| Not evaluated | <n> |

## Critical
| Rule | Page | Visual | Expected | Found |
|---|---|---|---|---|

## Warnings
| Rule | Page | Visual | Expected | Found |
|---|---|---|---|---|

## Waived / accepted / not evaluated
- …

## Visual review (VR-01…09)
- …

**Next step:** <remediation plan RP-… | ready for publishing>
