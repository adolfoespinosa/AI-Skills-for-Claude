<!--
STATUS: v0.1 (Step 6, batch 2)
PURPOSE: Allowed chart types and per-type formatting (CHART-*).
LOADED: designing or modifying charts.
-->
# Charts

## 1. Allowed visuals

The allowed list is **what the corpus uses**. Any other type needs a design-system decision (new MINOR
version) or a recorded exception.

| Visual | Use |
|---|---|
| `lineChart` | Monthly tracking with scenarios (ACT / FCT / REF) |
| `areaChart` | Same, with an area fill (ACT to date, REF) |
| `waterfallChart` | Bridges (e.g. EBITDA vs reference) |
| `clusteredBarChart` | Rankings and comparisons by category |
| `clusteredColumnChart` / `columnChart` | Period comparisons |

Not approved yet: pie, donut, gauge, scatter, combo, treemap, ribbon, map, and any custom visual.

## 2. Common formatting

| Property | Standard |
|---|---|
| Title | Panel title bar (PANEL-002), subtitle row for context |
| Data labels | On, `type.label`, `text.primary` |
| Category axis | On, `type.label`, no title; months formatted `Mmm-YY` |
| Value axis | Line and area: **off** (labels carry values) · waterfall and bar/column: on, right side for waterfall |
| Gridlines | Only when the value axis is on: `color.gridline`, dotted |
| Legend | Scenario charts: top-left, `type.label` · single series: off |
| Visual header | Hidden (PANEL-006) |
| Background | `surface.panel` |

## 3. Rules

```yaml
- id: CHART-001
  title: Allowed chart types only
  status: active
  since: 0.1.0
  severity: critical
  priority: P4
  modes: [dark, light]
  applies_to: ["*Chart", "*chart", pieChart, donutChart, gauge, scatterChart, treemap, map, filledMap]
  statement: "Only lineChart, areaChart, waterfallChart, clusteredBarChart, clusteredColumnChart and columnChart are allowed."
  check: auto
  exceptions: allowed

- id: CHART-002
  title: Scenario lines
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [lineChart, areaChart]
  statement: "Scenario series MUST follow COLOR-010 (ACT solid with markers, FCT dashed, REF reference colour; ACT area up to the current period)."
  check: assisted
  exceptions: allowed

- id: CHART-003
  title: Waterfall standard
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [waterfallChart]
  statement: "Waterfalls MUST use COLOR-011 sentiment colours, data labels on top, value axis on the right with dotted gridlines, and the total as the last category."
  check: auto
  exceptions: allowed

- id: CHART-004
  title: Labels instead of axes on tracking lines
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [lineChart, areaChart]
  statement: "Tracking line and area charts MUST show data labels and hide the value axis and gridlines."
  check: auto
  exceptions: allowed

- id: CHART-005
  title: Text sizes on charts
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: ["*Chart"]
  statement: "Axis labels, data labels and legends MUST use type.label (8 pt)."
  check: auto
  exceptions: allowed

- id: CHART-006
  title: Legend
  status: active
  since: 0.1.0
  severity: info
  priority: P4
  modes: [dark, light]
  applies_to: ["*Chart"]
  statement: "Multi-series charts SHOULD show the legend top-left; single-series charts MUST hide it."
  check: auto
  exceptions: allowed

- id: CHART-007
  title: Bar and column colours
  status: active
  since: 0.1.0
  severity: warning
  priority: P3
  modes: [dark, light]
  applies_to: [clusteredBarChart, clusteredColumnChart, columnChart]
  statement: "Single-measure bars MUST use scenario.actual (or scenario.reference for the reference measure); highlighting a category MUST use a condition, never a static status colour."
  check: assisted
  exceptions: allowed
```

## 4. Open points
- CH1: Very few charts in the corpus (19). Rules for bar/column charts are provisional. Revisit when a
  chart-heavy report is available.
