"""
_tokens.py: shared helpers for loading and resolving tokens/tokens.yaml.

Reference syntax: "{path.to.token}" (dot path from the tokens root).
A semantic colour is a mode map {dark: ..., light: ...}. Resolving a path that points at a
mode map requires a mode. A path ending in ".dark"/".light" pins the mode explicitly.

Rule-file aliases (used in references/**/*.md expect blocks):
  {color.X}  -> semantic.color.X      {type.X}   -> semantic.type.X
  {radius.X} -> semantic.radius.X     {space.X}  -> semantic.space.X
  {border.X} -> semantic.border.X     {font.X}   -> primitive.font.X
  {layout.X} -> layout.X
"""
from __future__ import annotations

import re
from pathlib import Path

import yaml

SKILL_ROOT = Path(__file__).resolve().parent.parent
TOKENS_PATH = SKILL_ROOT / "tokens" / "tokens.yaml"
REF = re.compile(r"\{([A-Za-z0-9_.\-]+)\}")
HEX = re.compile(r"^#[0-9A-Fa-f]{6}$")
MODES = ("dark", "light")
ALIASES = {
    "color": "semantic.color", "type": "semantic.type", "radius": "semantic.radius",
    "space": "semantic.space", "border": "semantic.border", "font": "primitive.font",
    "layout": "layout",
}


class TokenError(Exception):
    pass


def load(path: Path | str = TOKENS_PATH) -> dict:
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def get(tokens: dict, path: str):
    node = tokens
    for part in path.split("."):
        if isinstance(node, dict) and part in node:
            node = node[part]
        elif isinstance(node, list) and part.isdigit() and int(part) < len(node):
            node = node[int(part)]
        else:
            raise TokenError(f"unknown token path: {path}")
    return node


def expand_alias(path: str) -> str:
    head, _, rest = path.partition(".")
    if head in ALIASES and not path.startswith(("semantic.", "primitive.", "layout.", "component.")):
        return f"{ALIASES[head]}.{rest}" if rest else ALIASES[head]
    return path


def is_mode_map(node) -> bool:
    return isinstance(node, dict) and set(node.keys()) == set(MODES)


def resolve(tokens: dict, value, mode: str | None = None, _stack: tuple = ()):
    """Resolve a literal, a "{ref}" string, or a token path to its final value for `mode`."""
    if isinstance(value, str):
        m = REF.fullmatch(value.strip())
        if not m:
            return value
        path = expand_alias(m.group(1))
        if path in _stack:
            raise TokenError(f"reference cycle: {' -> '.join(_stack + (path,))}")
        node = get(tokens, path)
        return resolve(tokens, node, mode, _stack + (path,))
    if is_mode_map(value):
        if mode is None:
            raise TokenError("mode required to resolve a mode map")
        return resolve(tokens, value[mode], mode, _stack)
    return value


def resolve_path(tokens: dict, path: str, mode: str | None = None):
    return resolve(tokens, "{" + path + "}", mode)


def walk(node, prefix: str = ""):
    """Yield (path, value) for every leaf."""
    if isinstance(node, dict):
        for k, v in node.items():
            yield from walk(v, f"{prefix}.{k}" if prefix else str(k))
    elif isinstance(node, list):
        for i, v in enumerate(node):
            yield from walk(v, f"{prefix}.{i}")
    else:
        yield prefix, node


def mode_maps(node, prefix: str = ""):
    """Yield (path, node) for every mode map (or near-mode-map) under node."""
    if isinstance(node, dict):
        keys = set(node.keys())
        if keys & set(MODES) and all(not isinstance(v, dict) for v in node.values()):
            yield prefix, node
            return
        for k, v in node.items():
            yield from mode_maps(v, f"{prefix}.{k}" if prefix else str(k))


def all_color_values(tokens: dict, mode: str) -> set[str]:
    out = set()
    for path, _ in mode_maps(tokens["semantic"]["color"], "semantic.color"):
        v = resolve_path(tokens, path, mode)
        if isinstance(v, str) and HEX.match(v):
            out.add(v.upper())
    return out


def luminance(hex_color: str) -> float:
    c = [int(hex_color[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    c = [x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4 for x in c]
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]


def contrast(a: str, b: str) -> float:
    la, lb = sorted((luminance(a), luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def load_rule_blocks(root: Path = SKILL_ROOT) -> list[tuple[str, object]]:
    """Return (file, parsed yaml) for every ```yaml block in references/**/*.md."""
    out = []
    for f in sorted((root / "references").rglob("*.md")):
        text = f.read_text(encoding="utf-8")
        for block in re.findall(r"```yaml\n(.*?)```", text, re.S):
            out.append((str(f.relative_to(root)), yaml.safe_load(block)))
    return out


def accepted_deviations(root: Path = SKILL_ROOT) -> list[dict]:
    for _, data in load_rule_blocks(root):
        if isinstance(data, dict) and "accepted_deviations" in data:
            return data["accepted_deviations"]
    return []


def font_stack(tokens: dict, family: str) -> str:
    """FS1: Power BI renders a font correctly only with its stack ("'Segoe UI Bold', wf_segoe-ui_bold, ...")."""
    fam = str(family).split(",")[0].strip().strip("'\"")
    return tokens["primitive"].get("font_stack", {}).get(fam, family)


def is_bare_font(value: str) -> bool:
    return isinstance(value, str) and "wf_" not in value and "," not in value


def pbir_font_literal(tokens: dict, family: str) -> dict:
    """PBIR literal for a font: the stack inside single quotes, inner quotes doubled."""
    return {"expr": {"Literal": {"Value": "'" + font_stack(tokens, family).replace("'", "''") + "'"}}}


def visual_level_value(tokens: dict, rule: dict):
    """Expected value of a component.visual_level entry (token number or fixed value)."""
    return resolve(tokens, rule["token"]) if "token" in rule else rule["value"]


def apply_visual_level(body: dict, tokens: dict) -> int:
    """Write every component.visual_level style on a visual.json body (themes ignore them). Returns changes."""
    v = body.get("visual", {})
    n = 0
    for r in tokens["component"].get("visual_level", []):
        if v.get("visualType") != r["visual"]:
            continue
        val = visual_level_value(tokens, r)
        lit = {"expr": {"Literal": {"Value": f"{val}L" if isinstance(val, (int, float)) else f"'{val}'"}}}
        entries = v.setdefault("objects", {}).setdefault(r["object"], [])
        sel = r.get("selector")
        e = next((x for x in entries if (x.get("selector") or {}).get("id") == sel), None) if sel else \
            next((x for x in entries if not x.get("selector")), None)
        if e is None:
            e = {"properties": {}}
            if sel:
                e["selector"] = {"id": sel}
            entries.append(e)
        if e.setdefault("properties", {}).get(r["property"]) != lit:
            e["properties"][r["property"]] = lit
            n += 1
    return n
