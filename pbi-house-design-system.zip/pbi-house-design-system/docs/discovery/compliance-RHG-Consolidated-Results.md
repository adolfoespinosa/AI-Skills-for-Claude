# Design Compliance Report

**Report:** RHG Consolidated Results.Report · **Design System:** v0.1.0 · **Pages:** 8 (+1 twins) · **Visuals:** 210 · **Date:** 2026-10-05
**Status:** FAILED

| Status | Count | By rule |
|---|---|---|
| Critical | 262 | COLOR-001 ×71, TYPO-001 ×50, LAYOUT-003 ×44, LAYOUT-004 ×36, LAYOUT-005 ×27, LAYOUT-008 ×17, KPI-001 ×9, COLOR-006 ×5, TYPO-002 ×2, PAGE-001 ×1 |
| Warnings | 200 | LAYOUT-007 ×109, FMT-002 ×79, MODE-002 ×7, NAV-006 ×3, COLOR-009 ×2 |
| Waived | 0 | — |
| Baseline | 0 | — |
| Passed rules | 12 | ACCESS-004, CHART-001, COLOR-005, COLOR-011, KPI-005, LAYOUT-001, LAYOUT-002, MODE-004, NAV-005, PAGE-002, PAGE-004, TIP-001 |
| Not evaluated rules | 79 | manual / assisted / not yet automated |

## Critical
| Rule | Page | Visual | Property | Expected | Found |
|---|---|---|---|---|---|
| LAYOUT-005 | Intro | image 42841089 | position | inside one band | y 332–720 |
| LAYOUT-005 | Intro | image 89a96c37 | position | inside one band | y 11–277 |
| LAYOUT-005 | Intro | textbox a0f9aee0 | position | inside one band | y 60–250 |
| LAYOUT-003 | Intro | textbox 5b0413cf | x | column start | 1156.1 |
| LAYOUT-003 | Intro | group 84b57c25 | x | column start | 979.6 |
| LAYOUT-003 | Intro | card 98973b0b | x | column start | 292.2 |
| LAYOUT-004 | Intro | textbox 5b0413cf | width | span width | 123.9 |
| LAYOUT-004 | Intro | group 84b57c25 | width | span width | 286.9 |
| LAYOUT-004 | Intro | card 98973b0b | width | span width | 439.1 |
| LAYOUT-008 | Intro | group 84b57c25 | bounds | no overlap | overlaps textbox 5b0413cf |
| LAYOUT-005 | ▶  P&L RHG | shape 01c14663 | position | inside one band | y 10–76 |
| LAYOUT-005 | ▶  P&L RHG | shape 89c841e1 | position | inside one band | y 87–656 |
| LAYOUT-005 | ▶  P&L RHG | textbox f9faa4e2 | position | inside one band | y 10–75 |
| LAYOUT-003 | ▶  P&L RHG | group 264a6826 | x | column start | 618.4 |
| LAYOUT-003 | ▶  P&L RHG | group 55107621 | x | column start | 685.0 |
| LAYOUT-003 | ▶  P&L RHG | group 5c50870a | x | column start | 11.0 |
| LAYOUT-003 | ▶  P&L RHG | group b77eeec2 | x | column start | 619.0 |
| LAYOUT-003 | ▶  P&L RHG | slicer d5b93851 | x | column start | 5.8 |
| LAYOUT-004 | ▶  P&L RHG | group 264a6826 | width | span width | 639.0 |
| LAYOUT-004 | ▶  P&L RHG | group 55107621 | width | span width | 428.0 |
| LAYOUT-004 | ▶  P&L RHG | group 5c50870a | width | span width | 592.0 |
| LAYOUT-004 | ▶  P&L RHG | group b77eeec2 | width | span width | 641.8 |
| LAYOUT-008 | ▶  P&L RHG | group 55107621 | bounds | no overlap | overlaps group 264a6826 |
| LAYOUT-008 | ▶  P&L RHG | group b77eeec2 | bounds | no overlap | overlaps group 55107621 |
| LAYOUT-005 | ▶  P&L Leased | shape 7caaddb2 | position | inside one band | y 87–656 |
| LAYOUT-005 | ▶  P&L Leased | textbox ecdb55ab | position | inside one band | y 10–75 |
| LAYOUT-005 | ▶  P&L Leased | shape ed992a1a | position | inside one band | y 10–76 |
| LAYOUT-003 | ▶  P&L Leased | clusteredColumnChart 02bc7161 | x | column start | 1030.7 |
| LAYOUT-003 | ▶  P&L Leased | group 04419268 | x | column start | 11.1 |
| LAYOUT-003 | ▶  P&L Leased | group 44254ca0 | x | column start | 685.0 |
| LAYOUT-003 | ▶  P&L Leased | group ab4d7652 | x | column start | 586.7 |
| LAYOUT-003 | ▶  P&L Leased | group ed3706d5 | x | column start | 587.1 |
| LAYOUT-003 | ▶  P&L Leased | slicer 0dcebdd4 | x | column start | 5.8 |
| LAYOUT-004 | ▶  P&L Leased | clusteredColumnChart 02bc7161 | width | span width | 226.0 |
| LAYOUT-004 | ▶  P&L Leased | group 04419268 | width | span width | 561.7 |
| LAYOUT-004 | ▶  P&L Leased | group 44254ca0 | width | span width | 428.0 |
| LAYOUT-004 | ▶  P&L Leased | group ab4d7652 | width | span width | 676.7 |
| LAYOUT-004 | ▶  P&L Leased | group ed3706d5 | width | span width | 431.0 |
| LAYOUT-008 | ▶  P&L Leased | group 44254ca0 | bounds | no overlap | overlaps clusteredColumnChart 02bc7161 |
| LAYOUT-008 | ▶  P&L Leased | group ab4d7652 | bounds | no overlap | overlaps group 44254ca0 |
| LAYOUT-008 | ▶  P&L Leased | group ed3706d5 | bounds | no overlap | overlaps group 44254ca0 |
| LAYOUT-005 | ▶  P&L Leased KPI's | shape 1aeb6017 | position | inside one band | y 87–656 |
| LAYOUT-005 | ▶  P&L Leased KPI's | shape 22255349 | position | inside one band | y 10–76 |
| LAYOUT-005 | ▶  P&L Leased KPI's | textbox 4be8bf5f | position | inside one band | y 10–75 |
| LAYOUT-003 | ▶  P&L Leased KPI's | group 2db9c4c3 | x | column start | 685.0 |
| LAYOUT-003 | ▶  P&L Leased KPI's | columnChart 2dee0782 | x | column start | 586.7 |
| LAYOUT-003 | ▶  P&L Leased KPI's | group 4729b450 | x | column start | 9.3 |
| LAYOUT-003 | ▶  P&L Leased KPI's | group 4db40ae2 | x | column start | 586.7 |
| LAYOUT-003 | ▶  P&L Leased KPI's | slicer aee863bf | x | column start | 5.8 |
| LAYOUT-004 | ▶  P&L Leased KPI's | group 2db9c4c3 | width | span width | 428.0 |
| LAYOUT-004 | ▶  P&L Leased KPI's | columnChart 2dee0782 | width | span width | 671.3 |
| LAYOUT-004 | ▶  P&L Leased KPI's | group 4729b450 | width | span width | 563.3 |
| LAYOUT-004 | ▶  P&L Leased KPI's | group 4db40ae2 | width | span width | 676.7 |
| LAYOUT-008 | ▶  P&L Leased KPI's | columnChart 2dee0782 | bounds | no overlap | overlaps group 2db9c4c3 |
| LAYOUT-008 | ▶  P&L Leased KPI's | group 4db40ae2 | bounds | no overlap | overlaps group 2db9c4c3 |
| LAYOUT-005 | ▶ P&L RHG Light | textbox 1f2dd5df | position | inside one band | y 12–77 |
| LAYOUT-005 | ▶ P&L RHG Light | shape 2affa192 | position | inside one band | y 93–663 |
| LAYOUT-005 | ▶ P&L RHG Light | shape 99f7818b | position | inside one band | y 10–76 |
| LAYOUT-003 | ▶ P&L RHG Light | group 36782d16 | x | column start | 618.4 |
| LAYOUT-003 | ▶ P&L RHG Light | group 6bb892cd | x | column start | 685.0 |
| … | 202 more in the JSON report | | | | |

## Warnings
| Rule | Page | Visual | Property | Expected | Found |
|---|---|---|---|---|---|
| LAYOUT-007 | Intro | image 42841089 | y | integer | 332.34 |
| LAYOUT-007 | Intro | textbox 5b0413cf | x | integer | 1156.11 |
| LAYOUT-007 | Intro | group 84b57c25 | x | integer | 979.59 |
| LAYOUT-007 | Intro | image 89a96c37 | x | integer | 19.09 |
| LAYOUT-007 | Intro | card 98973b0b | x | integer | 292.24 |
| LAYOUT-007 | Intro | textbox a0f9aee0 | x | integer | 281.48 |
| LAYOUT-007 | ▶  P&L RHG | shape 01c14663 | y | integer | 10.22 |
| LAYOUT-007 | ▶  P&L RHG | advancedSlicerVisual 2040bae1 | x | integer | 473.43 |
| LAYOUT-007 | ▶  P&L RHG | group 264a6826 | x | integer | 618.36 |
| LAYOUT-007 | ▶  P&L RHG | actionButton 2960affa | x | integer | 1233.33 |
| LAYOUT-007 | ▶  P&L RHG | advancedSlicerVisual 2d22dca9 | x | integer | 210.50 |
| LAYOUT-007 | ▶  P&L RHG | slicer 338bd899 | x | integer | 94.17 |
| LAYOUT-007 | ▶  P&L RHG | image 35e502a0 | x | integer | 1184.94 |
| LAYOUT-007 | ▶  P&L RHG | group 55107621 | height | integer | 497.78 |
| LAYOUT-007 | ▶  P&L RHG | card 7d2809b7 | x | integer | 715.88 |
| LAYOUT-007 | ▶  P&L RHG | group b77eeec2 | width | integer | 641.84 |
| LAYOUT-007 | ▶  P&L RHG | slicer d5b93851 | x | integer | 5.83 |
| LAYOUT-007 | ▶  P&L RHG | textbox f9faa4e2 | width | integer | 244.70 |
| LAYOUT-007 | ▶  P&L Leased | clusteredColumnChart 02bc7161 | x | integer | 1030.67 |
| LAYOUT-007 | ▶  P&L Leased | group 04419268 | x | integer | 11.15 |
| LAYOUT-007 | ▶  P&L Leased | slicer 0dcebdd4 | x | integer | 5.83 |
| LAYOUT-007 | ▶  P&L Leased | slicer 40fdd52e | x | integer | 94.17 |
| LAYOUT-007 | ▶  P&L Leased | group 44254ca0 | height | integer | 497.78 |
| LAYOUT-007 | ▶  P&L Leased | actionButton 4bc8174a | x | integer | 1233.33 |
| LAYOUT-007 | ▶  P&L Leased | advancedSlicerVisual 553fb697 | x | integer | 210.50 |
| LAYOUT-007 | ▶  P&L Leased | image a93462bb | x | integer | 1184.94 |
| LAYOUT-007 | ▶  P&L Leased | group ab4d7652 | x | integer | 586.67 |
| LAYOUT-007 | ▶  P&L Leased | advancedSlicerVisual dff8fe29 | x | integer | 473.43 |
| LAYOUT-007 | ▶  P&L Leased | textbox ecdb55ab | width | integer | 244.70 |
| LAYOUT-007 | ▶  P&L Leased | group ed3706d5 | x | integer | 587.07 |
| LAYOUT-007 | ▶  P&L Leased | shape ed992a1a | y | integer | 10.22 |
| LAYOUT-007 | ▶  P&L Leased KPI's | shape 22255349 | y | integer | 10.22 |
| LAYOUT-007 | ▶  P&L Leased KPI's | group 2db9c4c3 | height | integer | 497.78 |
| LAYOUT-007 | ▶  P&L Leased KPI's | columnChart 2dee0782 | x | integer | 586.67 |
| LAYOUT-007 | ▶  P&L Leased KPI's | group 4729b450 | x | integer | 9.33 |
| LAYOUT-007 | ▶  P&L Leased KPI's | textbox 4be8bf5f | width | integer | 244.70 |
| LAYOUT-007 | ▶  P&L Leased KPI's | group 4db40ae2 | x | integer | 586.67 |
| LAYOUT-007 | ▶  P&L Leased KPI's | image 592cb5df | x | integer | 1184.94 |
| LAYOUT-007 | ▶  P&L Leased KPI's | slicer aee863bf | x | integer | 5.83 |
| LAYOUT-007 | ▶  P&L Leased KPI's | advancedSlicerVisual d2c7ecf2 | x | integer | 210.50 |
| LAYOUT-007 | ▶  P&L Leased KPI's | advancedSlicerVisual d388d400 | x | integer | 473.43 |
| LAYOUT-007 | ▶  P&L Leased KPI's | actionButton df1b8146 | x | integer | 1233.33 |
| LAYOUT-007 | ▶  P&L Leased KPI's | slicer e106de89 | x | integer | 94.17 |
| LAYOUT-007 | ▶ P&L RHG Light | textbox 1f2dd5df | x | integer | 490.67 |
| LAYOUT-007 | ▶ P&L RHG Light | advancedSlicerVisual 1f38b096 | x | integer | 464.20 |
| LAYOUT-007 | ▶ P&L RHG Light | advancedSlicerVisual 21d0e045 | x | integer | 210.50 |
| LAYOUT-007 | ▶ P&L RHG Light | shape 2affa192 | x | integer | 612.67 |
| LAYOUT-007 | ▶ P&L RHG Light | slicer 30c2b24b | x | integer | 5.83 |
| LAYOUT-007 | ▶ P&L RHG Light | group 36782d16 | x | integer | 618.36 |
| LAYOUT-007 | ▶ P&L RHG Light | group 6bb892cd | y | integer | 147.17 |
| LAYOUT-007 | ▶ P&L RHG Light | advancedSlicerVisual 80ebc490 | x | integer | 564.67 |
| LAYOUT-007 | ▶ P&L RHG Light | tableEx 91ef253f | x | integer | 11.11 |
| LAYOUT-007 | ▶ P&L RHG Light | shape 99f7818b | y | integer | 10.22 |
| LAYOUT-007 | ▶ P&L RHG Light | advancedSlicerVisual af825eb3 | y | integer | 669.33 |
| LAYOUT-007 | ▶ P&L RHG Light | image b460abd9 | x | integer | 1184.94 |
| LAYOUT-007 | ▶ P&L RHG Light | group baa43cf1 | width | integer | 641.84 |
| LAYOUT-007 | ▶ P&L RHG Light | slicer bbf0722e | x | integer | 94.17 |
| LAYOUT-007 | ▶ P&L RHG Light | card bfd37160 | y | integer | 32.83 |
| LAYOUT-007 | ▶ P&L RHG Light | actionButton e9dc4925 | y | integer | 674.67 |
| LAYOUT-007 | ▶  P&L Fee Business | slicer 0a389be3 | x | integer | 94.17 |
| … | 140 more in the JSON report | | | | |

## Not evaluated
ACCESS-001, ACCESS-002, ACCESS-003, ASSET-001, CHART-002, CHART-003, CHART-004, CHART-005, CHART-006, CHART-007, COLOR-002, COLOR-003, COLOR-004, COLOR-007, COLOR-008, COLOR-010, COLOR-012, DATA-001, DATA-002, DATA-003, DATA-004, DATA-005, FMT-001, FMT-003, FMT-004, KPI-002, KPI-003, KPI-004, KPI-006, KPI-007, LAYOUT-006, LAYOUT-009, LAYOUT-010, MODE-001, MODE-003, MODE-005, MODE-006, MODE-007, NAV-001, NAV-002, NAV-003, NAV-004, PAGE-003, PAGE-005, PAGE-006, PAGE-007, PANEL-001, PANEL-002, PANEL-003, PANEL-004, PANEL-005, PANEL-006, PANEL-007, SLICER-001, SLICER-002, SLICER-003, SLICER-004, SLICER-005, SLICER-006, SLICER-007, TABLE-001, TABLE-002, TABLE-003, TABLE-004, TABLE-005, TABLE-006, TABLE-007, TABLE-008, TEXT-001, TEXT-002, TEXT-003, TEXT-004, TEXT-005, TEXT-006, TIP-002, TIP-003, TYPO-003, TYPO-004, TYPO-005

**Next step:** remediation plan (`remediation-plan.yaml`)
