<!--
STATUS: v0.1 (Step 6, batch 3)
PURPOSE: Contract for layout tables that drive P&L row formatting (DATA-*).
LOADED: P&L / statement matrices driven by a layout table (DIM_Layout / DIM_Layouts).
-->
# Data-driven Formatting (layout tables)

## 1. Why this exists

In the financial reports, a **layout table** (`DIM_Layout` / `DIM_Layouts`) decides which rows appear, in which
order, with which indentation, format, sign and **colour**. Dispatcher measures read it. The colours are
therefore **data**: the theme and the PBIR checker cannot see them. This file makes them part of the design
system.

Ownership: the layout table belongs to the data or model owner. This skill defines the allowed values and
validates them. Changes go through a handoff (section 4).

## 2. Contract (columns with design meaning)

| Column | Allowed values | Design meaning |
|---|---|---|
| `Highlight Code` | blank · 1 · 2 · 3 | blank = normal row · 1, 2 = **total band** · 3 = **highlight band** |
| `Background Color` | token value of `surface.total_row` (codes 1, 2) · `surface.highlight_row` (code 3) · blank | Row background |
| `Font Color` | token value of `text.on_total_row` (1, 2) · `text.on_highlight_row` (3) · blank | Row text |
| `KPI Heading` | Label, indented with non-breaking spaces; ratio rows prefixed `↪` | Indentation and ratio marker |
| `ABS Format` / `DEV Format` / `%DEV Format` | Format strings from `formatting-standards.md` | Number format per row |
| `Sign` / `Multiplier` | ±1 / 1 or 100 | Sign convention and % scaling (FMT-004) |

Indentation ladder (from the handover): depth **0 · 3 · 4 · 6 · 10 · 12** non-breaking spaces. The depth must
agree with `Highlight Code` (totals at depth 0).

Current values (corpus): codes 1 and 2 use the slate +40% band with white text (accepted deviation AD-004);
code 3 uses the slate band with light-blue text.

## 3. Rules

```yaml
- id: DATA-001
  title: Layout colours are tokens
  status: active
  since: 0.1.0
  severity: critical
  priority: P2
  modes: [dark, light]
  applies_to: [layout_table]
  statement: "Every non-blank Background Color / Font Color value MUST equal the token value assigned to its Highlight Code (section 2)."
  check: assisted          # DAX query via integration/tooling.md
  exceptions: allowed

- id: DATA-002
  title: Highlight code consistency
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [layout_table]
  statement: "Rows with the same Highlight Code MUST share the same Background Color and Font Color; blank code MUST have blank colours."
  check: assisted
  exceptions: allowed

- id: DATA-003
  title: Layout format strings
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [layout_table]
  statement: "ABS / DEV / %DEV Format values MUST be format strings allowed by FMT-001."
  check: assisted
  exceptions: allowed

- id: DATA-004
  title: Indentation ladder
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [layout_table]
  statement: "Leading non-breaking spaces in KPI Heading MUST be one of 0, 3, 4, 6, 10, 12; ratio rows MUST start with '↪' after the indentation."
  check: assisted
  exceptions: allowed

- id: DATA-005
  title: Changes through the data owner
  status: active
  since: 0.1.0
  severity: critical
  priority: P0
  modes: [dark, light]
  applies_to: [workflow]
  statement: "This skill MUST NOT edit the layout table. Required changes are listed in model-requests.yaml (request: layout_table) for the data/model owner."
  check: manual
  exceptions: forbidden
```

## 4. Validation query (read-only)

Run through the model tools listed in `integration/tooling.md`. Adjust the table name to the report.

```dax
EVALUATE
SUMMARIZECOLUMNS (
    'DIM_Layouts'[Highlight Code],
    'DIM_Layouts'[Background Color],
    'DIM_Layouts'[Font Color],
    "Rows", COUNTROWS ( 'DIM_Layouts' )
)
```

Compare the result with the token values. The query returns design metadata only, no business figures.
