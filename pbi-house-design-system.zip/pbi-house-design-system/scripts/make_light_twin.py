#!/usr/bin/env python3
"""
make_light_twin.py: create (or rebuild) the Light twin of a Dark page (MODE-001…006, D16).

Deterministic helper executed in the powerbi-report-cli authoring step (decision D1a):
  1. Duplicates "<page>" as "<page> Light" (hidden), with new visual IDs (groups and interactions remapped)
  2. Applies the Light override profile (assets/themes/light-overrides.<ver>.json):
       - '*' entries → container objects (title, subTitle, background, border) on every visual,
                       axis entries on charts only
       - visual-type entries → that visual type
       - role profiles (text tabs, KPI tile outline)
  3. Re-colours explicit literal colours with the token map dark→light (most frequent semantic meaning)
  4. Swaps assets: logo-white.png → logo-blue.png, moon.png → sun.png (registers them if needed)
  5. Points the mode toggle of each twin to the other page
Page background/outspace come from the profile 'page' entries.

Usage: python scripts/make_light_twin.py --report "<path>/<name>.Report" --page "<Dark page display name>" [--replace]
"""
from __future__ import annotations

import argparse
import collections
import copy
import json
import secrets
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _tokens as T  # noqa: E402

SKILL = T.SKILL_ROOT
CONTAINER = {"title", "subTitle", "background", "border", "dropShadow", "visualHeader", "visualTooltip",
             "visualHeaderTooltip", "padding", "visualLink", "spacing"}
CHARTS = {"lineChart", "areaChart", "waterfallChart", "clusteredBarChart", "clusteredColumnChart", "columnChart", "barChart"}
SWAPS = {"logo-white.png": "logo-blue.png", "moon.png": "sun.png"}


def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def dump(p, d): Path(p).write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding="utf-8")


def lit(v):
    if isinstance(v, bool):
        return {"expr": {"Literal": {"Value": "true" if v else "false"}}}
    if isinstance(v, (int, float)):
        return {"expr": {"Literal": {"Value": f"{v}D"}}}
    if isinstance(v, str) and v.startswith("#"):
        return {"solid": {"color": {"expr": {"Literal": {"Value": f"'{v}'"}}}}}
    return {"expr": {"Literal": {"Value": "'" + str(v).replace("'", "''") + "'"}}}


def set_prop(objs: dict, obj: str, prop: str, value, selector: str | None):
    entries = objs.setdefault(obj, [])
    for e in entries:
        sel = (e.get("selector") or {}).get("id")
        if sel == selector or (selector is None and "selector" not in e):
            e.setdefault("properties", {})[prop] = lit(value)
            return
    e = {"properties": {prop: lit(value)}}
    if selector:
        e["selector"] = {"id": selector}
    entries.append(e)


def color_map(tokens) -> dict:
    votes = collections.defaultdict(collections.Counter)
    for path, _ in T.mode_maps(tokens["semantic"]["color"], "semantic.color"):
        d, l = T.resolve_path(tokens, path, "dark").upper(), T.resolve_path(tokens, path, "light").upper()
        votes[d][l] += 1
    return {d: c.most_common(1)[0][0] for d, c in votes.items()}


def recolor(node, cmap):
    if isinstance(node, dict):
        c = node.get("color")
        if isinstance(c, str) and c.startswith("#") and c[:7].upper() in cmap:   # textbox textStyle colours
            node["color"] = cmap[c[:7].upper()]
        lv = node.get("Literal", {}).get("Value") if "Literal" in node else None
        if isinstance(lv, str) and lv.startswith("'#") and lv[1:8].upper() in cmap:
            node["Literal"]["Value"] = f"'{cmap[lv[1:8].upper()]}'"
        for v in node.values():
            recolor(v, cmap)
    elif isinstance(node, list):
        for v in node:
            recolor(v, cmap)


def swap_assets(text: str) -> str:
    for a, b in SWAPS.items():
        text = text.replace(a, b)
    return text


def ensure_resource(rep: Path, name: str):
    rr = rep / "StaticResources" / "RegisteredResources"
    rr.mkdir(parents=True, exist_ok=True)
    for folder in ("logo", "icons"):
        src = SKILL / "assets" / folder / name
        if src.exists() and not (rr / name).exists():
            shutil.copy(src, rr / name)
    rj = rep / "definition" / "report.json"
    report = load(rj)
    pkg = next((p for p in report.setdefault("resourcePackages", []) if p.get("type") == "RegisteredResources"), None)
    if pkg is None:
        pkg = {"name": "RegisteredResources", "type": "RegisteredResources", "items": []}
        report["resourcePackages"].append(pkg)
    if name not in {i["name"] for i in pkg["items"]}:
        pkg["items"].append({"name": name, "path": name, "type": "Image"})
    dump(rj, report)


def toggle_ids(visuals: dict) -> list[str]:
    out = []
    for vid, d in visuals.items():
        v = d.get("visual", {})
        if v.get("visualType") == "actionButton" and d["position"].get("x", 0) >= 1150 and d["position"].get("y", 0) >= 650:
            if "PageNavigation" in json.dumps(v.get("visualContainerObjects", {}).get("visualLink", [])):
                out.append(vid)
    return out


def is_header(d: dict) -> bool:
    """HD1 header visuals (Header Period card…) are owned by install_header.py, not by the KPI role."""
    return "'Header " in json.dumps(d.get("visual", {}).get("visualContainerObjects", {}).get("title", []))


def set_nav(d: dict, target: str):
    for e in d["visual"].setdefault("visualContainerObjects", {}).setdefault("visualLink", [{"properties": {}}]):
        e.setdefault("properties", {})["navigationSection"] = lit(target)
        e["properties"]["type"] = lit("PageNavigation")
        e["properties"]["show"] = lit(True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--page", required=True)
    ap.add_argument("--replace", action="store_true")
    a = ap.parse_args()
    rep = Path(a.report)
    defn = rep / "definition"
    meta_p = defn / "pages" / "pages.json"
    meta = load(meta_p)
    tokens = T.load()
    ver = tokens["meta"]["version"]
    profile = load(SKILL / "assets" / "themes" / f"light-overrides.{ver}.json")
    cmap = color_map(tokens)

    pages = {pid: load(defn / "pages" / pid / "page.json") for pid in meta["pageOrder"]}
    dark_id = next((pid for pid, p in pages.items() if p.get("displayName", "").strip() == a.page.strip()), None)
    if not dark_id:
        print(f"ERROR: page '{a.page}' not found")
        return 2
    light_name = f"{pages[dark_id]['displayName'].strip()} Light"
    old = [pid for pid, p in pages.items() if p.get("displayName", "").strip() == light_name]
    if old and not a.replace:
        print(f"'{light_name}' already exists. Use --replace.")
        return 1
    for pid in old:
        meta["pageOrder"].remove(pid)
        shutil.rmtree(defn / "pages" / pid, ignore_errors=True)

    light_id = secrets.token_hex(10)
    src = defn / "pages" / dark_id
    dst = defn / "pages" / light_id
    (dst / "visuals").mkdir(parents=True)
    dark_visuals = {vd.name: load(vd / "visual.json") for vd in (src / "visuals").iterdir() if (vd / "visual.json").exists()}
    idmap = {vid: secrets.token_hex(10) for vid in dark_visuals}

    # page.json
    pg = copy.deepcopy(pages[dark_id])
    pg["name"], pg["displayName"], pg["visibility"] = light_id, light_name, "HiddenInViewMode"
    for o in profile["overrides"]:
        if o["visualType"] == "page":
            set_prop(pg.setdefault("objects", {}), o["object"], o["property"], o["light"], o["selector"])
    for vi in pg.get("visualInteractions", []):
        vi["source"], vi["target"] = idmap.get(vi["source"], vi["source"]), idmap.get(vi["target"], vi["target"])
    dump(dst / "page.json", pg)

    toggles = toggle_ids(dark_visuals)
    for vid, d in dark_visuals.items():
        nd = json.loads(swap_assets(json.dumps(d, ensure_ascii=False)))
        nd["name"] = idmap[vid]
        if nd.get("parentGroupName") in idmap:
            nd["parentGroupName"] = idmap[nd["parentGroupName"]]
        v = nd.setdefault("visual", {}) if "visual" in nd else None
        if v is not None:
            recolor(v, cmap)
            vt = v.get("visualType", "")
            objs, cont = v.setdefault("objects", {}), v.setdefault("visualContainerObjects", {})
            for o in profile["overrides"]:
                if o["visualType"] == "page" or o["light"] is None:
                    continue
                if o["visualType"] == "*":
                    if o["object"] in CONTAINER:
                        set_prop(cont, o["object"], o["property"], o["light"], o["selector"])
                    elif o["object"] in ("categoryAxis", "valueAxis") and vt in CHARTS:
                        set_prop(objs, o["object"], o["property"], o["light"], o["selector"])
                elif o["visualType"] == vt:
                    target = cont if o["object"] in CONTAINER else objs
                    set_prop(target, o["object"], o["property"], o["light"], o["selector"])
            if vt == "cardVisual" and not is_header(nd):          # KPI tile role, never the header period card
                for k, val in profile["roles"]["kpi_tile_outline"]["modes"]["light"].items():
                    obj, prop = k.split(".")
                    set_prop(objs, obj, prop, val, "default")
            if vid in toggles:
                set_nav(nd, dark_id)
        if v is not None:
            import apply_table_role                          # TB2 · table roles re-resolved with Light tokens
            apply_table_role.reapply_from_annotations(nd, tokens, "light")
        (dst / "visuals" / idmap[vid]).mkdir()
        dump(dst / "visuals" / idmap[vid] / "visual.json", nd)

    for vid, d in dark_visuals.items():   # dark side: toggle → light page, KPI outline role (dark values)
        changed = False
        if vid in toggles:
            set_nav(d, light_id)
            changed = True
        if d.get("visual", {}).get("visualType") == "cardVisual" and not is_header(d):
            for k, val in profile["roles"]["kpi_tile_outline"]["modes"]["dark"].items():
                obj, prop = k.split(".")
                set_prop(d["visual"].setdefault("objects", {}), obj, prop, val, "default")
            changed = True
        if changed:
            dump(src / "visuals" / vid / "visual.json", d)
    for name in SWAPS.values():
        ensure_resource(rep, name)

    i = meta["pageOrder"].index(dark_id)
    meta["pageOrder"].insert(i + 1, light_id)
    dump(meta_p, meta)
    import install_header                                   # HD1 · header rebuilt with Light tokens (exact, no re-mapping)
    if any(install_header.visual_name(load(v)) in install_header.NAMES for v in (dst / "visuals").glob("*/visual.json")):
        install_header.install_on_page(rep, light_id)
    print(f"LIGHT TWIN · '{light_name}' ({light_id}) · {len(dark_visuals)} visuals · toggles linked: {len(toggles)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
