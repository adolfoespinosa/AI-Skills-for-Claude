# Icons (PNG, from the reference reports)

| File | Use |
|---|---|
| `moon.png` / `sun.png` | Mode toggle: moon on Dark pages, sun on Light twins (MODE-005) |
| `filter-white.png` / `filter-blue.png` / `filter-orange.png` | Filter indicators (white = Dark, blue = Light, orange = active/hover in Dark) |
| `home-orange.png` | Home button (Dark) |

Still missing (gap G2): back, info, reset as SVG. Until then, use the built-in shapes (back, information, reset).
