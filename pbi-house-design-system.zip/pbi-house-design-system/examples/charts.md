<!-- STATUS: v0.1 (Step 9) · LOADED: on demand -->
# Examples: Charts

## Good: EBITDA bridge (waterfall)
```yaml
- id: bridge
  kind: waterfallChart                                   # CHART-001
  geometry: { col: 13, span: 12, y: 380, h: 276 }
  sentimentColors: { increase: color.waterfall.increase, decrease: color.waterfall.decrease, total: color.waterfall.total }  # COLOR-011
  labels: { show: true, type: type.label }               # CHART-003/005
  valueAxis: { show: true, position: Right, gridline: { color: color.gridline, style: dotted } }
  categories: [EBITDA BUD, Revenue, Payroll, Other OPEX, Rent & Guar., IFRS 16, EBITDA ACT (total last)]
```

## Good: tracking line
ACT solid with markers (`scenario.actual`) · FCT dashed (`scenario.forecast`) · REF `scenario.reference` with area ·
data labels on, value axis off (CHART-004) · legend top-left.

## Bad
```yaml
- kind: pieChart                     # ✗ CHART-001 not approved
- kind: lineChart
  series: { BUD: orange solid, ACT: blue }   # ✗ COLOR-010 scenario encoding · ✗ COLOR-005 orange on data (Dark)
  valueAxis: { show: true } , labels: { show: false }   # ✗ CHART-004
```
