#!/usr/bin/env python3
"""
build_themes.py: generate Power BI theme artifacts from tokens/tokens.yaml (Step 8, D4).

Outputs (assets/themes/):
  corporate-dark.<ver>.json     Theme to REGISTER in reports (default mode Dark, D15)
  light-overrides.<ver>.json    Light override profile for "<page> Light" twins (MODE-003)
  corporate-light.<ver>.json    Reference Light theme (standalone Light reports / previews only;
                                NOT registered in twin-page reports, one theme per report)
  manifest.json                 Versions + SHA-256 of the generated files

Design notes
  * dataColors positions 0..7 and foreground/background are LOCKED (tokens › component.theme_compat):
    existing visuals reference them by ThemeDataColor ColorId. Reordering them is a MAJOR change.
  * report-cli base.json safeguards are kept: textbox zero padding / no background / no border,
    cardVisual zero padding + callout padding, tableEx growToFit, hidden visual headers.
  * Never edit the outputs by hand. Change tokens.yaml and rebuild.

Usage:
  python scripts/build_themes.py                       # build
  python scripts/build_themes.py --compare <theme.json> # build + diff the Dark theme against an existing theme
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _tokens as T  # noqa: E402

OUT_DIR = T.SKILL_ROOT / "assets" / "themes"
SCHEMA = "https://raw.githubusercontent.com/microsoft/powerbi-desktop-samples/main/Report%20Theme%20JSON%20Schema/reportThemeSchema-2.153.json"


class Ctx:
    def __init__(self, tokens: dict, mode: str):
        self.t, self.mode = tokens, mode

    def c(self, path: str) -> dict:
        """Resolved colour as a theme fill object."""
        return {"solid": {"color": T.resolve_path(self.t, T.expand_alias(path), self.mode)}}

    def hex(self, path: str) -> str:
        return T.resolve_path(self.t, T.expand_alias(path), self.mode)

    def font(self, role: str, key: str = "family") -> str:
        return T.font_stack(self.t, T.resolve(self.t, self.t["semantic"]["type"][role][key]))   # FS1

    def size(self, role: str) -> int:
        return self.t["semantic"]["type"][role]["size"]


def visual_styles(x: Ctx) -> dict:
    radius_c = x.t["semantic"]["radius"]["container"]
    radius_ctl = x.t["semantic"]["radius"]["control"]
    bw = x.t["semantic"]["border"]["width"]
    lbl, lbl_font = x.size("label"), x.font("label")
    axis = {"labelColor": x.c("color.text.primary"), "fontSize": lbl, "fontFamily": lbl_font,
            "showAxisTitle": False, "gridlineStyle": "dotted", "gridlineColor": x.c("color.gridline")}

    vs = {
        "*": {"*": {
            "background": [{"show": True, "color": x.c("color.surface.panel"), "transparency": 0}],
            "border": [{"show": True, "color": x.c("color.border.container"), "radius": radius_c, "width": bw}],
            "dropShadow": [{"show": False}],                                   # PAGE-002
            "visualHeader": [{"show": False}],                                 # PANEL-006
            "title": [{"show": True, "fontColor": x.c("color.text.on_panel_title"),
                       "background": x.c("color.surface.panel_title"),
                       "fontSize": x.size("panel_title"), "fontFamily": x.font("panel_title"),
                       "alignment": "center"}],                                # PANEL-002/007 (charts)
            "subTitle": [{"fontColor": x.c("color.text.panel_subtitle"),
                          "fontSize": x.size("subtitle"), "fontFamily": x.font("subtitle")}],
            "visualTooltip": [{"themedBackground": x.c("color.tooltip.background"),          # Q-T1 dark in both modes
                               "themedTitleFontColor": x.c("color.tooltip.text"),
                               "themedValueFontColor": x.c("color.tooltip.text"),
                               "actionFontColor": x.c("color.tooltip.text")}],
            "visualHeaderTooltip": [{"themedBackground": x.c("color.tooltip.background"),
                                     "themedTitleFontColor": x.c("color.tooltip.text")}],
            "outspacePane": [{"backgroundColor": x.c("color.surface.panel"),
                              "foregroundColor": x.c("color.text.primary"),
                              "checkboxAndApplyColor": x.c("color.text.tab_inactive")}],
            "filterCard": [{"$id": "Applied", "backgroundColor": x.c("color.surface.panel"),
                            "foregroundColor": x.c("color.text.primary"), "transparency": 0},
                           {"$id": "Available", "backgroundColor": x.c("color.surface.panel"),
                            "foregroundColor": x.c("color.text.primary"), "transparency": 0}],
            "categoryAxis": [dict(axis)],
            "valueAxis": [dict(axis)],
        }},
        "page": {"*": {
            "background": [{"color": x.c("color.surface.page"), "transparency": 0}],
            "outspace": [{"color": x.c("color.surface.outspace")}],
        }},
        "textbox": {"*": {                                                     # base.json safeguard
            "padding": [{"top": 0, "bottom": 0, "left": 0, "right": 0}],
            "background": [{"show": False}],
            "border": [{"show": False}],
            "title": [{"show": False}],
        }},
        "shape": {"*": {
            "title": [{"show": False}],
            "background": [{"show": False}],                                   # the shape fill is the surface
            "fill": [{"show": True, "fillColor": x.c("color.surface.panel"), "transparency": 0}],
            "outline": [{"show": True, "lineColor": x.c("color.border.container"), "weight": bw}],
        }},
        "image": {"*": {"title": [{"show": False}], "border": [{"show": False}], "background": [{"show": False}],
                        "visualHeader": [{"show": False}]}},
        "bookmarkNavigator": {"*": {"title": [{"show": False}], "background": [{"show": False}], "border": [{"show": False}]}},
        "cardVisual": {"*": {                                                  # KPI-001..006 + base.json safeguards
            "title": [{"show": False}],
            "padding": [{"top": 0, "bottom": 0, "left": 0, "right": 0}],
            "cardCalloutArea": [{"paddingUniform": 0}],
            "value": [{"$id": "default", "fontColor": x.c("color.text.primary"),
                       "fontSize": x.size("kpi_large"), "fontFamily": x.font("kpi_large")}],
            "label": [{"$id": "default", "show": True, "fontColor": x.c("color.text.primary"),
                       "fontSize": lbl, "fontFamily": lbl_font, "position": "aboveValue"}],
            "dropShadow": [{"show": False}],
            "shadowCustom": [{"show": False}],
            "glowCustom": [{"show": False}],
        }},
        "tableEx": {"*": table_styles(x, list_role=False) | {
            "columnHeaders": [header_styles(x) | {"autoSizeColumnWidth": True, "columnAdjustment": "growToFit"}],
        }},
        "pivotTable": {"*": table_styles(x, list_role=False) | {
            "columnHeaders": [header_styles(x)],
            "rowHeaders": [{"fontColor": x.c("color.text.primary"), "backColor": x.c("color.surface.table"),
                            "fontSize": x.size("table_cell"), "fontFamily": x.font("table_cell"),
                            "stepped": False, "showExpandCollapseButtons": False}],
        }},
        "slicer": {"*": {                                                      # SLICER-001/006
            "title": [{"show": False}],
            "background": [{"show": False}],
            "border": [{"show": False}],
            "header": [{"show": True, "fontColor": x.c("color.text.primary"),
                        "textSize": x.size("slicer_header"), "fontFamily": x.font("slicer_header"), "outline": "None"}],
            "items": [{"fontColor": x.c("color.control.dropdown_text"),
                       "background": x.c("color.control.dropdown_fill"),
                       "textSize": lbl, "fontFamily": lbl_font, "outline": "None"}],
            # dropdown.borderRadius is NOT honoured from the theme (Desktop test 2026-10-06): see component.visual_level
            "general": [{"outlineColor": x.c("color.border.container"), "outlineWeight": bw,
                         "keepLayerOrder": True}],                             # BS3 · corpus theme: no jump to front on click
        }},
        "advancedSlicerVisual": {"*": {                                        # SLICER-002/003, COLOR-007
            "title": [{"show": False}],
            "background": [{"show": False}],
            "border": [{"show": False}],
            "fillCustom": [
                {"$id": "default", "show": True, "fillColor": x.c("color.selection.unselected_fill")},
                {"$id": "interaction:rest", "fillColor": x.c("color.selection.unselected_fill")},
                {"$id": "selection:selected", "fillColor": x.c("color.selection.fill")},
                {"$id": "interaction:hover", "fillColor": button_hover(x)},
                {"$id": "interaction:press", "fillColor": x.c("color.press.control")},
            ],
            "value": [
                {"$id": "default", "fontColor": x.c("color.selection.unselected_text"),
                 "fontSize": x.size("label"), "fontFamily": x.font("control")},          # BS1 · corpus buttons 8 pt
                {"$id": "interaction:rest", "fontColor": x.c("color.selection.unselected_text")},
                {"$id": "selection:selected", "fontColor": x.c("color.selection.text"),
                 "fontFamily": x.font("control", "selected_family")},
            ],
            "outline": [{"$id": "default", "show": True, "lineColor": x.c("color.border.container"), "weight": bw}],
            "shapeCustomRectangle": [{"$id": "default", "tileShape": "rectangleRoundedByPixel",
                                      "rectangleRoundedCurve": radius_ctl}],   # BS4 · also written on each visual (SLICER-009)
        }},
        "listSlicer": {"*": {
            "title": [{"show": True, "fontColor": x.c("color.text.on_panel_title"),
                       "background": x.c("color.surface.panel_title"),
                       "fontSize": x.size("panel_title"), "fontFamily": x.font("panel_title"), "alignment": "left"}],
            "value": [{"$id": "default", "fontColor": x.c("color.text.primary"), "fontSize": lbl, "fontFamily": lbl_font}],
            "selectionIcon": [{"$id": "selection:selected", "color": x.c("color.selection.fill")}],
        }},
        "actionButton": {"*": {                                                # NAV-004
            "title": [{"show": False}],
            "background": [{"show": False}],
            "border": [{"show": False}],
            "visualHeader": [{"show": False}],
            "fill": [{"show": True},
                     {"$id": "default", "fillColor": x.c("color.surface.page"), "transparency": 100},
                     {"$id": "hover", "fillColor": x.c("color.hover.fill"), "transparency": 0},
                     {"$id": "selected", "fillColor": x.c("color.selection.fill"), "transparency": 0},
                     {"$id": "disabled", "fillColor": x.c("color.surface.page"), "transparency": 100}],
            "icon": [{"show": True},
                     {"$id": "default", "lineColor": x.c("color.accent.primary")},   # Dark: orange icons (COLOR-004)
                     {"$id": "hover", "lineColor": x.c("color.text.primary")},
                     {"$id": "selected", "lineColor": x.c("color.selection.text")},
                     {"$id": "disabled", "lineColor": x.c("color.text.tab_inactive")}],
            "text": [{"show": True},                                          # renders only if text is set
                     {"$id": "default", "fontColor": x.c("color.text.primary"),
                      "fontSize": x.size("control"), "fontFamily": x.font("control")}],
            "outline": [{"show": False}],
        }},
        "pageNavigator": {"*": {                                              # NAV-007: never a title bar
            "title": [{"show": False}],
            "background": [{"show": False}],
            "border": [{"show": False}],
            "visualHeader": [{"show": False}],
            "fill": [{"$id": "default", "fillColor": x.c("color.selection.unselected_fill")},
                     {"$id": "selected", "fillColor": x.c("color.selection.fill")},
                     {"$id": "hover", "fillColor": x.c("color.hover.fill")}],
            "text": [{"$id": "default", "fontColor": x.c("color.selection.unselected_text"),
                      "fontSize": x.size("panel_title"), "fontFamily": x.font("control")},
                     {"$id": "selected", "fontColor": x.c("color.selection.text")}],
        }},
    }
    labels = {"show": True, "color": x.c("color.text.primary"), "fontSize": lbl, "fontFamily": lbl_font}
    legend = {"show": True, "position": "TopLeft", "labelColor": x.c("color.text.primary"),
              "fontSize": lbl, "fontFamily": lbl_font}
    for line in ("lineChart", "areaChart"):                                     # CHART-002/004
        vs[line] = {"*": {
            "labels": [dict(labels)],
            "legend": [dict(legend)],
            "valueAxis": [dict(axis) | {"show": False, "gridlineShow": False}],
            "categoryAxis": [dict(axis) | {"show": True, "gridlineShow": False}],
        }}
    vs["waterfallChart"] = {"*": {                                              # CHART-003, COLOR-011
        "sentimentColors": [{"increaseFill": x.c("color.waterfall.increase"),
                             "decreaseFill": x.c("color.waterfall.decrease"),
                             "totalFill": x.c("color.waterfall.total")}],
        "labels": [dict(labels) | {"backgroundColor": x.c("color.surface.data_label")}],
        "legend": [{"show": False}],
        "valueAxis": [dict(axis) | {"show": True, "position": "Right", "gridlineShow": True}],
        "categoryAxis": [dict(axis) | {"show": True, "gridlineShow": False}],
    }}
    for bar in ("clusteredBarChart", "clusteredColumnChart", "columnChart"):   # CHART-005/007
        vs[bar] = {"*": {
            "labels": [dict(labels)],
            "legend": [{"show": False}],
            "dataPoint": [{"defaultColor": x.c("color.scenario.actual")}],
            "valueAxis": [dict(axis) | {"show": True, "gridlineShow": True}],
            "categoryAxis": [dict(axis) | {"show": True, "gridlineShow": False}],
        }}
    # Tables use left-aligned titles (PANEL-007)
    for tbl in ("tableEx", "pivotTable"):
        vs[tbl]["*"]["title"] = [dict(vs["*"]["*"]["title"][0]) | {"alignment": "left"}]
    return vs


def header_styles(x: Ctx) -> dict:                                              # TABLE-001
    return {"fontColor": x.c("color.text.on_panel_title"), "backColor": x.c("color.surface.panel_title"),
            "fontSize": x.size("table_header"), "fontFamily": x.font("table_header"), "outline": "None"}


def table_styles(x: Ctx, list_role: bool) -> dict:                              # TABLE-002/003/008
    role = "table_cell_list" if list_role else "table_cell"
    pad = x.t["component"]["table"]["list" if list_role else "financial_matrix"]["row_padding"]
    return {
        "grid": [{"gridVertical": False, "gridHorizontal": False, "rowPadding": pad,
                  "outlineColor": x.c("color.surface.table"), "textSize": x.size(role)}],
        "values": [{"fontColorPrimary": x.c("color.text.primary"), "backColorPrimary": x.c("color.surface.table"),
                    "fontColorSecondary": x.c("color.text.primary"), "backColorSecondary": x.c("color.surface.table"),
                    "fontSize": x.size(role), "fontFamily": x.font(role), "bandedRowHeaders": False}],
        "total": [{"fontColor": x.c("color.text.primary"), "backColor": x.c("color.surface.table"),
                   "fontFamily": x.font(role, "total_family") if "total_family" in x.t["semantic"]["type"][role] else x.font(role)}],
        "background": [{"show": True, "color": x.c("color.surface.table"), "transparency": 0}],
    }


def button_hover(x: Ctx) -> dict:
    return {"solid": {"color": T.resolve(x.t, x.t["component"]["button_slicer"]["hover"]["fill"], x.mode)}}


def text_classes(x: Ctx) -> dict:
    return {
        "label":   {"fontSize": x.size("label"), "fontFace": x.font("label"), "color": x.hex("color.text.primary")},
        "callout": {"fontSize": x.size("kpi_hero"), "fontFace": x.font("kpi_hero"), "color": x.hex("color.text.primary")},
        "title":   {"fontSize": x.size("panel_title"), "fontFace": x.font("panel_title"), "color": x.hex("color.text.on_panel_title")},
        "header":  {"fontSize": x.size("control"), "fontFace": x.font("kpi_small"), "color": x.hex("color.text.primary")},
    }


def build_theme(tokens: dict, mode: str) -> dict:
    x = Ctx(tokens, mode)
    compat = tokens["component"]["theme_compat"]
    slots = [T.resolve(tokens, r) for r in compat["data_slots"]]
    categorical = [x.hex(f"color.data.categorical_{i}") for i in range(1, 5)]
    data_colors = slots + [c for c in categorical if c not in slots]
    if mode == "dark":
        fg, bg = T.resolve(tokens, compat["foreground"]), T.resolve(tokens, compat["background"])
    else:  # reference Light theme only
        fg, bg = x.hex("color.text.primary"), x.hex("color.surface.page")
    sent = tokens["component"]["theme_sentiment"]
    v = tokens["meta"]["version"]
    return {
        "$schema": SCHEMA,
        "name": f"RHG House {mode.capitalize()} {v}",
        "dataColors": data_colors,
        "foreground": fg,
        "background": bg,
        "foregroundNeutralSecondary": x.hex("color.text.tab_inactive"),
        "backgroundNeutral": T.resolve(tokens, "{primitive.color.slate_500}"),
        "tableAccent": x.hex("color.surface.panel_title"),
        "good": T.resolve(tokens, sent["good"], mode),
        "bad": T.resolve(tokens, sent["bad"], mode),
        "neutral": T.resolve(tokens, sent["neutral"], mode),
        "maximum": x.hex("color.scenario.actual"),
        "center": x.hex("color.scenario.reference"),
        "minimum": x.hex("color.surface.panel"),
        "textClasses": text_classes(x),
        "visualStyles": visual_styles(x),
    }


def flatten_styles(vs: dict):
    """(visualType, object, $id, property) -> scalar value (colours as hex)."""
    out = {}
    for vtype, wild in vs.items():
        for obj, entries in wild["*"].items():
            for e in entries:
                sel = e.get("$id", "")
                for prop, val in e.items():
                    if prop == "$id":
                        continue
                    if isinstance(val, dict) and "solid" in val:
                        val = val["solid"]["color"]
                    out[(vtype, obj, sel, prop)] = val
    return out


def role_styles(tokens: dict) -> dict:
    """Per-role explicit overrides that a theme cannot express (same visualType, different role).
    Applied in BOTH modes to the identified visuals."""
    roles = {}
    for mode in T.MODES:
        x = Ctx(tokens, mode)
        roles.setdefault("text_tabs", {"visualType": "advancedSlicerVisual",
                                       "identify": "advancedSlicerVisual in a panel subtitle row (height <= 30, inside band.content) · SLICER-004",
                                       "modes": {}})
        roles["text_tabs"]["modes"][mode] = {
            "background.show": False, "border.show": False,
            "fillCustom[default].show": False,
            "fillCustom[selection:selected].show": False,
            "outline[default].show": False,
            "value[default].fontColor": x.hex("color.text.tab_inactive"),
            "value[selection:selected].fontColor": x.hex("color.text.tab_active"),
            "value[interaction:hover].fontColor": x.hex("color.text.tab_active"),
            "value[default].fontSize": x.size("control"),
            "value[selection:selected].fontFamily": x.font("control", "selected_family"),
        }
        roles.setdefault("kpi_tile_outline", {"visualType": "cardVisual",
                                              "identify": "cardVisual variant tile (KPI-002/006)", "modes": {}})
        roles["kpi_tile_outline"]["modes"][mode] = {
            "outline.show": True,
            "outline.lineColor": T.resolve(tokens, tokens["component"]["kpi_card"]["outline"][mode]),
        }
    return roles


def light_profile(tokens: dict, dark: dict, light: dict) -> dict:
    slots = [T.resolve(tokens, r).upper() for r in tokens["component"]["theme_compat"]["data_slots"]]
    fd, fl = flatten_styles(dark["visualStyles"]), flatten_styles(light["visualStyles"])
    overrides = []
    for key in sorted(set(fd) | set(fl)):
        if fd.get(key) != fl.get(key):
            vtype, obj, sel, prop = key
            entry = {"visualType": vtype, "object": obj, "selector": sel or None, "property": prop,
                     "dark": fd.get(key), "light": fl.get(key)}
            if isinstance(fl.get(key), str) and fl[key].upper() in slots:
                entry["light_theme_color"] = {"ColorId": 2 + slots.index(fl[key].upper()), "Percent": 0}
            overrides.append(entry)
    return {
        "name": f"RHG House Light override profile {tokens['meta']['version']}",
        "applies_to": "pages named '<Dark page> Light' (MODE-003)",
        "how_to_apply": ("For every visual on the Light twin, set each listed property for its visualType "
                         "('*' = all visuals) to `light`. Prefer `light_theme_color` (ThemeDataColor) when present. "
                         "Page-level entries (visualType 'page') go to page.json objects."),
        "count": len(overrides),
        "overrides": overrides,
        "roles": role_styles(tokens),
    }


def compare(generated: dict, existing_path: str) -> None:
    ex = json.loads(Path(existing_path).read_text(encoding="utf-8"))
    print(f"\nCOMPARE generated Dark vs {Path(existing_path).name}")
    for k in ("foreground", "background", "good", "bad", "neutral"):
        mark = "=" if str(ex.get(k, "")).upper() == str(generated.get(k, "")).upper() else "≠"
        print(f"  {mark} {k:12} existing {ex.get(k)!s:9} → generated {generated.get(k)}")
    slots_same = [a.upper() for a in ex.get("dataColors", [])[:8]] == [b.upper() for b in generated["dataColors"][:8]]
    print(f"  {'=' if slots_same else '≠'} dataColors[0..7] (locked slots) {'preserved' if slots_same else 'CHANGED'}")
    for cls in ("label", "callout", "title", "header"):
        e, g = ex.get("textClasses", {}).get(cls, {}), generated["textClasses"][cls]
        print(f"  {'=' if str(e.get('color','')).upper()==g['color'].upper() and e.get('fontSize')==g['fontSize'] else '≠'} "
              f"textClasses.{cls:8} existing {e.get('fontSize')}pt {e.get('color')} → generated {g['fontSize']}pt {g['color']}")
    fe, fg = flatten_styles(ex.get("visualStyles", {})), flatten_styles(generated["visualStyles"])
    common = set(fe) & set(fg)
    same = sum(1 for k in common if str(fe[k]).upper() == str(fg[k]).upper())
    print(f"  visualStyles: existing {len(fe)} props · generated {len(fg)} · common {len(common)} · identical {same}")
    changed = [k for k in common if str(fe[k]).upper() != str(fg[k]).upper()]
    for k in sorted(changed)[:25]:
        print(f"    ≠ {'/'.join(x for x in k if x)}: {fe[k]} → {fg[k]}")
    if len(changed) > 25:
        print(f"    … {len(changed) - 25} more")
    fonts = {v for k, v in fe.items() if k[3] in ("fontFamily",) and isinstance(v, str)}
    print(f"  fonts in existing theme: {sorted(fonts)}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(OUT_DIR))
    ap.add_argument("--compare", help="existing theme JSON to diff against the generated Dark theme")
    a = ap.parse_args()

    tokens = T.load()
    v = tokens["meta"]["version"]
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    dark, light = build_theme(tokens, "dark"), build_theme(tokens, "light")
    profile = light_profile(tokens, dark, light)
    files = {f"corporate-dark.{v}.json": dark, f"corporate-light.{v}.json": light, f"light-overrides.{v}.json": profile}
    manifest = {"design_system_version": v, "files": {}}
    for name, data in files.items():
        text = json.dumps(data, indent=2, ensure_ascii=False)
        (out / name).write_text(text + "\n", encoding="utf-8")
        manifest["files"][name] = hashlib.sha256(text.encode()).hexdigest()
    manifest["register_in_reports"] = f"corporate-dark.{v}.json"
    manifest["note"] = "Generated by scripts/build_themes.py. Do not edit by hand."
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    fd = flatten_styles(dark["visualStyles"])
    print(f"BUILD THEMES · v{v}")
    print(f"  corporate-dark.{v}.json   {len(fd)} style properties · {len(dark['visualStyles'])} visual types")
    print(f"  corporate-light.{v}.json  (reference only)")
    print(f"  light-overrides.{v}.json  {profile['count']} overrides")
    if a.compare:
        compare(dark, a.compare)
    return 0


if __name__ == "__main__":
    sys.exit(main())
