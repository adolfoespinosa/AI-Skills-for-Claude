<!--
STATUS: v0.1 (Step 6, batch 3)
PURPOSE: From a business request to page templates and slots, without asking the user where each element goes.
LOADED: creating a new dashboard or page.
-->
# Dashboard Catalogue and Composition

## 1. Composition pipeline

```text
Request ─► classify each page (section 2) ─► pick template (page-templates.yaml)
        ─► classify measures (section 3) ─► assign slots ─► component rules ─► house-constraints + Design Brief
```

Ask the user only when the page type or a measure's role cannot be inferred from the request **and** the
semantic model. Otherwise decide, and record the assumption in the brief (`variant_rationale`).

## 2. Page types

| Page type | Signals | Template | report-cli archetype |
|---|---|---|---|
| **Intro** (always, first page) | Every new report | `T-INTRO` (locked template, `install_intro.py`) | — |
| **Executive summary** | headline KPIs, "summary", "overview", ≤ 10 s scan | `T-SUMMARY` | Executive Summary |
| **Financial statement** | P&L, statement, line items, EBITDA bridge | `T-STATEMENT` | Analytical Canvas |
| **Detail list** | per hotel / entity, ranking, "list", many rows | `T-LIST` | Comparative Benchmark |
| **Benchmark** | compare entities or areas, peer, "vs" across units | `T-BENCHMARK` | Comparative Benchmark |
| **Utility** | data check, definitions, KPI calculation | `T-UTILITY` (free layout in band.content, chrome still required) | — |
| **Tooltip** | hover detail | `T-TOOLTIP-S` / `T-TOOLTIP-M` | — |

Every visible page (except tooltips) also gets its **Light twin** (MODE-002).

## 3. Measure roles

| Role | How to recognise | Becomes |
|---|---|---|
| Amount KPI | Currency amount (Revenue, EBITDA, Net Income) | KPI tile value, matrix row, chart series |
| Ratio KPI | %, margin, "% of revenue" | KPI secondary line or matrix ratio row (`↪`) — **not a separate chart** |
| Scenario | ACT / BUD / TGT / LY / FCT / REF suffix | Series encoding (COLOR-010) or matrix column |
| **Time lens** | YTD, Mth, LTM, Rolling 13M | **Not a visual.** A matrix column block, or text tabs on a chart (Calendar year / Rolling LTM) |
| View dimension | ABS/DEV/DEV%, K/M, currency, comparison | Button-slicer group in band.bottom |
| Global filter | Year, Period, Area | Dropdown in band.bottom |
| Entity | Hotel, area, brand | Rows (list) or list rail |

## 4. Worked example

> "Create a P&L dashboard with Revenue, EBITDA, EBITDA %, YTD and LTM."

| Step | Decision |
|---|---|
| Page type | Financial statement → `T-STATEMENT` (+ Light twin) |
| Revenue, EBITDA | Amount KPIs → P&L matrix rows (layout-driven) + EBITDA tracking line + EBITDA waterfall |
| EBITDA % | Ratio → `↪ %Rev EBITDA` row under EBITDA. No own chart |
| YTD | Time lens → second column block (Mth \| YTD) in the matrix |
| LTM | Time lens → text tabs "Calendar year / Rolling LTM" on the tracking chart |
| Scenarios | ACT solid, FCT dashed, REF light blue; text tabs BUD / LY / TGT choose REF |
| Bottom band | Year, Period dropdowns · vs LY/vs TGT · ABS/DEV/DEV% · K/M · EUR/FXN/LC · icons · mode toggle |
| Model requests | EBITDA % format `#,#0.0%`; LTM measures if missing; dynamic title "(in EUR thousands)" |

Result: no question to the user. The assumptions go into `variant_rationale`.
