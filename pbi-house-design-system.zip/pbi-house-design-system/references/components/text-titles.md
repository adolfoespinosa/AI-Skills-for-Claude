<!--
STATUS: v0.1 (Step 6, batch 2)
PURPOSE: Wording and placement of titles, subtitles, units and notes (TEXT-*).
LOADED: any title or explanatory text.
-->
# Text and Titles

## 1. Conventions (from the corpus)

| Text | Pattern | Example |
|---|---|---|
| Page title | Short page name | "Summary" |
| Period (next to the title) | `Mmm-YYYY` | "Jun-2026" |
| Panel title, table | `<Subject> (in <CUR> <unit>)` | "P&L RHG (in EUR thousands)" |
| Panel title, chart | `<Subject> · <year> - <Scenario> vs <Scenario> (Ref)` | "Monthly tracking · 2026 - Actual vs Budget (Ref)" |
| Subtitle row | Period context or tabs | "Mth - Jun 2026 · YTD" |
| Scenario names in headers | ACT · BUD · TGT · LY · FCT · REF | "ACT · vs TGT · vs BUD" |
| Variance column headers | `vs <SCN>` | "vs BUD" |

Titles are **descriptive** (they say what is shown), not insight statements. This differs from the
`powerbi-report-cli` default and house rules win.

## 2. Rules

```yaml
- id: TEXT-001
  title: Units in the title
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [tableEx, pivotTable, "*Chart"]
  statement: "When values are scaled or in a currency, the panel title MUST state currency and unit, e.g. '(in EUR thousands)'. If units are user-selectable, the title MUST be dynamic (measure-driven)."
  check: assisted
  exceptions: allowed

- id: TEXT-002
  title: Descriptive titles
  status: active
  since: 0.1.0
  severity: warning
  priority: P6
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Panel and page titles MUST be descriptive (subject + scope). Insight headlines are not used."
  check: manual
  exceptions: allowed

- id: TEXT-003
  title: Scenario vocabulary
  status: active
  since: 0.1.0
  severity: warning
  priority: P3
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Scenario labels MUST use the house vocabulary: ACT, BUD, TGT, LY, FCT, REF; comparisons as 'vs <SCN>'; long form 'Actual vs Budget (Ref)'."
  check: assisted
  exceptions: allowed

- id: TEXT-004
  title: No raw field names
  status: active
  since: 0.1.0
  severity: critical
  priority: P4
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Axis titles, column headers and legends MUST NOT show raw field or aggregation names (e.g. 'Sum of Amount'). Use display names."
  check: auto
  exceptions: allowed

- id: TEXT-005
  title: Period formats
  status: active
  since: 0.1.0
  severity: warning
  priority: P3
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Periods MUST be written Mmm-YYYY in titles and Mmm-YY on axes."
  check: assisted
  exceptions: allowed
```

## 3. Decision TX1 (2026-10-04)

```yaml
- id: TEXT-006
  title: Capitalisation
  status: active
  since: 0.1.0
  severity: warning
  priority: P5
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Panel titles MUST use sentence case ('Monthly tracking'); page names MUST use Title Case ('Profit & Loss'). Scenario codes (ACT, BUD…) and acronyms stay upper case."
  check: assisted
  exceptions: allowed
```
