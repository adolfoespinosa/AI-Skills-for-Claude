<!--
STATUS: v0.1 (Step 6, batch 2)
PURPOSE: Tooltip pages (TIP-*).
LOADED: designing tooltips.
-->
# Tooltips

## 1. Standard

| Property | Standard |
|---|---|
| Type | Report-page tooltip (`type: Tooltip`, hidden), or the default tooltip themed by the theme |
| Sizes | `layout.tooltip.small` = 176 × 48 (inline value) · `layout.tooltip.medium` = 320 × 320 (mini chart) |
| Surface | `tooltip.background` · text `tooltip.text`: **dark in both modes** (Q-T1). Tooltip pages are shared by both twins, so they have one style only |
| Text | Title `type.panel_title` · values `type.label` / `type.kpi_small` |
| Content | One question: the hovered data point's detail (breakdown, comparison or definition) |
| Display option | `ActualSize` |

## 2. Rules

```yaml
- id: TIP-001
  title: Approved tooltip sizes
  status: active
  since: 0.1.0
  severity: warning
  priority: P5
  modes: [dark, light]
  applies_to: [page]
  statement: "Tooltip pages MUST use layout.tooltip.small or layout.tooltip.medium."
  check: auto
  exceptions: allowed

- id: TIP-002
  title: Default tooltip themed
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: [theme]
  statement: "The default tooltip and tooltip pages MUST use tooltip.background and tooltip.text in both modes (dark tooltips, Q-T1)."
  check: auto
  exceptions: allowed

- id: TIP-003
  title: Tooltip page contents
  status: active
  since: 0.1.0
  severity: info
  priority: P4
  modes: [dark, light]
  applies_to: [page]
  statement: "A tooltip page SHOULD contain at most 3 visuals and no slicers or buttons."
  check: auto
  exceptions: allowed
```

## 3. Decision TP1 (2026-10-04)
small = 176 × 48 · medium = 320 × 320. Existing tooltip pages at 175×40 and 210×80 go to the baseline.
