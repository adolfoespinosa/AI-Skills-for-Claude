# Corporate logos (company assets)

Source: registered resources of the reference reports (Operational Report - Fabric, RHG Consolidated Results).
PNG/JPG as used today. Official SVGs are still pending (gap G1); replace them here when available and keep the names.

| File | Size | Use | Original resource name |
|---|---|---|---|
| `logo-white.png` | 2500x600 | Full logo for **Dark** pages (header, PAGE-003) | RHG_LOGO_WHITE… |
| `logo-blue.png` | 2500x600 | Full logo for **Light** pages (header, PAGE-003) | RHG_LOGO_BLUE… |
| `logo-black.jpg` | 2500x600 | Print / documents on white (not for report pages) | RHG_LOGO_BLACK… |
| `icon-white.png` | 1100x1100 | Isotype on dark backgrounds (Intro page) | RHG_ICON_WHITE… |
| `icon-ww.png` | 1100x1100 | Isotype, alternative variant | RHG_ICON_WW… |

Rules: PAGE-003 (logo variant by background), ASSET-001 (assets come from this folder; no duplicated copies).
When registering in a report, keep the file name; report-cli authoring registers it in `report.json › resourcePackages`.
