#!/usr/bin/env python3
"""
check_twins.py: MODE-001 twin parity between "<page>" (Dark) and "<page> Light".

Visual IDs differ between twins, so visuals are matched by type + rounded absolute position + size.
Allowed differences: colour properties, the mode-toggle icon/target, the logo image.
Reported differences:
  UNMATCHED       a visual exists on one twin only
  GEOMETRY        same type but different position/size (> 1 px)
  BINDING         different query / projections (fields, measures, sort)
  FILTER          different visual filters
  FORMAT          non-colour formatting differs (fonts, sizes, borders, padding…)

Usage: python scripts/check_twins.py --report "<path>/<name>.Report" [--json]
Exit code: 0 = all twins identical (except allowed), 1 = differences found.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _pbir import Report  # noqa: E402

COLOR_WORDS = ("color", "colour", "fill", "background", "foreground", "linecolor", "fontcolor", "backcolor")


def is_colour_prop(prop: str, value) -> bool:
    p = prop.lower()
    return any(w in p for w in COLOR_WORDS) or (isinstance(value, str) and value.startswith("#"))


def key(v):
    return (v.vtype, round(v.x / 4), round(v.y / 4), round(v.w / 4), round(v.h / 4))


def loose_key(v):
    return (v.vtype, round(v.x / 16), round(v.y / 16))


def canon(obj) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False)


def canon_binding(obj) -> str:
    """Mode-specific measures '<X> Light' are allowed to replace '<X>' on the Light twin (modes.md §2)."""
    return canon(obj).replace(' Light"', '"')


def compare(dark, light):
    diffs = []
    dl = {key(v): v for v in dark.visuals}
    ll = {key(v): v for v in light.visuals}
    unmatched_d = [v for k, v in dl.items() if k not in ll]
    unmatched_l = [v for k, v in ll.items() if k not in dl]
    # second pass: same type close position → GEOMETRY
    for v in list(unmatched_d):
        cand = next((w for w in unmatched_l if loose_key(w) == loose_key(v)), None)
        if cand:
            diffs.append(("GEOMETRY", v.vtype, v.id, f"dark {v.x:.0f},{v.y:.0f} {v.w:.0f}x{v.h:.0f} · light {cand.x:.0f},{cand.y:.0f} {cand.w:.0f}x{cand.h:.0f}"))
            unmatched_d.remove(v)
            unmatched_l.remove(cand)
            dl[key(v)] = v
            ll[key(v)] = cand
    for v in unmatched_d:
        diffs.append(("UNMATCHED", v.vtype, v.id, "only on Dark"))
    for v in unmatched_l:
        diffs.append(("UNMATCHED", v.vtype, v.id, "only on Light"))
    for k, d in dl.items():
        l = ll.get(k)
        if not l or d.vtype in ("group",):
            continue
        dv, lv = d.raw.get("visual", {}), l.raw.get("visual", {})
        if canon_binding(dv.get("query")) != canon_binding(lv.get("query")):
            diffs.append(("BINDING", d.vtype, d.id, "query/projections differ"))
        if canon_binding(d.raw.get("filterConfig")) != canon_binding(l.raw.get("filterConfig")):
            diffs.append(("FILTER", d.vtype, d.id, "visual filters differ"))
        if d.vtype == "image" or (d.vtype == "actionButton" and d.y >= 650 and d.x >= 1150):
            continue  # logo variant / mode toggle: allowed to differ
        fd = {(o, p, s): val for g, o, p, s, val in d.props if not is_colour_prop(p, val) and o != "visualLink"}
        fl = {(o, p, s): val for g, o, p, s, val in l.props if not is_colour_prop(p, val) and o != "visualLink"}
        nocolor = lambda x: re.sub(r"#[0-9A-Fa-f]{6}", "#COLOR", json.dumps(x, sort_keys=True, default=str))  # noqa: E731
        for kk in sorted(set(fd) | set(fl)):
            if nocolor(fd.get(kk)) != nocolor(fl.get(kk)):
                o, p, s = kk
                diffs.append(("FORMAT", d.vtype, d.id, f"{o}.{p}{'['+s+']' if s else ''}: dark={fd.get(kk)} light={fl.get(kk)}"))
    return diffs


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    rep = Report(a.report)
    norm = lambda s: " ".join(s.split())                       # tolerate double spaces in legacy names
    by_name = {norm(p.name): p for p in rep.pages}
    results = []
    for p in rep.pages:
        if p.mode == "light":
            dark = by_name.get(norm(p.name.removesuffix(" Light")))
            if not dark:
                results.append({"dark": None, "light": p.name, "diffs": [("UNMATCHED", "page", "", "Dark page not found")]})
                continue
            diffs = compare(dark, p)
            if f"{dark.name} Light" != p.name:
                diffs.insert(0, ("NAMING", "page", "", f"twin name should be exactly '{dark.name} Light' (MODE-004)"))
            results.append({"dark": dark.name, "light": p.name, "diffs": diffs})
    total = sum(len(r["diffs"]) for r in results)
    if a.json:
        print(json.dumps({"status": "FAILED" if total else "PASSED", "pairs": results}, indent=2, ensure_ascii=False))
    else:
        print(f"TWIN CHECK (MODE-001) · {len(results)} pair(s) · {'FAILED' if total else 'PASSED'}")
        for r in results:
            print(f"  {r['dark']}  ⇄  {r['light']}: {len(r['diffs'])} difference(s)")
            for kind, vt, vid, msg in r["diffs"][:40]:
                print(f"    {kind:9} {vt:22} {vid[:10]:10} {msg}")
            if len(r["diffs"]) > 40:
                print(f"    … {len(r['diffs']) - 40} more")
        if not results:
            print("  no '<page> Light' twins found")
    return 1 if total else 0


if __name__ == "__main__":
    sys.exit(main())
