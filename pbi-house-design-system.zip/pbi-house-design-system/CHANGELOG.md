# Changelog

SemVer for the design system (D11).

## [0.10.0] - 2026-10-08 · design system 0.9.0
- TB2 table role `financial-matrix` (template `assets/templates/table-roles`, `scripts/apply_table_role.py`): title / subtitle /
  divider / spacing / right-aligned Semibold headers / custom widths 150-10-55 / dummy "." column / row padding 2
- Roles stored as visual annotations (`house.role`); make_light_twin re-applies them with Light tokens
- Tokens: type.table_title, component.table.financial_matrix (row_padding 1 → 2, sizes, widths, spacing)
- Testbed P&L table uses the role (+ `Dummy Column` measure)

## [0.9.2] - 2026-10-07
- HD4: header period card multi-card layout without background and uniform padding 0 (Dark and Light), Desktop structure

## [0.9.1] - 2026-10-07 · design system 0.8.0
- HD3: header logo Image fit = Fit; Selected Period card part of the header (optional `--period`): no border /
  background / divider / label, value Segoe UI Semibold 15 centred; title centred on the frame and lower (512·16·244×60)
- Fix: make_light_twin applied the KPI-tile outline to the header period card
- Tests 68/68

## [0.9.0] - 2026-10-07 · design system 0.7.0
- HD1 corporate page header (all pages except Intro): template `assets/templates/page-header`, `scripts/install_header.py`
  (per-mode colours, idempotent, keeps title/caption), make_light_twin rebuilds it on twins, testbed uses it
- Tokens: component.header (frame/logo/title/badge), type.badge_title, shadow.header #425463, band.header 10–76
- New rule PAGE-011 (auto) · PAGE-001 geometry updated · 34 automated rules · tests 66/66
- HD2 open interpretations listed in the decision log

## [0.8.0] - 2026-10-07 · design system 0.6.0
- BS2: Light press colour on button slicers = grey (`press.control` Light → grey_400)
- BS4: button corners mandatory 4 px (`radius.control` 4); written on every button slicer with Desktop's structure
  (tileShape rectangleRoundedByPixel + rectangleRoundedCurve) · new rule SLICER-009 (auto) · 33 automated rules
- `component.visual_level` supports selectors / fixed values; `apply_visual_level()` used by bind_blueprint;
  normalize_visual drops visual-level styles (the binder writes them)

## [0.7.0] - 2026-10-07 · design system 0.5.0
- FS1 (Desktop test): bare font names render wrongly → every font is written as the Power BI font stack
  (`tokens › primitive.font_stack`): theme (all titles incl. matrices, slicers, textClasses), blueprints, bind_blueprint
  safety net, normalize_visual, make_light_twin (quote escaping)
- New rule TYPO-006 (auto, critical) on visuals and themes · 32 automated rules · tests 60/60

## [0.6.0] - 2026-10-07 · design system 0.4.0
- Slicer blueprints from RHG Consolidated Results › P&L RHG: `slicer/year-dropdown`, `slicer/button-group`
  (presets ly-tgt, deltaview, figures, currency, dataview); period-dropdown gains the Light source
- New `scripts/check_fidelity.py` (effective values per state and mode, accepted/pending lists in manifests); tests layer 8
- BS1 button value 8 pt + hover/press details · token `hover.control_text` · BS3 keepLayerOrder on dropdowns
- normalize_visual: per-state selectors normalised (theme-equal dropped, colours tokenised by state); report-page tooltip links removed
- bind_blueprint: `--preset`, `--x`, width from COLUMNS, empty SYNC_GROUP = not synced
- Testbed bottom band built entirely from blueprints (7 slicers); FMT-002 no longer flags slicer label units
- Pending: BS2 (Light press colour), BS4 (button corner radius)

## [0.5.3] - 2026-10-06
- RD1b (Desktop test): themes ignore `slicer.dropdown.borderRadius` → removed from the theme; new registry
  `component.visual_level` (styles that must be written on each visual); normalizer keeps them as `{{num:<token>}}`,
  binder resolves them; testbed Year slicer sets it; new rule SLICER-008 (auto, 31 automated rules)

## [0.5.2] - 2026-10-06 · design system 0.3.0
- RD1: new token `radius.dropdown` = 3; theme sets `slicer.dropdown.borderRadius` (themes rebuilt as 0.3.0)
- Blueprint `slicer/period-dropdown` 1.2.0 regenerated from the v2 source (schema 2.13.0); everything visual now comes from the theme
- normalize_visual: font families compared by first family name

## [0.5.1] - 2026-10-06 · design system 0.2.0
- SL1: new type role `type.slicer_header` (Segoe UI Semibold 9) for dropdown slicer headers; themes rebuilt as 0.2.0
- SL2: period dropdown opens on "Last Month" (label in the model, never stale); blueprint `slicer/period-dropdown` 1.1.0
- `bind_blueprint.render()` importable; the testbed builds its Period slicer from the blueprint (`Date[Period Label]`)

## [0.5.0] - 2026-10-06
- Blueprint library (D19): `inbox/visuals/` drop zone (repo only), `scripts/normalize_visual.py`, `scripts/bind_blueprint.py`,
  `assets/blueprints/INDEX.md`, core rule C18
- First blueprint `slicer/period-dropdown` (Slicer Period): bound into the testbed → compliance PASSED, twins PASSED
- Pending decisions SL1 (header Semibold) and SL2 (default period)

## [0.4.1] - 2026-10-06
- Fix (Desktop test): Intro logo and title were hidden behind the background shape's container background; navigator showed a title bar
- Intro template: container title/background/header off on every visual, normalised z-order; PAGE-009 checks it
- Theme: navigators without title/background/border; shape without container background; image without header
- New rule NAV-007 (navigators never show a title) · tests 41/41

## [0.4.0] - 2026-10-06
- `scripts/make_light_twin.py`: deterministic Light twin builder (profile, roles, colour map, asset swap, toggles)
- Testbed `tests/testbed/` (HouseTest PBIP, fictitious data) + `preview_testbed.py`; run_tests 40/40
- Checker fixes: waterfall decrease in Light (COLOR-006); twins ignore colours inside text runs

## [0.3.0] - 2026-10-05
- Intro template v2: background, world map, round RHG logo, generic title "Title", page navigator only
- Removed: tutorial buttons, DynamicScroll banner, version text, last-update card, model measures, play icon
- Dynamic navigator height by number of tabs (`install_intro.py --refresh-nav`, rule PAGE-010)
- Intro is Dark-only (no Light twin), enforced by PAGE-008
- check_compliance: 30 automated rules · tests 37/37

## [0.2.0] - 2026-10-05
- **Intro page** as a locked brand template (exact copy of Operational Report - Fabric Intro): `assets/templates/intro-page`,
  `scripts/install_intro.py`, `references/components/intro-page.md`, rules PAGE-008/009, core rule C16
- **Corporate logos** (`assets/logo/`) and icons (`assets/icons/`), core rule C17, PAGE-003 updated with file names
- check_compliance: Intro checks (29 automated rules); Intro exempt from grid/typography/colour/naming/twin rules
- Tests 32/32 (+8 intro tests)
- Design system tokens/themes unchanged (tokens v0.1.0)

## [0.1.0] - 2026-10-05 (packaged)
- Step 10: evals with/without skill (18/18 vs 4/18), description tuned, rule-ID citation fix, validation report
- SKILL.md router, 21 references, 106 rules (17 domains), rule ID system v1.0
- tokens.yaml: 15 primitive colours, semantic colours with dark/light parity, 14 type roles, layout, components
- Generated themes: corporate-dark (register), light-overrides (twins), corporate-light (reference)
- Checkers: check_tokens, check_contrast, check_compliance (27 automated rules), check_twins, diff_guard
- Accepted deviations AD-001…AD-005; tooltips dark in both modes
- Tests 24/24; evals (10 behavioural, 16 trigger)

## [0.0.0] - 2026-10-04
- Repository scaffold (Step 4).
