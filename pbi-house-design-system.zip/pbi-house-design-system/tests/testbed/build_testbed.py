#!/usr/bin/env python3
"""
build_testbed.py: generate the HouseTest PBIP (fictitious hotel group data) built with the house design system.

Everything is regenerated from scratch (deterministic data, seed 42). No external data source:
tables are "Enter data"-style M partitions (compressed JSON) + an M-generated Date table, so the model
refreshes offline in Power BI Desktop.

Pages: Intro (install_intro.py) · Summary · P&L · Hotel List  (+ Light twins via make_light_twin.py)
Run:   python tests/testbed/build_testbed.py        → tests/testbed/HouseTest/
Then:  open HouseTest/HouseTest.pbip in Power BI Desktop → Refresh.
"""
from __future__ import annotations

import base64
import json
import random
import shutil
import subprocess
import sys
import uuid
import zlib
from datetime import date
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL = HERE.parent.parent
OUT = HERE / "HouseTest"
NAME = "HouseTest"
sys.path.insert(0, str(SKILL / "scripts"))
import _tokens as T  # noqa: E402
from bind_blueprint import render as render_blueprint  # noqa: E402
from install_header import header_visuals  # noqa: E402
from apply_table_role import apply_role  # noqa: E402

TOK = T.load()
VER = TOK["meta"]["version"]
M = "_Measures"


def uid() -> str:
    return str(uuid.uuid4())


def hexid() -> str:
    return uuid.uuid4().hex[:20]


def tok(path: str, mode: str = "dark") -> str:
    return T.resolve_path(TOK, T.expand_alias(path), mode)


# =====================================================================================
# 1. DATA (fictitious, deterministic)
# =====================================================================================
rnd = random.Random(42)
HOTELS = [  # id, name, city, area, rooms, adr
    (1, "Aurora Grand", "Madrid", "Iberia", 320, 145), (2, "Costa Azul", "Lisbon", "Iberia", 210, 120),
    (3, "Fjord View", "Oslo", "Nordics", 260, 170), (4, "Nordlys Central", "Stockholm", "Nordics", 180, 160),
    (5, "Alpine Lodge", "Zurich", "DACH", 150, 210), (6, "Spree Riverside", "Berlin", "DACH", 400, 115),
    (7, "Thames Court", "London", "UK & Ireland", 350, 190), (8, "Liffey House", "Dublin", "UK & Ireland", 190, 150),
    (9, "Canal Belle", "Amsterdam", "Benelux", 240, 175), (10, "Grand Place", "Brussels", "Benelux", 200, 130),
    (11, "Duomo Palace", "Milan", "Italy", 280, 185), (12, "Colosseo Suites", "Rome", "Italy", 230, 165),
]
SEASON = [0.62, 0.66, 0.74, 0.80, 0.86, 0.92, 0.95, 0.93, 0.88, 0.80, 0.70, 0.65]
RATIOS = {"PAY": -0.30, "OPX": -0.33, "RNT": -0.16, "DNA": -0.05}
LAST_ACT = (2026, 9)
facts = []
for hid, _, _, _, rooms, adr in HOTELS:
    for y in (2025, 2026):
        growth = 1.0 if y == 2025 else 1.045
        for m in range(1, 13):
            days = 30
            base = rooms * adr * SEASON[m - 1] * days * growth
            budget_rev = base * 1.03
            act_rev = base * rnd.uniform(0.94, 1.06)
            is_act = (y, m) <= LAST_ACT
            d = date(y, m, 1).isoformat()
            scen_rev = [("ACT", act_rev)] if is_act else ([("FCT", budget_rev * rnd.uniform(0.97, 1.01))] if y == 2026 else [])
            if y == 2026:
                scen_rev.append(("BUD", budget_rev))
            for scen, rev in scen_rev:
                facts.append([d, hid, "REV", scen, round(rev, 2)])
                for acc, r in RATIOS.items():
                    noise = rnd.uniform(0.95, 1.05) if scen == "ACT" else 1.0
                    facts.append([d, hid, acc, scen, round(rev * r * noise, 2)])

LAYOUT = [  # order, code, line, type, highlight, abs fmt, dev fmt
    (1, "REV", "Revenue", "Base", 1, "#,##", "#,##"),
    (2, "PAY", "   Payroll", "Base", None, "#,##", "#,##"),
    (3, "PAY%", "    ↪ %Rev Payroll", "Ratio", None, "#,#0.0%", "#,#0.0 pp"),
    (4, "OPX", "   Other OPEX", "Base", None, "#,##", "#,##"),
    (5, "OPX%", "    ↪ %Rev Other OPEX", "Ratio", None, "#,#0.0%", "#,#0.0 pp"),
    (6, "EBITDAR", "EBITDAR", "Subtotal", 2, "#,##", "#,##"),
    (7, "EBITDAR%", "    ↪ %Rev EBITDAR", "Ratio", None, "#,#0.0%", "#,#0.0 pp"),
    (8, "RNT", "   Rent", "Base", None, "#,##", "#,##"),
    (9, "EBITDA", "EBITDA", "Subtotal", 3, "#,##", "#,##"),
    (10, "EBITDA%", "    ↪ %Rev EBITDA", "Ratio", None, "#,#0.0%", "#,#0.0 pp"),
    (11, "DNA", "   D&A", "Base", None, "#,##", "#,##"),
    (12, "NI", "Net Income", "Subtotal", 1, "#,##", "#,##"),
]
HL = {1: ("surface.total_row", "text.on_total_row"), 2: ("surface.total_row", "text.on_total_row"),
      3: ("surface.highlight_row", "text.on_highlight_row")}
layout_rows = []
for o, code, line, typ, hl, af, df in LAYOUT:
    bg, fg = (tok("color." + HL[hl][0]), tok("color." + HL[hl][1])) if hl else (None, None)
    layout_rows.append([o, code, line, typ, hl, bg, fg, af, df])


# =====================================================================================
# 2. SEMANTIC MODEL (TMDL)
# =====================================================================================
def enter_data_m(cols: list[tuple[str, str]], rows: list[list]) -> str:
    payload = json.dumps([[None if v is None else str(v) for v in r] for r in rows], ensure_ascii=False).encode()
    c = zlib.compressobj(9, zlib.DEFLATED, -15)
    b64 = base64.b64encode(c.compress(payload) + c.flush()).decode()
    cols_t = ", ".join(f'#"{n}" = _t' if " " in n else f"{n} = _t" for n, _ in cols)
    types = ", ".join(f'{{"{n}", {t}}}' for n, t in cols)
    return (f'let\n    Source = Table.FromRows(Json.Document(Binary.Decompress(Binary.FromText("{b64}", BinaryEncoding.Base64), '
            f'Compression.Deflate)), let _t = ((type nullable text) meta [Serialized.Text = true]) in type table [{cols_t}]),\n'
            f'    Typed = Table.TransformColumnTypes(Source, {{{types}}})\nin\n    Typed')


def col(name, dtype, fmt=None, summarize="none", sort_by=None, hidden=False, key=False):
    s = f"\tcolumn '{name}'\n" if any(ch in name for ch in " &%") else f"\tcolumn {name}\n"
    s += f"\t\tdataType: {dtype}\n"
    if key:
        s += "\t\tisKey\n"
    if hidden:
        s += "\t\tisHidden\n"
    if fmt:
        s += f"\t\tformatString: {fmt}\n"
    s += f"\t\tlineageTag: {uid()}\n\t\tsummarizeBy: {summarize}\n\t\tsourceColumn: {name}\n"
    if sort_by:
        s += f"\t\tsortByColumn: {sort_by}\n"
    s += "\n\t\tannotation SummarizationSetBy = Automatic\n\n"
    return s


def table(name, columns: str, m: str, extra_header: str = "", measures: str = "") -> str:
    qn = f"'{name}'" if " " in name else name
    body = "\n".join("\t\t\t\t" + ln for ln in m.splitlines())
    return (f"table {qn}\n{extra_header}\tlineageTag: {uid()}\n\n{measures}{columns}"
            f"\tpartition {qn} = m\n\t\tmode: import\n\t\tsource =\n{body}\n\n"
            f"\tannotation PBI_ResultType = Table\n\n")


def measure(name, dax, fmt=None, fmt_expr=None, folder=None, hidden=False):
    qn = f"'{name}'" if any(ch in name for ch in " &%()-/") else name
    body = "\n".join("\t\t\t" + ln for ln in dax.strip().splitlines())
    s = f"\tmeasure {qn} =\n{body}\n"
    if hidden:
        s += "\t\tisHidden\n"
    if fmt:
        s += f"\t\tformatString: {fmt}\n"
    if folder:
        s += f"\t\tdisplayFolder: {folder}\n"
    s += f"\t\tlineageTag: {uid()}\n"
    if fmt_expr:
        s += "\n\t\tformatStringDefinition = " + fmt_expr + "\n"
    return s + "\n"


ACC = lambda codes: "{" + ", ".join(f'"{c}"' for c in codes) + "}"  # noqa: E731
MEASURES = [
    ("_Unit Factor", 'SWITCH(SELECTEDVALUE(Unit[Unit], "K"), "M", 1000000, 1000)', "0", None, "_helpers", True),
    ("_Comparison", 'SELECTEDVALUE(Comparison[Comparison], "vs BUD")', None, None, "_helpers", True),
    ("_Amt", "SUM(Facts[Amount])", "#,##", None, "_helpers", True),
    ("_Amt ACT", 'CALCULATE([_Amt], Facts[Scenario] = "ACT")', "#,##", None, "_helpers", True),
    ("_Amt BUD", 'CALCULATE([_Amt], Facts[Scenario] = "BUD")', "#,##", None, "_helpers", True),
    ("_Amt LY", "CALCULATE([_Amt ACT], SAMEPERIODLASTYEAR('Date'[Date]))", "#,##", None, "_helpers", True),
    ("_Amt REF", 'IF([_Comparison] = "vs LY", [_Amt LY], [_Amt BUD])', "#,##", None, "_helpers", True),
    ("_REV ACT", 'CALCULATE([_Amt ACT], Facts[Account] = "REV")', "#,##", None, "_helpers", True),
    ("_REV REF", 'CALCULATE([_Amt REF], Facts[Account] = "REV")', "#,##", None, "_helpers", True),
    ("_EBITDA ACT", f"CALCULATE([_Amt ACT], Facts[Account] IN {ACC(['REV','PAY','OPX','RNT'])})", "#,##", None, "_helpers", True),
    ("_EBITDA REF", f"CALCULATE([_Amt REF], Facts[Account] IN {ACC(['REV','PAY','OPX','RNT'])})", "#,##", None, "_helpers", True),
    # KPI cards
    ("Revenue", "DIVIDE([_REV ACT], [_Unit Factor])", "#,##", None, "KPI", False),
    ("Payroll", 'DIVIDE(-CALCULATE([_Amt ACT], Facts[Account] = "PAY"), [_Unit Factor])', "#,##", None, "KPI", False),
    ("EBITDAR", f"DIVIDE(CALCULATE([_Amt ACT], Facts[Account] IN {ACC(['REV','PAY','OPX'])}), [_Unit Factor])", "#,##", None, "KPI", False),
    ("EBITDA", "DIVIDE([_EBITDA ACT], [_Unit Factor])", "#,##", None, "KPI", False),
    ("EBITDA %", "DIVIDE([_EBITDA ACT], [_REV ACT])", "#,#0.0%", None, "KPI", False),
    ("Net Income", "DIVIDE(CALCULATE([_Amt ACT], NOT ISBLANK(Facts[Account])), [_Unit Factor])", "#,##", None, "KPI", False),
    ("Revenue vs REF %", "DIVIDE([_REV ACT] - [_REV REF], ABS([_REV REF]))", "#,#0.0%", None, "KPI", False),
    ("EBITDA vs REF %", "DIVIDE([_EBITDA ACT] - [_EBITDA REF], ABS([_EBITDA REF]))", "#,#0.0%", None, "KPI", False),
    # P&L (layout-driven, disconnected 'PnL Layout' table)
    ("_PL Line", """
VAR code = SELECTEDVALUE('PnL Layout'[Line Code])
VAR f = [_Unit Factor]
VAR REV = CALCULATE([_Amt], Facts[Account] = "REV")
VAR PAY = CALCULATE([_Amt], Facts[Account] = "PAY")
VAR OPX = CALCULATE([_Amt], Facts[Account] = "OPX")
VAR RNT = CALCULATE([_Amt], Facts[Account] = "RNT")
VAR DNA = CALCULATE([_Amt], Facts[Account] = "DNA")
VAR EBITDAR = REV + PAY + OPX
VAR EBITDA = EBITDAR + RNT
VAR NI = EBITDA + DNA
RETURN
    SWITCH(code,
        "REV", DIVIDE(REV, f), "PAY", DIVIDE(-PAY, f), "PAY%", DIVIDE(-PAY, REV),
        "OPX", DIVIDE(-OPX, f), "OPX%", DIVIDE(-OPX, REV),
        "EBITDAR", DIVIDE(EBITDAR, f), "EBITDAR%", DIVIDE(EBITDAR, REV),
        "RNT", DIVIDE(-RNT, f), "EBITDA", DIVIDE(EBITDA, f), "EBITDA%", DIVIDE(EBITDA, REV),
        "DNA", DIVIDE(-DNA, f), "NI", DIVIDE(NI, f))""", None, None, "_helpers", True),
    ("ACT", 'CALCULATE([_PL Line], Facts[Scenario] = "ACT")', None, "SELECTEDVALUE('PnL Layout'[ABS Format], \"#,##\")", "P&L", False),
    ("REF", """IF([_Comparison] = "vs LY",
    CALCULATE([_PL Line], Facts[Scenario] = "ACT", SAMEPERIODLASTYEAR('Date'[Date])),
    CALCULATE([_PL Line], Facts[Scenario] = "BUD"))""", None, "SELECTEDVALUE('PnL Layout'[ABS Format], \"#,##\")", "P&L", False),
    ("vs REF", """VAR a = [ACT]
VAR b = [REF]
RETURN IF(SELECTEDVALUE('PnL Layout'[Line Type]) = "Ratio", (a - b) * 100, a - b)""", None, "SELECTEDVALUE('PnL Layout'[DEV Format], \"#,##\")", "P&L", False),
    ("ACT YTD", "CALCULATE([ACT], DATESYTD('Date'[Date]))", None, "SELECTEDVALUE('PnL Layout'[ABS Format], \"#,##\")", "P&L", False),
    ("REF YTD", "CALCULATE([REF], DATESYTD('Date'[Date]))", None, "SELECTEDVALUE('PnL Layout'[ABS Format], \"#,##\")", "P&L", False),
    ("vs REF YTD", """VAR a = [ACT YTD]
VAR b = [REF YTD]
RETURN IF(SELECTEDVALUE('PnL Layout'[Line Type]) = "Ratio", (a - b) * 100, a - b)""", None, "SELECTEDVALUE('PnL Layout'[DEV Format], \"#,##\")", "P&L", False),
    ("_Row Background", "SELECTEDVALUE('PnL Layout'[Background Color])", None, None, "_helpers", True),
    ("_Row Font", "SELECTEDVALUE('PnL Layout'[Font Color])", None, None, "_helpers", True),
    # Trend (line chart) and bridge (waterfall)
    ("EBITDA ACT", "DIVIDE([_EBITDA ACT], [_Unit Factor])", "#,##", None, "Trend", False),
    ("EBITDA FCT", f'DIVIDE(CALCULATE([_Amt], Facts[Scenario] = "FCT", Facts[Account] IN {ACC(["REV","PAY","OPX","RNT"])}), [_Unit Factor])', "#,##", None, "Trend", False),
    ("EBITDA REF", "DIVIDE([_EBITDA REF], [_Unit Factor])", "#,##", None, "Trend", False),
    ("EBITDA bridge vs REF", """VAR code = SELECTEDVALUE(Bridge[Account])
RETURN DIVIDE(CALCULATE([_Amt ACT], Facts[Account] = code) - CALCULATE([_Amt REF], Facts[Account] = code), [_Unit Factor])""", "#,##", None, "Trend", False),
    # Titles and labels
    ("Title P&L", '"P&L Hotel Group (in EUR " & IF(SELECTEDVALUE(Unit[Unit], "K") = "M", "millions", "thousands") & ")"', None, None, "Titles", False),
    ("Title Trend", '"EBITDA monthly tracking · " & SELECTEDVALUE(\'Date\'[Year]) & " - Actual vs " & IF([_Comparison] = "vs LY", "Last year", "Budget") & " (Ref)"', None, None, "Titles", False),
    ("Title Bridge", '"EBITDA bridge - Actual vs " & IF([_Comparison] = "vs LY", "Last year", "Budget") & " (Ref)"', None, None, "Titles", False),
    ("Selected Period", 'FORMAT(MAX(\'Date\'[Date]), "mmm-yyyy")', None, None, "Titles", False),
    ("Dummy Column", '""', None, None, "Titles", False),                                    # TB2 · separator column "."
]


def build_model(root: Path):
    sm = root / f"{NAME}.SemanticModel"
    d = sm / "definition"
    (d / "tables").mkdir(parents=True)
    (sm / "definition.pbism").write_text(json.dumps({
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json",
        "version": "4.2", "settings": {}}, indent=2))
    (sm / ".platform").write_text(json.dumps({
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",
        "metadata": {"type": "SemanticModel", "displayName": NAME}, "config": {"version": "2.0", "logicalId": uid()}}, indent=2))
    (d / "database.tmdl").write_text("database\n\tcompatibilityLevel: 1606\n\n")
    tables = ["Date", "Hotel", "Facts", "PnL Layout", "Comparison", "Unit", "Deltaview", "Currency", "Dataview", "Bridge", M]
    refs = "".join(f"ref table '{t}'\n" if " " in t else f"ref table {t}\n" for t in tables)
    (d / "model.tmdl").write_text(
        "model Model\n\tculture: en-US\n\tdefaultPowerBIDataSourceVersion: powerBI_V3\n\tsourceQueryCulture: en-US\n"
        "\tdataAccessOptions\n\t\tlegacyRedirects\n\t\treturnErrorValuesAsNull\n\n"
        "annotation __PBI_TimeIntelligenceEnabled = 0\n\n"
        f"annotation PBI_QueryOrder = {json.dumps(tables)}\n\n{refs}")
    (d / "relationships.tmdl").write_text(
        f"relationship {uid()}\n\tfromColumn: Facts.Date\n\ttoColumn: Date.Date\n\n"
        f"relationship {uid()}\n\tfromColumn: Facts.HotelID\n\ttoColumn: Hotel.HotelID\n\n")

    date_m = """let
    Start = #date(2025, 1, 1),
    Dates = List.Dates(Start, Duration.Days(#date(2026, 12, 31) - Start) + 1, #duration(1, 0, 0, 0)),
    T = Table.FromList(Dates, Splitter.SplitByNothing(), {"Date"}),
    Typed = Table.TransformColumnTypes(T, {{"Date", type date}}),
    Y = Table.AddColumn(Typed, "Year", each Date.Year([Date]), Int64.Type),
    MN = Table.AddColumn(Y, "MonthNo", each Date.Month([Date]), Int64.Type),
    Mo = Table.AddColumn(MN, "Month", each Date.ToText([Date], "MMM", "en-US"), type text),
    P = Table.AddColumn(Mo, "Period", each Date.ToText([Date], "MMM-yy", "en-US"), type text),
    K = Table.AddColumn(P, "PeriodKey", each [Year] * 100 + [MonthNo], Int64.Type),
    LastClosed = Date.StartOfMonth(Date.AddMonths(Date.From(DateTime.LocalNow()), -1)),
    L = Table.AddColumn(K, "Period Label", each if Date.StartOfMonth([Date]) = LastClosed then "Last Month" else [Period], type text)
in
    L"""
    files = {
        "Date": table("Date", col("Date", "dateTime", "dd/mm/yyyy", key=True) + col("Year", "int64", "0")
                      + col("MonthNo", "int64", "0", hidden=True) + col("Month", "string", sort_by="MonthNo")
                      + col("Period", "string", sort_by="PeriodKey") + col("PeriodKey", "int64", "0", hidden=True)
                      + col("Period Label", "string", sort_by="PeriodKey"),
                      date_m, extra_header="\tdataCategory: Time\n"),
        "Hotel": table("Hotel", col("HotelID", "int64", "0", hidden=True) + col("Hotel", "string") + col("City", "string")
                       + col("Area", "string") + col("Rooms", "int64", "#,##", summarize="sum"),
                       enter_data_m([("HotelID", "Int64.Type"), ("Hotel", "type text"), ("City", "type text"),
                                     ("Area", "type text"), ("Rooms", "Int64.Type")], [list(h[:5]) for h in HOTELS])),
        "Facts": table("Facts", col("Date", "dateTime", "dd/mm/yyyy", hidden=True) + col("HotelID", "int64", "0", hidden=True)
                       + col("Account", "string", hidden=True) + col("Scenario", "string", hidden=True)
                       + col("Amount", "double", "#,##", summarize="sum", hidden=True),
                       enter_data_m([("Date", "type date"), ("HotelID", "Int64.Type"), ("Account", "type text"),
                                     ("Scenario", "type text"), ("Amount", "type number")], facts)),
        "PnL Layout": table("PnL Layout", col("Line Order", "int64", "0", hidden=True) + col("Line Code", "string", hidden=True)
                            + col("Line", "string", sort_by="'Line Order'") + col("Line Type", "string", hidden=True)
                            + col("Highlight Code", "int64", "0", hidden=True) + col("Background Color", "string", hidden=True)
                            + col("Font Color", "string", hidden=True) + col("ABS Format", "string", hidden=True)
                            + col("DEV Format", "string", hidden=True),
                            enter_data_m([("Line Order", "Int64.Type"), ("Line Code", "type text"), ("Line", "type text"),
                                          ("Line Type", "type text"), ("Highlight Code", "Int64.Type"),
                                          ("Background Color", "type text"), ("Font Color", "type text"),
                                          ("ABS Format", "type text"), ("DEV Format", "type text")], layout_rows)),
        "Comparison": table("Comparison", col("Comparison", "string", sort_by="Order") + col("Order", "int64", "0", hidden=True),
                            enter_data_m([("Comparison", "type text"), ("Order", "Int64.Type")], [["vs BUD", 1], ["vs LY", 2]])),
        "Unit": table("Unit", col("Unit", "string", sort_by="Order") + col("Order", "int64", "0", hidden=True),
                      enter_data_m([("Unit", "type text"), ("Order", "Int64.Type")], [["K", 1], ["M", 2]])),
        **{t: table(t, col(t, "string", sort_by="Order") + col("Order", "int64", "0", hidden=True),
                    enter_data_m([(t, "type text"), ("Order", "Int64.Type")], [[o, i + 1] for i, o in enumerate(opts)]))
           for t, opts in [("Deltaview", ["ABS", "DEV", "DEV%"]), ("Currency", ["EUR", "FXN", "LC"]),
                           ("Dataview", ["Mth", "YTD", "ROY", "FY"])]},   # view selectors only (no measure reads them)
        "Bridge": table("Bridge", col("Driver", "string", sort_by="Order") + col("Account", "string", hidden=True)
                        + col("Order", "int64", "0", hidden=True),
                        enter_data_m([("Driver", "type text"), ("Account", "type text"), ("Order", "Int64.Type")],
                                     [["Revenue", "REV", 1], ["Payroll", "PAY", 2], ["Other OPEX", "OPX", 3], ["Rent", "RNT", 4]])),
        M: table(M, col("Placeholder", "string", hidden=True), 'let\n    Source = #table(type table [Placeholder = text], {})\nin\n    Source',
                 measures="".join(measure(n, dx, f, fe, fo, h) for n, dx, f, fe, fo, h in MEASURES)),
    }
    for name, text in files.items():
        (d / "tables" / f"{name.replace('*', '%2A')}.tmdl").write_text(text, encoding="utf-8")


# =====================================================================================
# 3. REPORT (PBIR) — Dark pages; twins + Intro via skill scripts
# =====================================================================================
VC = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.12.0/schema.json"
PG = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.1.0/schema.json"


INT_L = {"columnCount", "rowCount", "maxTiles", "cellPadding", "orientation"}


def L(v, key=""):
    if isinstance(v, bool):
        return {"expr": {"Literal": {"Value": "true" if v else "false"}}}
    if isinstance(v, (int, float)):
        return {"expr": {"Literal": {"Value": f"{int(v)}L" if key in INT_L else f"{v}D"}}}
    if isinstance(v, str) and v.startswith("#"):
        return {"solid": {"color": {"expr": {"Literal": {"Value": f"'{v}'"}}}}}
    return {"expr": {"Literal": {"Value": f"'{v}'"}}}


def F(entity, prop, kind="Column"):
    return {kind: {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}


def proj(entity, prop, kind="Column", display=None):
    p = {"field": F(entity, prop, kind), "queryRef": f"{entity}.{prop}", "nativeQueryRef": prop}
    if display:
        p["displayName"] = display
    return p


def props(d: dict, selector=None):
    e = {"properties": {k: v if isinstance(v, dict) and ("expr" in v or "solid" in v) else L(v, k) for k, v in d.items()}}
    if selector:
        e["selector"] = selector
    return e


def visual(vtype, x, y, w, h, z=1000, query=None, objects=None, container=None, name=None):
    v = {"visualType": vtype}
    if query:
        v["query"] = {"queryState": query}
    v["objects"] = objects or {}
    v["visualContainerObjects"] = container or {}
    return {"$schema": VC, "name": name or hexid(),
            "position": {"x": x, "y": y, "z": z, "height": h, "width": w, "tabOrder": z}, "visual": v}


def title(text=None, measure_title=None):
    t = {"show": True}
    if text:
        t["text"] = text
    if measure_title:
        t["text"] = {"expr": {"Measure": {"Expression": {"SourceRef": {"Entity": M}}, "Property": measure_title}}}
    return {"title": [props(t)]}


def slicer_filter(entity, prop, value, numeric=False):
    lit = f"{value}L" if numeric else f"'{value}'"
    return {"filter": {"Version": 2, "From": [{"Name": "x", "Entity": entity, "Type": 0}],
                       "Where": [{"Condition": {"In": {"Expressions": [{"Column": {"Expression": {"SourceRef": {"Source": "x"}},
                                                                                   "Property": prop}}],
                                                       "Values": [[{"Literal": {"Value": lit}}]]}}}]}}


def chrome(page_title: str):
    """Header (container, logo, title, period) + bottom band (dropdowns, button groups, home, mode toggle)."""
    vs = []
    vs += header_visuals(TOK, "dark", page_title, TOK["component"]["header"]["badge"]["caption"],
                         period=f"{M}[Selected Period]")                                             # HD1/HD3 · page header
    # bottom band
    # D19 · every bottom-band slicer comes from a blueprint (source: RHG Consolidated Results › P&L RHG)
    year = render_blueprint("slicer/year-dropdown", {"FIELD_1": "Date[Year]"}, {"DEFAULT_VALUE": "2026L"}, tab=4000)
    period = render_blueprint("slicer/period-dropdown", {"FIELD_1": "Date[Period Label]"}, tab=5000)   # SL1 · SL2
    vs += [year, period]
    x, z = 277, 6000
    for preset, field, params in [("ly-tgt", "Comparison[Comparison]", {"DEFAULT_VALUE": "vs BUD"}),   # testbed values
                                  ("deltaview", "Deltaview[Deltaview]", {}),
                                  ("figures", "Unit[Unit]", {"DEFAULT_VALUE": "K"}),
                                  ("currency", "Currency[Currency]", {}),
                                  ("dataview", "Dataview[Dataview]", {})]:
        b = render_blueprint("slicer/button-group", {"FIELD_1": field}, params, preset=preset, x=x, tab=z)
        b["position"]["z"] = z
        vs.append(b)
        x, z = x + b["position"]["width"] + 16, z + 100
    toggle = visual("actionButton", 1218, 663, 50, 50, z=9000, objects={
        "icon": [props({"shapeType": "blank"}, {"id": "default"})],
        "fill": [{"properties": {"show": L(True)}},
                 {"properties": {"image": {"image": {"name": L("moon.png"), "url": {"expr": {"ResourcePackageItem": {
                     "PackageName": "RegisteredResources", "PackageType": 1, "ItemName": "moon.png"}}}, "scaling": L("Normal")}}},
                  "selector": {"id": "default"}}]},
        container={"visualLink": [props({"show": True, "type": "PageNavigation", "navigationSection": "__SELF__"})],
                   "visualHeader": [props({"show": False})]})
    vs.append(toggle)
    return vs, {"year": year["name"], "period": period["name"]}


def kpi_row():
    return visual("cardVisual", 12, 88, 1256, 176, z=10000, query={"Data": {"projections": [
        proj(M, n, "Measure") for n in ("Revenue", "Payroll", "EBITDAR", "EBITDA", "EBITDA %", "Net Income")]}},
        objects={"layout": [props({"maxTiles": 6, "orientation": 1})],
                 "label": [props({"show": True, "position": "aboveValue"}, {"id": "default"})]},
        container=title("Key figures"))


def series(mode):
    return {"dataPoint": [props({"fill": tok("color.scenario.actual", mode)}, {"metadata": f"{M}.EBITDA ACT"}),
                          props({"fill": tok("color.scenario.forecast", mode)}, {"metadata": f"{M}.EBITDA FCT"}),
                          props({"fill": tok("color.scenario.reference", mode)}, {"metadata": f"{M}.EBITDA REF"})],
            "lineStyles": [props({"lineStyle": "dashed"}, {"metadata": f"{M}.EBITDA FCT"}),
                           props({"showMarker": True}, {"metadata": f"{M}.EBITDA ACT"})]}


def trend(x, y, w, h):
    return visual("lineChart", x, y, w, h, z=11000, query={
        "Category": {"projections": [{**proj("Date", "Period"), "active": True}]},
        "Y": {"projections": [proj(M, n, "Measure") for n in ("EBITDA ACT", "EBITDA FCT", "EBITDA REF")]}},
        objects=series("dark"), container=title(measure_title="Title Trend"))


def bridge(x, y, w, h):
    return visual("waterfallChart", x, y, w, h, z=12000, query={
        "Category": {"projections": [{**proj("Bridge", "Driver"), "active": True}]},
        "Y": {"projections": [proj(M, "EBITDA bridge vs REF", "Measure")]}},
        container=title(measure_title="Title Bridge"))


def page(display, visuals, interactions=()):
    pid = hexid()
    return pid, {"$schema": PG, "name": pid, "displayName": display, "displayOption": "FitToPage", "height": 720, "width": 1280,
                 "visualInteractions": [{"source": s, "target": t, "type": "NoFilter"} for s, t in interactions]}, visuals


def build_report(root: Path):
    rep = root / f"{NAME}.Report"
    d = rep / "definition"
    (d / "pages").mkdir(parents=True)
    rr = rep / "StaticResources" / "RegisteredResources"
    rr.mkdir(parents=True)
    (rep / "StaticResources" / "SharedResources" / "BaseThemes").mkdir(parents=True)
    base_theme = SKILL / "tests" / "testbed" / "CY26SU05.json"
    shutil.copy(base_theme, rep / "StaticResources" / "SharedResources" / "BaseThemes" / "CY26SU05.json")
    theme = f"corporate-dark.{VER}.json"
    shutil.copy(SKILL / "assets" / "themes" / theme, rr / theme)
    for n in ("logo-white.png",):
        shutil.copy(SKILL / "assets" / "logo" / n, rr / n)
    for n in ("moon.png",):
        shutil.copy(SKILL / "assets" / "icons" / n, rr / n)
    (rep / "definition.pbir").write_text(json.dumps({
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/2.0.0/schema.json",
        "version": "4.0", "datasetReference": {"byPath": {"path": f"../{NAME}.SemanticModel"}}}, indent=2))
    (rep / ".platform").write_text(json.dumps({
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",
        "metadata": {"type": "Report", "displayName": NAME}, "config": {"version": "2.0", "logicalId": uid()}}, indent=2))
    (d / "version.json").write_text(json.dumps({
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/versionMetadata/1.0.0/schema.json",
        "version": "2.0.0"}, indent=2))
    (d / "report.json").write_text(json.dumps({
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/report/3.3.0/schema.json",
        "themeCollection": {
            "baseTheme": {"name": "CY26SU05", "reportVersionAtImport": {"visual": "2.9.0", "report": "3.3.0", "page": "2.3.1"}, "type": "SharedResources"},
            "customTheme": {"name": theme, "reportVersionAtImport": {"visual": "2.11.0", "report": "3.4.0", "page": "2.3.1"}, "type": "RegisteredResources"}},
        "resourcePackages": [
            {"name": "SharedResources", "type": "SharedResources", "items": [{"name": "CY26SU05", "path": "BaseThemes/CY26SU05.json", "type": "BaseTheme"}]},
            {"name": "RegisteredResources", "type": "RegisteredResources", "items": [
                {"name": theme, "path": theme, "type": "CustomTheme"},
                {"name": "logo-white.png", "path": "logo-white.png", "type": "Image"},
                {"name": "moon.png", "path": "moon.png", "type": "Image"}]}],
        "settings": {"useStylableVisualContainerHeader": True, "exportDataMode": "AllowSummarized",
                     "defaultDrillFilterOtherVisuals": True, "allowChangeFilterTypes": True, "useEnhancedTooltips": True,
                     "useDefaultAggregateDisplayName": True}}, indent=2))

    pages = []
    # Summary (T-SUMMARY)
    c, ids = chrome("Summary")
    line = trend(12, 280, 620, 180)
    bars = visual("clusteredBarChart", 648, 280, 620, 180, z=11500, query={
        "Category": {"projections": [{**proj("Hotel", "Area"), "active": True}]},
        "Y": {"projections": [proj(M, "Revenue", "Measure")]}},
        container=title("Revenue by area"))
    br = bridge(12, 476, 620, 180)
    top = visual("tableEx", 648, 476, 620, 180, z=12500, query={"Values": {"projections": [
        proj("Hotel", "Hotel"), proj(M, "Revenue", "Measure"), proj(M, "EBITDA", "Measure"), proj(M, "EBITDA vs REF %", "Measure")]}},
        container=title("Hotels by EBITDA"))
    pages.append(page("Summary", c + [kpi_row(), line, bars, br, top], [(ids["period"], line["name"])]))
    # P&L (T-STATEMENT)
    c, ids = chrome("Profit & Loss")
    pnl_fields = [("PnL Layout", "Line", "Column")] + [(M, n, "Measure") for n in ("ACT", "REF", "vs REF", "ACT YTD", "REF YTD", "vs REF YTD")]
    cf = lambda prop, meas: {"solid": {"color": {"expr": {"Measure": {"Expression": {"SourceRef": {"Entity": M}}, "Property": meas}}}}}
    pnl = visual("tableEx", 12, 88, 620, 568, z=10000, query={
        "Values": {"projections": [proj(e, p, k, display=("P&L" if p == "Line" else None)) for e, p, k in pnl_fields]}},
        objects={"total": [props({"totals": False})], "grid": [props({"rowPadding": 1})],
                 "values": [{"properties": {"backColor": cf("backColor", "_Row Background"), "fontColor": cf("fontColor", "_Row Font")},
                             "selector": {"data": [{"dataViewWildcard": {"matchingOption": 0}}], "metadata": f"{e}.{p}"}}
                            for e, p, k in pnl_fields]},
        container=title(measure_title="Title P&L"))
    pnl["visual"]["query"]["sortDefinition"] = {"sort": [{"field": F("PnL Layout", "Line"), "direction": "Ascending"}]}
    apply_role(pnl, TOK, "dark", "financial-matrix", "PnL Layout.Line", f"{M}.Dummy Column", insert_dummy=True)   # TB2
    line2 = trend(648, 88, 620, 276)
    br2 = bridge(648, 380, 620, 276)
    pages.append(page("Profit & Loss", c + [pnl, line2, br2], [(ids["period"], line2["name"])]))
    # Hotel List (T-LIST)
    c, ids = chrome("Hotel List")
    lst = visual("tableEx", 12, 88, 1044, 568, z=10000, query={"Values": {"projections": [
        proj("Hotel", "Hotel"), proj("Hotel", "Area"), proj("Hotel", "Rooms", display="Rooms"), proj(M, "Revenue", "Measure"),
        proj(M, "Revenue vs REF %", "Measure"), proj(M, "EBITDA", "Measure"), proj(M, "EBITDA %", "Measure"),
        proj(M, "EBITDA vs REF %", "Measure")]}},
        objects={"grid": [props({"rowPadding": 6})], "values": [props({"fontSize": 10})]},
        container=title("Hotels"))
    rail = visual("listSlicer", 1072, 88, 196, 568, z=11000, query={"Values": {"projections": [{**proj("Hotel", "Area"), "active": True}]}},
                  container=title("Area"))
    pages.append(page("Hotel List", c + [lst, rail]))

    order = []
    for pid, pj, vs in pages:
        (d / "pages" / pid / "visuals").mkdir(parents=True)
        for v in vs:
            link = v["visual"]["visualContainerObjects"].get("visualLink")
            if link and "__SELF__" in json.dumps(link):
                v["visual"]["visualContainerObjects"]["visualLink"] = json.loads(json.dumps(link).replace("__SELF__", pid))
            (d / "pages" / pid / "visuals" / v["name"]).mkdir()
            (d / "pages" / pid / "visuals" / v["name"] / "visual.json").write_text(json.dumps(v, indent=2, ensure_ascii=False))
        (d / "pages" / pid / "page.json").write_text(json.dumps(pj, indent=2, ensure_ascii=False))
        order.append(pid)
    (d / "pages" / "pages.json").write_text(json.dumps({
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.1.0/schema.json",
        "pageOrder": order, "activePageName": order[0]}, indent=2))
    return rep


def run(*args):
    r = subprocess.run([sys.executable, *map(str, args)], capture_output=True, text=True)
    print(r.stdout.strip() or r.stderr.strip())
    return r.returncode


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    for child in OUT.iterdir():          # clear contents (the folder itself may be locked by OneDrive / Desktop)
        if child.is_dir():
            shutil.rmtree(child, ignore_errors=True)
        else:
            try:
                child.unlink()
            except OSError:
                pass
    leftovers = [p for p in OUT.rglob("*") if p.is_file() and ".pbi" not in p.parts]
    if leftovers:
        print(f"WARNING: could not delete {len(leftovers)} file(s) (close the PBIP in Power BI Desktop and re-run): {leftovers[:3]}")
    (OUT / f"{NAME}.pbip").write_text(json.dumps({
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/pbip/pbipProperties/1.0.0/schema.json",
        "version": "1.0", "artifacts": [{"report": {"path": f"{NAME}.Report"}}], "settings": {"enableAutoRecovery": True}}, indent=2))
    (OUT / ".gitignore").write_text("**/.pbi/localSettings.json\n**/.pbi/cache.abf\n")
    build_model(OUT)
    rep = build_report(OUT)
    for p in ("Summary", "Profit & Loss", "Hotel List"):
        run(SKILL / "scripts" / "make_light_twin.py", "--report", rep, "--page", p)
    run(SKILL / "scripts" / "install_intro.py", "--report", rep)
    run(SKILL / "scripts" / "install_intro.py", "--report", rep, "--refresh-nav")
    brief = OUT / "_brief"
    brief.mkdir(exist_ok=True)
    (brief / "house.lock.yaml").write_text(
        f'design_system_version: "{VER}"\ndefault_mode: dark\ntheme_file: "corporate-dark.{VER}.json"\n'
        'intro_page: { template_version: "2.0.0" }\ntwin_exempt: [Intro]\n'
        'page_hierarchy:\n  - page: "Summary"\n    children: ["Profit & Loss", "Hotel List"]\n')
    print(f"Facts rows: {len(facts)} · hotels: {len(HOTELS)} · output: {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
