# pbi-house-design-system

Claude Skill: **Power BI Corporate Design System & Dashboard Standards**.
A design layer that works **alongside** `powerbi-report-cli` and `semantic-model-authoring`. It never edits PBIR itself (D1).

> Repo README. **Not** loaded by Claude; the skill entry point is `SKILL.md`.

## Status

| Step | Content | Status |
|---|---|---|
| 1–2 | Architecture + intake | ✅ |
| 3 | Design System capture (2 reports, Dark + Light twins) | ✅ `docs/discovery/` |
| 4 | Skill structure + rule ID system | ✅ |
| 5 | `SKILL.md` | ✅ |
| 6 | `references/**` + brief templates | ✅ 106 rules |
| 7 | `tokens.yaml` + schema + `check_tokens.py` / `check_contrast.py` | ✅ 39 colour tokens · PASSED |
| 8 | `build_themes.py` → Dark theme + Light override profile | ✅ `docs/theme-validation.md` |
| 9 | Examples, checkers, fixtures, evals | ✅ `tests/run_tests.py` 24/24 |
| 10 | Validation + packaging | ✅ `docs/validation-report.md` · `pbi-house-design-system.skill` |
| v0.2 | Intro page template + corporate logos | ✅ tests 32/32 · `dist/pbi-house-design-system-0.2.0.skill` |
| v0.3 | Simplified Dark-only Intro, dynamic navigator | ✅ tests 37/37 · `dist/pbi-house-design-system-0.3.0.skill` |
| v0.4 | Light-twin builder + HouseTest testbed (fictitious data) | ✅ tests 40/40 · `tests/testbed/` |

## Layout and load strategy

```text
pbi-house-design-system/
├── SKILL.md                        ALWAYS on trigger · router, ≤300 lines
├── tokens/
│   ├── tokens.yaml                 on any create/modify · single source of truth
│   └── tokens.schema.json          scripts only
├── references/                     ON DEMAND via routing table in SKILL.md
│   ├── boundaries-and-handoffs.md
│   ├── priority-and-exceptions.md
│   ├── foundations/   color · typography · layout-grid · modes
│   ├── components/    page-chrome · panel · kpi-card · charts · table-matrix
│   │                  slicers-filters · navigation · tooltips · text-titles
│   ├── formatting-standards.md
│   ├── data-driven-formatting.md
│   ├── composition/   dashboard-catalog.md · page-templates.yaml
│   ├── qa/            compliance-protocol.md · visual-review.md
│   └── integration/   tooling.md   (only file naming MCP servers / CLIs)
├── examples/                       ON DEMAND · good/bad pairs per component
├── assets/                         NEVER read into context · used as files
│   ├── themes/          GENERATED (corporate-dark + light-overrides)
│   ├── logo/            corporate logos (PNG/JPG) · icons/ (moon, sun, filters, play, home)
│   ├── templates/intro-page/  LOCKED Dark-only Intro page (logo, map, title, dynamic navigator) · installed by scripts/install_intro.py
│   ├── svg-templates/
│   └── brief-templates/ house-constraints · house.lock · remediation-plan
│                        model-requests · exceptions · compliance-report
├── scripts/                        EXECUTED, output only enters context
│   extract_pbir · check_tokens · check_contrast · build_themes · check_compliance
│   check_twins · diff_guard · _tokens · _pbir   (all ✅)
├── docs/        (repo only)  decision-log · rule-id-system · discovery/
├── tests/       (repo only)  run_tests.py · fixtures/{good,bad} · evals/{evals,trigger-evals}.json
├── dist/        (repo only)  packaged .skill files per version
├── CHANGELOG.md (repo only)
└── .skillignore              excludes docs/, tests/, dist/, CHANGELOG from the package
```

## Per-report artifacts (written into each PBIP, not into the skill)

```text
<Report>/_brief/
  house-constraints.yaml · house.lock.yaml · remediation-plan.yaml
  model-requests.yaml · exceptions.yaml · compliance-report.{json,md}
```

## Conventions
- Skill files in **English** (D13); conversation in Spanish.
- Rules: `docs/rule-id-system.md`. Decisions: `docs/decision-log.md`.
- Never put literal HEX outside `tokens.yaml › primitive`.
