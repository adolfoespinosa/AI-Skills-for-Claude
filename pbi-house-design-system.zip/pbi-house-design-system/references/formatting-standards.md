<!--
STATUS: v0.1 (Step 6, batch 3)
PURPOSE: Number, percentage, deviation and date formats; unit and currency toggles; model-request handoff (FMT-*).
LOADED: measures that will be displayed, number formatting, K/M or currency toggles.
-->
# Formatting Standards

Formats are **owned by the model** (measure format strings, dynamic format strings, or the layout table's
format columns). This skill defines the standard. `semantic-model-authoring` implements it through
`_brief/model-requests.yaml`. Never fix a format with a visual-level override when the model can carry it.

## 1. Standard formats (corpus: `DIM_Layout` format columns + measure format strings)

| Value type | Format string | Example | Notes |
|---|---|---|---|
| Amount | `#,##` | 142,677 | No decimals. Zero renders **blank** (see F1) |
| Ratio / % of revenue | `#,#0.0%` | 25.1% | 1 decimal |
| Deviation of an amount (DEV) | `#,##` | 3,268 | Same as amount |
| Deviation of a ratio (DEV) | `#,#0.0 pp` | 1.2 pp | Percentage points |
| % deviation (%DEV) | `#,#0.0%` | 2.4% | 1 decimal |
| Negative | leading minus sign | -3,842 | Never parentheses, never colour alone (ACCESS-003) |
| Date in title | `Mmm-YYYY` | Jun-2026 | TEXT-005 |
| Date on axis | `Mmm-YY` | Jan-26 | TEXT-005 |

Locale: thousands separator `,` and decimal separator `.`.

## 2. Units and currency

| Control | Values | Implementation |
|---|---|---|
| Unit | K / M | Model-side (dynamic format string, calculation group or SWITCH measure), driven by a button slicer in band.bottom |
| Currency | EUR / FXN / LC | Model-side, driven by a button slicer |
| Measure type | ABS / DEV / DEV% | Model-side, driven by a button slicer |
| Comparison | vs LY / vs TGT (BUD shown as fixed reference) | Model-side, driven by a button slicer |

The panel title must reflect the active unit and currency (TEXT-001, dynamic title).

## 3. Rules

```yaml
- id: FMT-001
  title: Formats from the standard table
  status: active
  since: 0.1.0
  severity: critical
  priority: P3
  modes: [dark, light]
  applies_to: [measure, layout_table]
  statement: "Displayed measures and layout-table format columns MUST use a format string from section 1 for their value type."
  check: assisted          # reads format strings via the model (integration/tooling.md)
  exceptions: allowed

- id: FMT-002
  title: Formats live in the model
  status: active
  since: 0.1.0
  severity: warning
  priority: P4
  modes: [dark, light]
  applies_to: ["*"]
  statement: "Visuals SHOULD NOT override display units or decimals (labelDisplayUnits / labelPrecision) when the measure carries the format. Exception: the K/M toggle when implemented visually is not allowed; it MUST be model-side."
  check: auto
  exceptions: allowed

- id: FMT-003
  title: Minus sign for negatives
  status: active
  since: 0.1.0
  severity: critical
  priority: P1
  modes: [dark, light]
  applies_to: [measure, layout_table]
  statement: "Negative values MUST render with a leading minus sign."
  check: assisted
  exceptions: forbidden

- id: FMT-004
  title: Sign convention in the model
  status: active
  since: 0.1.0
  severity: warning
  priority: P3
  modes: [dark, light]
  applies_to: [measure, layout_table]
  statement: "Sign inversion for cost lines MUST be done in the model or layout table (Sign / Multiplier columns), never by visual formatting."
  check: manual
  exceptions: allowed
```

## 4. Model request format

```yaml
# _brief/model-requests.yaml
requests:
  - id: MR-001
    measure: "<Table>[<Measure>]"
    request: format_string            # format_string | dynamic_format | display_folder | svg_measure | toggle
    value: "#,#0.0%"
    reason: "Ratio row, FMT-001"
    rule: FMT-001
    status: open                      # open | done | rejected
```

## 5. Decision F1 (2026-10-05)
`#,##` is the standard for amounts: **zero renders blank** on purpose (empty cells read as "no value" in the
P&L). Do not "fix" it to `#,##0`.
