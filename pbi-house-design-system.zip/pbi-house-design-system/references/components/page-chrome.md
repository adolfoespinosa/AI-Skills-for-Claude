<!--
STATUS: v0.1 (Step 6, batch 2). Geometry = corpus normalised to grid C. Items marked (proposed) need owner confirmation.
PURPOSE: Page header band, bottom band, logo/assets (PAGE-*, ASSET-*).
LOADED: creating or modifying any page.
-->
# Page Chrome

## 1. Anatomy

```text
y=10  ┌─ HEADER FRAME (surface.header, 1 px border.container, radius 10, shadow.header) ──────────────┐
      │ [RHG logo 245×50]          [ Title 244×66 ]  [Period]                         [Badge 58×54] │
y=76  └─────────────────────────────────────────────────────────────────────────────────────────────┘
y=88  … band.content …
y=656 [Dropdowns] [Button-slicer group] [group] [group] …          [nav icons] … [◐ toggle]
y=720
```

## 2. Header (decision HD1, 2026-10-07) · every page except Intro and tooltip pages

Installed by `scripts/install_header.py` from `assets/templates/page-header/header.template.json`; geometry in
`tokens › component.header`. Colours are resolved **per mode** (the Light twin is rebuilt by `make_light_twin.py`).
Source: *RHG Consolidated Results › ▶ P&L RHG*.

| Element (Selection pane) | Visual | Geometry (x · y · w × h) | Dark | Light |
|---|---|---|---|---|
| Header Frame | `shape` rectangle, no fill; container background on | 11 · 10 · 1246 × 66 | background `#425463` · border `#FFFFFF` 1 px · radius 10 · shadow `#425463` (outer, bottom right) | background `#E6E6E6` · border `#425463` · same radius and shadow |
| Header Logo | `image`, rectangular RHG logo, **Image fit = Fit** (HD3) | 15 · 20 · 245 × 50 | `logo-white.png` | `logo-blue.png` |
| Header Title | `textbox`, default **"Title"**, Segoe (Bold) 25 pt, centred **on the frame** (HD3) | 512 · 16 · 244 × 60 | `#F3B244` (accent) | `#425463` |
| Header Period *(optional, needs the period measure)* | `cardVisual` · no border, no background, no divider, no label, **multi-card layout without background and uniform padding 0** (HD4) · value **Segoe UI Semibold 15**, centred | 772 · 22 · 143 × 48 | value white (`text.period`) | value `#336293` (`text.period`) |
| Header Badge | `image`, **empty**, padding 0, fit Normal, stroke 1 px, 4 corners 10 px, background 0 % transparency; caption (title) Segoe UI Semibold 8 centred | 1184 · 12 · 58 × 54 | background `#425463` · stroke `#FFFFFF` · caption white | background `#E6E6E6` · stroke `#425463` · caption `#425463` |

```bash
python ${CLAUDE_SKILL_DIR}/scripts/install_header.py --report "<.Report>" --page "<page>" [--title "P&L RHG"] [--badge-title "EUR"] \
       [--period "_Measures[Selected Period]"]
python ${CLAUDE_SKILL_DIR}/scripts/install_header.py --report "<.Report>" --all      # every standard page and twin
```

Re-running replaces the header visuals and keeps the current title, caption and period measure. Other header
content (context cards) goes between the period card and the badge. The KPI-tile role of `make_light_twin.py` never
touches header visuals. Only the header frame casts a shadow (P6).

## 3. Bottom band (656 → 720)

Order is fixed from left to right: **dropdown slicers → button-slicer groups → (free) → navigation icons → mode toggle**.

Decision PC1 (2026-10-04): **every button is 50 × 50**. Controls are centred vertically in the 64 px band.

| Element | Geometry | Notes |
|---|---|---|
| Dropdown slicers (e.g. Year, Period) | y 660 · h 56 · width span 2 (90) or span 3 (143) · first one at column 1 (x 12) | Header label visible (`type.control`) |
| Button-slicer group | y 663 · h 50 · **width = 50 × number of buttons** (2 → 100, 3 → 150) | One visual per dimension: comparison · measure type · unit · currency |
| Gaps (left cluster) | **16 (gutter)** between dropdowns and between groups | Only the first element starts on a column. The rest follow at gutter distance, because 50 px buttons do not fit the 53 px column pitch |
| Mode toggle | 50 × 50 · y 663 · right-aligned to x 1268 → **x 1218** | See MODE-005 |
| Navigation icons | 50 × 50 · y 663 · right to left from the toggle with a 16 gap: x 1152, 1086, 1020, … | home, back, info, reset/clear |

Band bottom geometry is the only place where widths are not grid spans (LAYOUT-003/004 exemption,
see `foundations/layout-grid.md`).

## 4. Rules

```yaml
- id: PAGE-001
  title: Header container
  status: active
  since: 0.1.0
  severity: critical
  priority: P2
  modes: [dark, light]
  applies_to: [shape]
  statement: "Every standard page MUST have one header frame occupying band.header (x 11, y 10, w 1246, h 66) with surface.header, border.container and radius.container (HD1)."
  check: auto
  exceptions: allowed

- id: PAGE-002
  title: Shadow only on the header
  status: active
  since: 0.1.0
  severity: warning
  priority: P2
  modes: [dark, light]
  applies_to: ["*"]
  statement: "dropShadow, shadowCustom and glowCustom MUST be off on every visual except the header container, which uses shadow.header."
  check: auto
  exceptions: allowed

- id: PAGE-003
  title: Logo placement and variant
  status: active
  since: 0.1.0
  severity: critical
  priority: P2
  modes: [dark, light]
  applies_to: [image]
  statement: "The corporate logo MUST appear once per standard page, left in the header (x 20, y 16, h 48, aspect ratio preserved), using the variant for the page's background (dark or light)."
  check: auto
  exceptions: allowed

- id: PAGE-004
  title: Bottom band order
  status: active
  since: 0.1.0
  severity: critical
  priority: P2
  modes: [dark, light]
  applies_to: [page]
  statement: "band.bottom MUST contain, left to right: dropdown slicers, button-slicer groups, navigation icons, mode toggle. Filters MUST NOT be placed in the header or content bands."
  check: auto
  exceptions: allowed

- id: PAGE-005
  title: Page title centred
  status: active
  since: 0.1.0
  severity: warning
  priority: P5
  modes: [dark, light]
  applies_to: [textbox]
  statement: "The page title textbox MUST be horizontally centred on the canvas (centre x = 640, tolerance 4 px) inside band.header."
  check: auto
  exceptions: allowed

- id: PAGE-006
  title: Background shape
  status: active
  since: 0.1.0
  severity: info
  priority: P5
  modes: [dark, light]
  applies_to: [page]
  statement: "Page background SHOULD be set through page.background = surface.page and outspace = surface.outspace, not through a full-page shape."
  check: auto
  exceptions: allowed

- id: ASSET-001
  title: Registered assets come from the skill
  status: active
  since: 0.1.0
  severity: warning
  priority: P2
  modes: [dark, light]
  applies_to: [image, actionButton]
  statement: "Logos and icons MUST come from assets/logo and assets/icons. Duplicated copies of the same image in RegisteredResources are not allowed."
  check: assisted
  exceptions: allowed

- id: PAGE-007
  title: Bottom band geometry
  status: active
  since: 0.1.0
  severity: warning
  priority: P5
  modes: [dark, light]
  applies_to: [slicer, advancedSlicerVisual, actionButton]
  statement: "In band.bottom: buttons (button-slicer buttons, navigation icons, mode toggle) MUST be 50 × 50 at y 663; dropdowns h 56 at y 660; elements in the left cluster separated by 16; the right cluster right-aligned to x 1268 with 16 gaps."
  check: auto
  exceptions: allowed

- id: PAGE-011
  title: Corporate page header
  status: active
  since: 0.9.0
  severity: critical
  priority: P2
  modes: [dark, light]
  applies_to: [page]
  statement: "Every page except Intro and tooltip pages MUST carry the four header visuals of section 2 (Frame, Logo, Title, Badge) with the template geometry, the logo of the page mode and the frame colour of the page mode. Install or repair with install_header.py."
  check: auto
  exceptions: allowed
```

## 5. Open points
- PC2: PNG logos are included (`assets/logo/`). Official SVG versions are still pending (G1); they will replace the PNGs with the same names.